;
/* tAIvy.js */
$(document).ready(function () {
    $('#header_other').bind('touchend', function () {
        if ($(this).hasClass('hover')) {
            $(this).removeClass('hover');
            return;
        } else {
            $(this).addClass('hover');
            return;
        }
    });
    $('#header_other_list').bind('touchend', function (event) {
        event.stopPropagation();
    });
    $('#header_other').on('mouseenter', function () {
        $(this).addClass('hover');
    });
    $('#header_other').on('mouseleave', function () {
        $(this).removeClass('hover');
    });
});
;
/* OTmpa.js */
var more_timer;

function clearTimer() {
    if (more_timer) {
        clearTimeout(more_timer);
        more_timer = null;
    }
}

function showMoreLogin() {
    clearTimer();
    var target = document.getElementById("more_login");
    var parent = document.getElementById("more");
    target.style.display = "block";
    target.style.top = (parent.offsetTop + 34) + "px";
    target.style.left = (parent.offsetLeft - 80) + "px";
}

function hideMoreLogin() {
    if (more_timer == null) {
        clearTimeout(more_timer);
        more_timer = setTimeout(function () {
            document.getElementById("more_login").style.display = "none";
            more_timer = null;
        }, 500);
    }
}

function moreOver() {
    clearTimer();
}

function moreOut() {
    hideMoreLogin();
}

$(document).ready(function () {
    $('#login_user').bind('touchend', function () {
        if ($(this).hasClass('hover')) {
            $(this).removeClass('hover');
            return;
        } else {
            $(this).addClass('hover');
            return;
        }
    });
    $('.login_ext_info').bind('touchend', function (event) {
        event.stopPropagation();
    });
    $('#login_user').on('mouseenter', function () {
        $(this).addClass('hover');
    });
    $('#login_user').on('mouseleave', function () {
        $(this).removeClass('hover');
    });
});
;

/* 9haEr.js */
function emptyInput(id) {
    $j("#" + id).val("").get(0).focus();
    $j("#" + id + "_tips").css({display: "none"});
}

function inputFocus(obj) {
    $j("#" + $j(obj).attr("id") + "_tips").css({display: "none"});
    $j(obj.parentElement).css({"background-position": "0px -52px"});
}

function inputBlur(obj) {
    if ($j(obj).val().length == 0)
        $j("#" + $j(obj).attr("id") + "_tips").css({display: ""});
    $j(obj.parentElement).css({"background-position": "0px 0px"});
}

function detectCapsLock(event) {
    var e = event || window.event;
    var o = e.target || e.srcElement;
    var keyCode = e.keyCode || e.which;
    if (keyCode >= 65 && keyCode <= 90)
        $j("#lg_c_capslock_tips").css({display: "inline"});
    else
        $j("#lg_c_capslock_tips").css({display: "none"});
}



//获取验证码

function rotateImg() {
    $j("#verifyimg").attr({src: "./RESTApi/getcode.php?" + +new Date()});
    $j("#vc").val("").get(0).focus();
}





function cancelEvent(e) {
    e.returnValue = false;
    if (e.stopPropagation)
        e.stopPropagation();
    if (e.preventDefault)
        e.preventDefault();
    return false;
}

function tip(msg) {
    $j("#lg_c_msg").html("<span></span>" + msg).css({
        visibility: "visible",
        background: "#e5f5ff",
        border: "#40b3ff 1px solid"
    });
    $j("#lg_c_msg span").css({
        background: "url('image/login3.png') no-repeat -76px -177px",
        display: "inline-block",
        width: "25px",
        height: "25px",
        "vertical-align": "middle"
    });
}

function error(msg) {
    $j("#lg_c_msg").html("<span></span>" + msg).css({
        visibility: "visible",
        background: "#fff2f2",
        border: "#ff8080 1px solid"
    });
    $j("#lg_c_msg span").css({
        background: "url('image/login3.png') no-repeat 4px -177px",
        display: "inline-block",
        width: "25px",
        height: "25px",
        "vertical-align": "middle"
    });
    setTimeout(function () {
        $j("#lg_c_msg").css({visibility: "hidden"})
    }, 6000);
    rotateImg();
}

function pass(code) {
    var state = $j("#form #state").val();
    window.location = state == "" ? "/" : state;
}

function ajax(method, url, param, callback) {
    var request;
    if (window.XMLHttpRequest)
        request = new XMLHttpRequest();
    else
        request = new ActiveXObject("Microsoft.XMLHTTP");
    var queryString = "";
    for (var key in param)
        queryString = queryString + key + "=" + param[key] + "&";
    queryString = encodeURI(queryString);
    request.onreadystatechange = function () {
        if (request.readyState == 4)
            callback(request.status, request.responseText, request);
    };
    if (method == "GET") {
        request.open("GET", url + "?" + queryString + +new Date());
        request.send(null);
    }
    else {
        request.open("POST", url);
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        request.send(queryString);
    }
}

if (document.addEventListener) {
    document.addEventListener("DOMContentLoaded", function () {
        onReady();
    }, false);
}
else if (document.attachEvent) {
    document.attachEvent("onreadystatechange", function () {
        if (document.readyState === "complete")
            onReady();
    });
}