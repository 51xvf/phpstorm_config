;
/* 16xQvq.js */
var space_common = {
    showmsg: function (msg, type, fun) {
        type = typeof type === 'undefined' ? "success" : type;
        var box = $("<div class='space_common_msgbox box_layer " + type + "'><div class='box_cover'></div></div>");
        var box_content = $("<div class='box_bg'><div class='box'></div></div>");
        box_content.find("div").append("<div class='logo'></div>").append("<div class='content'>" + msg + "</div>");
        box.append(box_content);
        $("body").append(box);
        space_common.locationCenter(box_content);
        box_content.show();
        setTimeout(function () {
            box.fadeOut(1000, function () {
                typeof fun == "function" ? fun() : "";
                box.remove();
            });
        }, 500);
    }, confirm: function (title, msg, fun) {
        var box = $("<div class='space_common_confirmbox box_layer'><div class='box_cover'></div></div>");
        var box_content = $("<div class='box_bg'><div class='box'></div></div>");
        box_content.find(".box").append("<h2>" + title + "</h2>").append("<div class='clearfix'><div class='logo'></div><div class='content'>" + msg + "</div></div>").append("<div class='action'><a class='confirm' href='javascript:;'>确定</a><a class='cancel' href='javascript:;'>取消</a></div>");
        box.append(box_content);
        $("body").append(box);
        space_common.locationCenter(box_content);
        box_content.show();
        box.find(".cancel").click(function () {
            box.remove();
        });
        box.find(".confirm").click(function () {
            fun();
            box.remove();
        });
    }, locationCenter: function (e, top, left) {
        var eWindow = $(window);
        var eDoc = $(document);
        e.css({
            top: eDoc.scrollTop() + (eWindow.height() - e.outerHeight()) / 2 + (typeof top == "undefined" ? 0 : top),
            left: eDoc.scrollLeft() + (eWindow.width() - e.outerWidth()) / 2 + (typeof left == "undefined" ? 0 : left)
        });
    }, locationBelow: function (e, eUp, top, left) {
        e.css({
            top: eUp.position().top + eUp.outerHeight() + (typeof top == "undefined" ? 0 : top),
            left: eUp.position().left + (typeof left == "undefined" ? 0 : left)
        });
    }, strip_tags: function (s) {
        return s.replace(/<[^>]+?>/g, "");
    }, login: function () {
        alert("请先登录");
    }, post: function (url, data, success, error, complete) {
        $.ajax({
            url: url, data: data, dataType: "JSON", method: "POST", success: function (res) {
                if (res.status == 1) {
                    success(res);
                } else if (res.status == 2) {
                    space_common.showmsg(res.msg, "error");
                } else if (res.status == 100) {
                    space_common.login();
                } else {
                    typeof error == "function" ? error() : space_common.showmsg("操作失败", "error");
                }
            }, error: function (res) {
                space_common.error_display(res.responseText);
                typeof error == "function" ? error() : space_common.showmsg("操作失败", "error");
            }, complete: function () {
                typeof complete == "function" ? complete() : "";
            }
        });
    }
};
;
/* 10eWCE.js */
(function () {
    $(document).ready(function () {


        var $birthday = $('#psm_birthday');
        var year = $birthday.find('[name="year"]');
        var month = $birthday.find('[name="month"]');
        var day = $birthday.find('[name="day"]');


        year.find('option[value="' + year.attr('select') + '"]').attr('selected', 'selected');

        var html = new Array();

        for (var i = 1; i <= 12; i++) {
            html.push('<option value="' + i + '">' + i + '</option>');
        }
        month.html(html.join(''));
        month.find('option[value="' + month.attr('select') + '"]').attr('selected', 'selected');
        getDayList();
        year.change(function () {
            getDayList();
        });
        month.change(function () {
            getDayList();
        });

        function getDayList() {
            var sel_year = year.val();
            var sel_month = month.val();
            sel_month = sel_month ? sel_month : 1;
            var sel_day = day.val();
            sel_day = sel_day ? sel_day : day.attr('select');
            var month_day = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            if (sel_year % 4 == 0 && (sel_year % 100 != 0 || sel_year % 400 == 0)) {
                month_day[2] = 29;
            }
            var html = new Array();
            for (var i = 1; i <= month_day[sel_month]; i++) {
                html.push('<option value="' + i + '">' + i + '</option>');
            }
            day.html(html.join(''));
            day.find('option[value="' + sel_day + '"]').attr('selected', 'selected');
        }

        $('#psm_brief').bind('keyup', function () {
            var val = $('#psm_brief').val();
            if (val.length > 100) {
                val = val.substr(0, 100);
                $('#psm_brief').val(val);
            }
            $('#psm_brief_number').html(val.length + '/100');
        });
        $('#psm_signature').bind('keyup', function () {
            var sig = $('#psm_signature').val();
            if (sig.length > 30) {
                sig = sig.substr(0, 30);
                $('#psm_signature').val(sig);
            }
        });


        //todo 2017-09-22用户信息更新


        //排行榜记录


       // rank_ajaxreq();

        function rank_ajaxreq() {
            $.ajax({

                //提交数据的类型 POST GET
                type: "POST",

                //提交的网址
                url: "../RESTApi/doUserRank.php",

                //提交的数据
                data: {do: "act"},

                //返回数据的格式
                datatype: "json",//"xml", "html", "script", "json", "jsonp", "text".

                //在请求之前调用的函数
                beforeSend: function (XMLHttpRequest) {
                    //todo
                    $(".loading").html("<img src='http://www.91xiaoyu.com/images/loading.gif'>");
                },

                //成功返回之后调用的函数
                success: function (data) {

                    var jsondata = $.parseJSON(data);
                    var rankdata = jsondata.data;

                    var temp = "";
                    var num = 1;
                    $.each(rankdata, function (key, val) {

                        temp += "                    <a href=\"chapterlist.php\">\n" +
                            "                    <div class=\"cc_li clearfix \">\n" +
                            "                        <div class=\"cc_number top3\">" + num + "</div>\n" +
                            "                        <div class=\"cc_rank cc_rank_up\" title=\"排名上升了2位\"><em></em><span>2</span></div>\n" +
                            "                        <div class=\"cc_level\">" + val.lv + "</div>\n" +
                            "                        <div class=\"cc_uname ellipsis\">" + val.nickname + "</div>\n" +
                            "                        <div class=\"cc_gems\"><span class=\"lv_gem\"></span>" + val.stuDay + "</div>\n" +
                            "                        <div class=\"cc_coins\"><span class=\"lv_coin\"></span>" + val.star + "</div>\n" +
                            "                        <div class=\"cc_awards\"><span class=\"lv_medal\"></span>" + val.rank + "</div>\n" +
                            "                    </div>\n" +
                            "                </a>";

                        num++;

                    });


                    $(".cc_list").append(temp);


                    //todo
                },

                //调用执行后调用的函数
                complete: function (XMLHttpRequest, textStatus) {
                    //todo
                    $(".loading").remove();
                },

                //调用出错执行的函数
                error: function () {
                    //todo
                }
            });

        }








        //调用播放记录
        var mob = "18710333329";
        ajaxDoPlayHistory(mob);

        /**
         * 处理播放历史记录
         * @param mob
         */

        function ajaxDoPlayHistory(mob) {
            $.ajax({

                //提交数据的类型 POST GET
                type: "POST",

                //提交的网址
                url: "../RESTApi/doPlayHistory.php",

                //提交的数据
                data: {do: "getPlayHistoryList", mob: mob},

                //返回数据的格式
                datatype: "json",//"xml", "html", "script", "json", "jsonp", "text".

                //在请求之前调用的函数
                beforeSend: function (XMLHttpRequest) {
                    //todo
                    $(".loading").html("<img src='http://www.91xiaoyu.com/images/loading.gif'>");
                },

                //成功返回之后调用的函数
                success: function (data) {

                    //todo
                    var jsondata = $.parseJSON(data);
                    var playdata = jsondata.data;
                   // console.log(jsondata);

                    var temp = "";
                    $.each(playdata, function (key, val) {

                        // var percent = Percentage(val.currentTime,val.durationTime);
                        var percent = ((val.currentTime / val.durationTime) * 100).toFixed(2) + '%';
                        var is_summ = val.is_summ;

                        if (is_summ) {
                            is_summ = "[有总结]";
                        } else {
                            is_summ = "";
                        }


                        temp += "                    <div class=\"records_course clearfix\">\n" +
                            "                        <div class=\"records_course_name ellipsis\" style=\"\">数学<a class='myexam' href='javascript:;' data-examId='" + val.vid + "'>" + is_summ + "</a></div>\n" +
                            "                        <div class=\"course_content\" style=\"display:inline-block\">\n" +
                            "                            <div class=\"clearfix\" style=\"float: right;\">\n" +
                            "                                <div class=\"category_name ellipsis\">" + val.title + "</div>\n" +
                            "                                <div class=\"to_learn\" data-stage_id=\"15865\"\n" +
                            "                                     onclick=\"window.location.href='http://www.91xiaoyu.com/videpage/index.php?from=playhistory&currentTime=" + val.currentTime + "&vtitle=" + val.title + "&id=" + val.vid + "';\">\n" +
                            "                                    开始学习\n" +
                            "                                </div>\n" +
                            "                            </div>\n" +
                            "                            <div class=\"course_prosess_div\">\n" +
                            "                                <div class=\"course_prosess\">\n" +
                            "                                    <div style=\"width:" + percent + "\"></div>\n" +
                            "                                </div>\n" +
                            "                                <span>" + percent + "</span>\n" +
                            "                            </div>\n" +
                            "                        </div>\n" +
                            "                        <div class=\"course_content\" style=\"display:none\">\n" +
                            "                            <div class=\"passed_icon\"></div>\n" +
                            "                            <div class=\"passed_tip\">已完成该学科下的全部知识点</div>\n" +
                            "                        </div>\n" +
                            "                    </div>";

                    });

                    $(".last_records_course_items").append(temp);


                },

                //调用执行后调用的函数
                complete: function (XMLHttpRequest, textStatus) {
                    //todo
                    $(".loading").remove();
                },

                //调用出错执行的函数
                error: function () {
                    //todo
                }
            });

        }


        $(".myexam").live('click', function () {

            var examId = $(this).attr("data-examId");

            $.ajax({

                //提交数据的类型 POST GET
                type: "POST",

                //提交的网址
                url: "../RESTApi/doPlayHistory.php",

                //提交的数据
                data: {do: "querySummary",examId:examId},

                //返回数据的格式
                datatype: "json",//"xml", "html", "script", "json", "jsonp", "text".

                //在请求之前调用的函数
                beforeSend: function (XMLHttpRequest) {
                    //todo
                },

                //成功返回之后调用的函数
                success: function (data) {

                    //todo

                    console.log(data);

                    layer.open({
                        type: 1,
                        title: '自己的学习总结~',
                        resize: false,
                        shadeClose: false,
                        area: ['493px', '270px'],
                        fixed: true,
                        maxmin: false,
                        content: $('#querySummary')
                    });
                },

                //调用执行后调用的函数
                complete: function (XMLHttpRequest, textStatus) {
                    //todo
                },

                //调用出错执行的函数
                error: function () {
                    //todo
                }
            });


        });


        //意见反馈

        $("#fee_submit").click(function () {
            var fee_text = $("#fee_text").val();

            if (fee_text === "") {
                layer.msg('请输入内容', {icon: 5}, function () {
                    location.reload();

                });
            } else {

                $.ajax({

                    //提交数据的类型 POST GET
                    type: "POST",

                    //提交的网址
                    url: "http://www.91xiaoyu.com/RESTApi/personal_update.php",

                    //提交的数据
                    data: {do: "feeAct", fee_text: fee_text},

                    //返回数据的格式
                    datatype: "json",//"xml", "html", "script", "json", "jsonp", "text".

                    //在请求之前调用的函数
                    beforeSend: function (XMLHttpRequest) {
                        //todo
                    },

                    //成功返回之后调用的函数
                    success: function (data) {

                        var jsondata = $.parseJSON(data);
                        if (jsondata.code === 0) {

                            layer.msg('提交成功', {
                                icon: 1,
                                time: 2000 //2秒关闭（如果不配置，默认是3秒）
                            }, function () {
                                //do something
                                location.reload();
                            })

                        }

                        //todo
                    },

                    //调用执行后调用的函数
                    complete: function (XMLHttpRequest, textStatus) {
                        //todo
                    },

                    //调用出错执行的函数
                    error: function () {
                        //todo
                    }
                });

            }

        });


        $(".laydate-icon").click(function () {
            laydate({elem: '#my_birthday'});//绑定元素 调用日历组件

        });

        //图片修改
        $('#imgUpload').click(function () {
            layer.open({
                type: 2,
                resize: false,
                shadeClose: false,
                area: ['600px', '300px'],
                fixed: false,
                maxmin: true,
                content: './imgUploadAct/',
                cancel: function (index, layero) {

                    //-----------------------
                    layer.close(index);
                    window.location.href = "./myhome.php";

                    //---------------------------


                }
            });
        });


        //todo 个人用户信息修改，这里需要重构！！！

        $('#psm_submit').click(function () {
            var data = {};

            data.realname = $('#psm_realname').val();

            data.nickname = $('#nickname').val();

            data.grade = $('#grade').val();

            data.birthday = $('#my_birthday').val();

            data.do = "personal_updete";

            data.gender = $('#psm_gender input:checked').val();
            if (!data.gender) {
                data.gender = 0;
            }


            data.signature = $('#psm_signature').val();
            data.brief = $('#psm_brief').val();


            if (data.email == '' || data.realname == '' || data.gender == '') {


                if (data.realname == '') {
                    space_common.showmsg('真实姓名未填写', 'error', function () {
                    });
                    return;
                }
                if (data.gender == '') {
                    space_common.showmsg('性别未填写', 'error', function () {
                    });
                    return;
                }

            } else {

                $.post('http://www.91xiaoyu.com/RESTApi/personal_update.php', data, function (msg) {


                    console.log(msg);

                    var ret = $.parseJSON(msg);

                    if (ret.status == 1) {
                        space_common.showmsg('修改成功', 'success', function () {
                            location.reload();
                        });
                    }

                });

            }
        });


    });
})();
;
/* tAIvy.js */
$(document).ready(function () {
    $('#header_other').bind('touchend', function () {
        if ($(this).hasClass('hover')) {
            $(this).removeClass('hover');
            return;
        } else {
            $(this).addClass('hover');
            return;
        }
    });
    $('#header_other_list').bind('touchend', function (event) {
        event.stopPropagation();
    });
    $('#header_other').on('mouseenter', function () {
        $(this).addClass('hover');
    });
    $('#header_other').on('mouseleave', function () {
        $(this).removeClass('hover');
    });
});
;
/* OTmpa.js */
var more_timer;

function clearTimer() {
    if (more_timer) {
        clearTimeout(more_timer);
        more_timer = null;
    }
}

function showMoreLogin() {
    clearTimer();
    var target = document.getElementById("more_login");
    var parent = document.getElementById("more");
    target.style.display = "block";
    target.style.top = (parent.offsetTop + 34) + "px";
    target.style.left = (parent.offsetLeft - 80) + "px";
}

function hideMoreLogin() {
    if (more_timer == null) {
        clearTimeout(more_timer);
        more_timer = setTimeout(function () {
            document.getElementById("more_login").style.display = "none";
            more_timer = null;
        }, 500);
    }
}

function moreOver() {
    clearTimer();
}

function moreOut() {
    hideMoreLogin();
}

$(document).ready(function () {
    $('#login_user').bind('touchend', function () {
        if ($(this).hasClass('hover')) {
            $(this).removeClass('hover');
            return;
        } else {
            $(this).addClass('hover');
            return;
        }
    });
    $('.login_ext_info').bind('touchend', function (event) {
        event.stopPropagation();
    });
    $('#login_user').on('mouseenter', function () {
        $(this).addClass('hover');
    });
    $('#login_user').on('mouseleave', function () {
        $(this).removeClass('hover');
    });
});
;
/* e5v3.js */
var space_common = {
    showmsg: function (msg, type, fun) {
        type = typeof type === 'undefined' ? "success" : type;
        var box = $("<div class='space_common_msgbox box_layer " + type + "'><div class='box_cover'></div></div>");
        var box_content = $("<div class='box_bg'><div class='box'></div></div>");
        box_content.find("div").append("<div class='logo'></div>").append("<div class='content'>" + msg + "</div>");
        box.append(box_content);
        $("body").append(box);
        space_common.locationCenter(box_content);
        box_content.show();
        setTimeout(function () {
            box.fadeOut(1000, function () {
                typeof fun == "function" ? fun() : "";
                box.remove();
            });
        }, 500);
    }, confirm: function (title, msg, fun) {
        var box = $("<div class='space_common_confirmbox box_layer'><div class='box_cover'></div></div>");
        var box_content = $("<div class='box_bg'><div class='box'></div></div>");
        box_content.find(".box").append("<h2>" + title + "</h2>").append("<div class='clearfix'><div class='logo'></div><div class='content'>" + msg + "</div></div>").append("<div class='action'><a class='confirm' href='javascript:;'>确定</a><a class='cancel' href='javascript:;'>取消</a></div>");
        box.append(box_content);
        $("body").append(box);
        space_common.locationCenter(box_content);
        box_content.show();
        box.find(".cancel").click(function () {
            box.remove();
        });
        box.find(".confirm").click(function () {
            fun();
            box.remove();
        });
    }, locationCenter: function (e, top, left) {
        var eWindow = $(window);
        var eDoc = $(document);
        e.css({
            top: eDoc.scrollTop() + (eWindow.height() - e.outerHeight()) / 2 + (typeof top == "undefined" ? 0 : top),
            left: eDoc.scrollLeft() + (eWindow.width() - e.outerWidth()) / 2 + (typeof left == "undefined" ? 0 : left)
        });
    }, locationBelow: function (e, eUp, top, left) {
        e.css({
            top: eUp.position().top + eUp.outerHeight() + (typeof top == "undefined" ? 0 : top),
            left: eUp.position().left + (typeof left == "undefined" ? 0 : left)
        });
    }, strip_tags: function (s) {
        return s.replace(/<[^>]+?>/g, "");
    }, login: function () {
        alert("请先登录");
    }, post: function (url, data, success, error, complete) {
        $.ajax({
            url: url, data: data, dataType: "JSON", method: "POST", success: function (res) {
                if (res.status == 1) {
                    success(res);
                } else if (res.status == 2) {
                    space_common.showmsg(res.msg, "error");
                } else if (res.status == 100) {
                    space_common.login();
                } else {
                    typeof error == "function" ? error() : space_common.showmsg("操作失败", "error");
                }
            }, error: function (res) {
                space_common.error_display(res.responseText);
                typeof error == "function" ? error() : space_common.showmsg("操作失败", "error");
            }, complete: function () {
                typeof complete == "function" ? complete() : "";
            }
        });
    }, error_display: function (msg) {
    }
};
;
/* mXpKQ.js */
var message = {
    send: function (editor, to_name, success_callback) {
        var data = {};
        data.content = editor.val();
        if (data.content == "") {
            return false;
        }
        ;
        if (to_name == "") {
            return false;
        }
        ;data.to_name = to_name;
        editor.disableSubmit();
        space_common.post('/space/ajax/new_message.php', data, function () {
            space_common.showmsg("发送成功");
            editor.reset();
            typeof success_callback == "function" ? success_callback() : "";
        }, function () {
            space_common.showmsg("发送失败", "error");
        }, function () {
            editor.enableSubmit();
        });
    }, sendBox: function (name) {
        name = typeof name == 'undefined' ? '' : name;
        if (this.elem.top == null) {
            this.messageBoxInit();
        }
        this.elem.top.show();
        space_common.locationCenter(this.elem.main.show(), 0, 0);
        this.elem.nameInput.val(name);
        this.elem.editor.reset()
        if (name == "") {
            this.elem.nameInput.focus();
        } else {
            this.elem.editor.focus();
        }
    }, elem: {top: null, nameInput: null, main: null, editor: null}, messageBoxInit: function () {
        var top = $("<div class='send_message_box box_layer'><div class='box_cover'></div></div>");
        var main = $("<div class='box_bg'><div class='box'></div></div>");
        top.append(main);
        main.find(".box").append("<h2>发私信<a href='javascript:;' class='btn_close'>&nbsp;</a></h2>");
        main.find(".box").append('<dl class="clearfix"> <dt>发&nbsp;给: </dt> <dd><input class="name_input" placeholder="请输入对方呢称" type="text" /></dd></dl class="clearfix"><dl class="editor_wrapper"> <dt>内&nbsp;容: </dt> <dd></dd>   </dl>');
        this.elem.nameInput = main.find(".name_input");
        var self = this;
        this.elem.editor = Editor(main.find(".editor_wrapper dd"), {}, function () {
            var to_name = self.elem.nameInput.val();
            if (to_name == "") {
                space_common.showmsg("请输入对方呢称", "error");
                return false;
            }
            ;self.send(self.elem.editor, to_name, function () {
                top.hide();
            });
        });
        $("body").append(top);
        this.elem.top = top;
        this.elem.main = main;
        main.find(".btn_close").click(function () {
            top.hide();
        });
    }
};
;
/* KbH4T.js */
(function () {
    var TT = {
        getCursorPosition: function (t) {
            if (document.selection) {
                t.focus();
                var ds = document.selection;
                var range = ds.createRange();
                var stored_range = range.duplicate();
                stored_range.moveToElementText(t);
                stored_range.setEndPoint("EndToEnd", range);
                t.selectionStart = stored_range.text.length - range.text.length;
                t.selectionEnd = t.selectionStart + range.text.length;
                return t.selectionStart;
            } else {
                return t.selectionStart;
            }
        }, setCursorPosition: function (t, p) {
            this.sel(t, p, p);
        }, add: function (t, txt) {
            var val = t.value;
            if (document.selection) {
                t.focus();
                document.selection.createRange().text = txt;
            } else {
                var cp = t.selectionStart;
                var ubbLength = t.value.length;
                var s = t.scrollTop;
                t.value = t.value.slice(0, t.selectionStart) + txt + t.value.slice(t.selectionStart, ubbLength);
                this.setCursorPosition(t, cp + txt.length);
                firefox = navigator.userAgent.toLowerCase().match(/firefox\/([\d\.]+)/) && setTimeout(function () {
                    if (t.scrollTop != s)
                        t.scrollTop = s;
                }, 0);
            }
            ;
        }, del: function (t, n) {
            var p = this.getCursorPosition(t);
            var s = t.scrollTop;
            var val = t.value;
            t.value = n > 0 ? val.slice(0, p - n) + val.slice(p) : val.slice(0, p) + val.slice(p - n);
            this.setCursorPosition(t, p - (n < 0 ? 0 : n));
            firefox = navigator.userAgent.toLowerCase().match(/firefox\/([\d\.]+)/) && setTimeout(function () {
                if (t.scrollTop != s)
                    t.scrollTop = s;
            }, 10);
        }, sel: function (t, s, z) {
            if (document.selection) {
                var range = t.createTextRange();
                range.moveEnd('character', -t.value.length);
                range.moveEnd('character', z);
                range.moveStart('character', s);
                range.select();
            } else {
                t.setSelectionRange(s, z);
                t.focus();
            }
        }, selString: function (t, s) {
            var index = t.value.indexOf(s);
            index != -1 ? this.sel(t, index, index + s.length) : false;
        }
    };
    var kingwolfofsky = {
        getInputPositon: function (elem) {
            if (document.selection) {
                elem.focus();
                var Sel = document.selection.createRange();
                return {left: Sel.boundingLeft, top: Sel.boundingTop, bottom: Sel.boundingTop + Sel.boundingHeight};
            } else {
                var that = this;
                var cloneDiv = '{$clone_div}', cloneLeft = '{$cloneLeft}', cloneFocus = '{$cloneFocus}',
                    cloneRight = '{$cloneRight}';
                var none = '<span style="white-space:pre-wrap;"> </span>';
                var div = elem[cloneDiv] || document.createElement('div'),
                    focus = elem[cloneFocus] || document.createElement('span');
                var text = elem[cloneLeft] || document.createElement('span');
                var offset = that._offset(elem), index = this._getFocus(elem), focusOffset = {left: 0, top: 0};
                if (!elem[cloneDiv]) {
                    elem[cloneDiv] = div, elem[cloneFocus] = focus;
                    elem[cloneLeft] = text;
                    div.appendChild(text);
                    div.appendChild(focus);
                    document.body.appendChild(div);
                    focus.innerHTML = '|';
                    focus.style.cssText = 'display:inline-block;width:0px;overflow:hidden;z-index:-100;word-wrap:break-word;word-break:break-all;';
                    div.className = this._cloneStyle(elem);
                    div.style.cssText = 'visibility:hidden;display:inline-block;position:absolute;z-index:-100;word-wrap:break-word;word-break:break-all;overflow:hidden;';
                }
                ;div.style.left = this._offset(elem).left + "px";
                div.style.top = this._offset(elem).top + "px";
                var strTmp = elem.value.substring(0, index).replace(/</g, '<').replace(/>/g, '>').replace(/\n/g, '<br/>').replace(/\s/g, none);
                text.innerHTML = strTmp;
                focus.style.display = 'inline-block';
                try {
                    focusOffset = this._offset(focus);
                } catch (e) {
                }
                ;focus.style.display = 'none';
                return {left: focusOffset.left, top: focusOffset.top, bottom: focusOffset.bottom};
            }
        }, _cloneStyle: function (elem, cache) {
            if (!cache && elem['${cloneName}']) return elem['${cloneName}'];
            var className, name, rstyle = /^(number|string)$/;
            var rname = /^(content|outline|outlineWidth)$/;
            var cssText = [], sStyle = elem.style;
            for (name in sStyle) {
                if (!rname.test(name)) {
                    val = this._getStyle(elem, name);
                    if (val !== '' && rstyle.test(typeof val)) {
                        name = name.replace(/([A-Z])/g, "-$1").toLowerCase();
                        cssText.push(name);
                        cssText.push(':');
                        cssText.push(val);
                        cssText.push(';');
                    }
                    ;
                }
                ;
            }
            ;cssText = cssText.join('');
            elem['${cloneName}'] = className = 'clone' + (new Date).getTime();
            this._addHeadStyle('.' + className + '{' + cssText + '}');
            return className;
        }, _addHeadStyle: function (content) {
            var style = this._style[document];
            if (!style) {
                style = this._style[document] = document.createElement('style');
                document.getElementsByTagName('head')[0].appendChild(style);
            }
            ;style.styleSheet && (style.styleSheet.cssText += content) || style.appendChild(document.createTextNode(content));
        }, _style: {}, _getStyle: 'getComputedStyle' in window ? function (elem, name) {
            return getComputedStyle(elem, null)[name];
        } : function (elem, name) {
            return elem.currentStyle[name];
        }, _getFocus: function (elem) {
            var index = 0;
            if (document.selection) {
                elem.focus();
                var Sel = document.selection.createRange();
                if (elem.nodeName === 'TEXTAREA') {
                    var Sel2 = Sel.duplicate();
                    Sel2.moveToElementText(elem);
                    var index = -1;
                    while (Sel2.inRange(Sel)) {
                        Sel2.moveStart('character');
                        index++;
                    }
                    ;
                } else if (elem.nodeName === 'INPUT') {
                    Sel.moveStart('character', -elem.value.length);
                    index = Sel.text.length;
                }
            } else if (elem.selectionStart || elem.selectionStart == '0') {
                index = elem.selectionStart;
            }
            return (index);
        }, _offset: function (elem) {
            var box = elem.getBoundingClientRect(), doc = elem.ownerDocument, body = doc.body,
                docElem = doc.documentElement;
            var clientTop = docElem.clientTop || body.clientTop || 0,
                clientLeft = docElem.clientLeft || body.clientLeft || 0;
            var top = box.top + (self.pageYOffset || docElem.scrollTop) - clientTop,
                left = box.left + (self.pageXOffset || docElem.scrollLeft) - clientLeft;
            return {left: left, top: top, right: left + box.width, bottom: top + box.height};
        }
    };
    var EditorElem = {
        style_default: "<div class='editor clearfix'>" + "<div class='word_count'></div>" + "<div class='textarea'>" + "<textarea></textarea>" + "</div>" + "<div class='toolbar clearfix'>" + "<div class='insert clearfix'>" + "<a href='javascript:;' class='btn_expression'>&nbsp;</a>" + "<a href='javascript:;' class='btn_picture' style='display:none;'>&nbsp;</a>" + "</div>" + "<div class='choice'>" + "</div>" + "</div>" + "<div class='submit_button'>" + "<input type='submit' value='确定'>" + "</div>" + "</div>",
        choice_share: "<div><input type='checkbox' name='share' value=''>同时分享到我的说说</div>",
        choice_comment: "<div><input type='checkbox' name='comment'>同时发表评论</div>",
        choice_comment_to_source: "<div><input type='checkbox' name='comment_to_source'>同时评论给原文作者</div>",
        expression_box: function () {
            var return_string = "<div class='expression_box box_layer'><div class='box_bg'><div class='arrow'>&nbsp;</div><div class='box'><h3>常用表情<a class='btn_close' href='javascript:;'>&nbsp;</a></h3><div class='list clearfix'>";
            for (var i = 0; i < swu_exp.length; i++) {
                return_string += '<div class="img"><img src="' + swu_exp[i][0] + '" title="' + swu_exp[i][1] + '" alt="' + swu_exp[i][1] + '"/></div>';
            }
            ;return_string += "</div></div></div></div>";
            return return_string;
        },
        picture_box: function () {
            var html = new Array();
            html.push('<div class="picture_box box_layer">');
            html.push('<div class="box_bg">');
            html.push('<div class="arrow">&nbsp;</div>');
            html.push('<div class="box">');
            html.push('<h3>&nbsp;<a class="btn_close" href="javascript:;">&nbsp;</a></h3>');
            html.push('<div class="pb_button clearfix">');
            html.push('<img class="up_img" src="/space/image/add.png" data-origin_src="/space/image/add.png">');
            html.push('<div class="pb_form">');
            html.push('<form action="/space/ajax/upload.php" method="post" enctype="multipart/form-data" target="up_iframe">');
            html.push('<input type="file" name="image"/>');
            html.push('<input type="hidden" name="refresh" value="1"/>');
            html.push('</form>');
            html.push('<iframe src="javascript:;" name="up_iframe" style="display:none;" id="up_iframe"></iframe>');
            html.push('</div>');
            html.push('</div>');
            html.push('<div class="pb_delete">');
            html.push('<a href="javascript:;" action="delete">删除</a>');
            html.push('</div>');
            html.push('</div>');
            html.push('</div>');
            return html.join('');
        }
    }
    var swu_exp = [["/comments/em/shenshou_thumb.gif", "草泥马"], ["/comments/em/horse2_thumb.gif", "神马"], ["/comments/em/fuyun_thumb.gif", "浮云"], ["/comments/em/geili_thumb.gif", "给力"], ["/comments/em/wg_thumb.gif", "围观"], ["/comments/em/vw_thumb.gif", "威武"], ["/comments/em/panda_thumb.gif", "熊猫"], ["/comments/em/rabbit_thumb.gif", "兔子"], ["/comments/em/otm_thumb.gif", "奥特曼"], ["/comments/em/j_thumb.gif", "囧"], ["/comments/em/hufen_thumb.gif", "互粉"], ["/comments/em/liwu_thumb.gif", "礼物"], ["/comments/em/smilea_thumb.gif", "呵呵"], ["/comments/em/tootha_thumb.gif", "嘻嘻"], ["/comments/em/laugh.gif", "哈哈"], ["/comments/em/tza_thumb.gif", "可爱"], ["/comments/em/kl_thumb.gif", "可怜"], ["/comments/em/kbsa_thumb.gif", "挖鼻屎"], ["/comments/em/cj_thumb.gif", "吃惊"], ["/comments/em/shamea_thumb.gif", "害羞"], ["/comments/em/zy_thumb.gif", "挤眼"], ["/comments/em/bz_thumb.gif", "闭嘴"], ["/comments/em/bs2_thumb.gif", "鄙视"], ["/comments/em/lovea_thumb.gif", "爱你"], ["/comments/em/sada_thumb.gif", "泪"], ["/comments/em/heia_thumb.gif", "偷笑"], ["/comments/em/qq_thumb.gif", "亲亲"], ["/comments/em/sb_thumb.gif", "生病"], ["/comments/em/mb_thumb.gif", "太开心"], ["/comments/em/ldln_thumb.gif", "懒得理你"], ["/comments/em/yhh_thumb.gif", "右哼哼"], ["/comments/em/zhh_thumb.gif", "左哼哼"], ["/comments/em/x_thumb.gif", "嘘"], ["/comments/em/cry.gif", "衰"], ["/comments/em/wq_thumb.gif", "委屈"], ["/comments/em/t_thumb.gif", "吐"], ["/comments/em/k_thumb.gif", "打哈欠"], ["/comments/em/bba_thumb.gif", "抱抱"], ["/comments/em/angrya_thumb.gif", "怒"], ["/comments/em/yw_thumb.gif", "疑问"], ["/comments/em/cza_thumb.gif", "馋嘴"], ["/comments/em/88_thumb.gif", "拜拜"], ["/comments/em/sk_thumb.gif", "思考"], ["/comments/em/sweata_thumb.gif", "汗"], ["/comments/em/sleepya_thumb.gif", "困"], ["/comments/em/sleepa_thumb.gif", "睡觉"], ["/comments/em/money_thumb.gif", "钱"], ["/comments/em/sw_thumb.gif", "失望"], ["/comments/em/cool_thumb.gif", "酷"], ["/comments/em/hsa_thumb.gif", "花心"], ["/comments/em/hatea_thumb.gif", "哼"], ["/comments/em/gza_thumb.gif", "鼓掌"], ["/comments/em/dizzya_thumb.gif", "晕"], ["/comments/em/bs_thumb.gif", "悲伤"], ["/comments/em/crazya_thumb.gif", "抓狂"], ["/comments/em/h_thumb.gif", "黑线"], ["/comments/em/yx_thumb.gif", "阴险"], ["/comments/em/nm_thumb.gif", "怒骂"], ["/comments/em/hearta_thumb.gif", "心"], ["/comments/em/unheart.gif", "伤心"], ["/comments/em/pig.gif", "猪头"], ["/comments/em/ok_thumb.gif", "ok"], ["/comments/em/ye_thumb.gif", "耶"], ["/comments/em/good_thumb.gif", "good"], ["/comments/em/no_thumb.gif", "不要"], ["/comments/em/z2_thumb.gif", "赞"], ["/comments/em/come_thumb.gif", "来"], ["/comments/em/sad_thumb.gif", "弱"], ["/comments/em/lazu_thumb.gif", "蜡烛"], ["/comments/em/clock_thumb.gif", "钟"], ["/comments/em/m_thumb.gif", "话筒"], ["/comments/em/cake.gif", "蛋糕"]];
    var Editor = function (parent_elem, param, callback) {
        return new Editor.fn.init(parent_elem, param, callback);
    }
    Editor.fn = Editor.prototype = {
        createElement: function () {
            style = this.param.style;
            var elem = this.elem;
            elem.main = $(EditorElem.style_default);
            elem.main.addClass(style);
            elem.word_count = elem.main.find(".word_count");
            elem.textarea = elem.main.find(".textarea textarea");
            elem.submit = elem.main.find("input[type='submit']");
            elem.choice = elem.main.find(".choice");
            elem.btn_expression = elem.main.find(".btn_expression");
            elem.btn_picture = elem.main.find(".btn_picture");
            elem.expression = null;
            elem.submit.val(this.param.submit_value);
            elem.textarea.attr('placeholder', this.param.placeholder);
            if (this.param.choice_share) {
                elem.choice.append(EditorElem.choice_share);
            }
            if (this.param.choice_comment) {
                elem.choice.append(EditorElem.choice_comment);
            }
            if (this.param.choice_comment_to_source) {
                elem.choice.append(EditorElem.choice_comment_to_source);
            }
            if (this.param.enable_picture) {
                elem.btn_picture.show();
            }
        }, init: function (parent_elem, param, callback) {
            this.elem = {};
            this.param = {
                submit_value: '确定',
                style: 'default_editor',
                placeholder: '',
                choice_share: false,
                choice_comment: false,
                choice_comment_to_source: false,
                max_word: 400,
                enable_picture: false,
                word_count_show_limit: 400
            };
            var self = this;
            for (i in param) {
                this.param[i] = param[i];
            }
            this.createElement();
            parent_elem.append(this.elem.main);
            var elem = self.elem;
            param = self.param;
            var fn = {
                fixTextareaHeight: function () {
                    var ori = elem.textarea.get(0);
                    if (ori.scrollHeight > ori.clientHeight) {
                        elem.textarea.height(ori.scrollHeight - ori.clientHeight + elem.textarea.height());
                    }
                }, showWordLeft: function () {
                    var left_word = param.max_word - elem.textarea.val().length;
                    if (left_word >= 0) {
                        if (left_word <= param.word_count_show_limit) {
                            elem.word_count.attr("class", "word_count").html("还可以输入<span>" + left_word + "</span>字").show();
                        } else {
                            elem.word_count.hide();
                        }
                    } else {
                        elem.word_count.attr("class", "word_count over").html("已超出<span>" + left_word + "</span>字").show();
                    }
                }, setSubmitButtonStyle: function () {
                    var word_length = elem.textarea.val().length;
                    if (word_length >= 0 && word_length <= param.max_word) {
                        elem.submit.attr("class", "");
                    } else {
                        elem.submit.attr("class", "disable");
                    }
                }
            }
            fn.showWordLeft();
            elem.textarea.keyup(function (event) {
                fn.fixTextareaHeight();
                fn.showWordLeft();
                fn.setSubmitButtonStyle();
            });
            elem.textarea.bind("paste", function () {
                fn.fixTextareaHeight();
                fn.showWordLeft();
                fn.setSubmitButtonStyle();
            });
            elem.textarea.focus(function () {
                fn.setSubmitButtonStyle();
                elem.textarea.parent().addClass("focus");
            });
            elem.textarea.blur(function () {
                elem.textarea.parent().removeClass("focus");
            });
            elem.btn_expression.click(function () {
                if (elem.expression) {
                    if (elem.expression.css("display") == "none") {
                        elem.expression.show();
                        space_common.locationBelow(elem.expression.find(".box_bg").show(), elem.btn_expression);
                    } else {
                        elem.expression.hide();
                    }
                } else {
                    elem.expression = $(EditorElem.expression_box());
                    elem.main.append(elem.expression);
                    elem.expression.find(".btn_close").click(function () {
                        elem.expression.hide();
                    });
                    elem.expression.find(".img img").click(function () {
                        TT.add(elem.textarea.get(0), '[' + $(this).attr('title') + ']');
                        elem.expression.hide();
                    })
                    elem.expression.show();
                    space_common.locationBelow(elem.expression.find(".box_bg").show(), elem.btn_expression);
                }
            });
            elem.btn_picture.click(function () {
                if (elem.picture_box) {
                    if (elem.picture_box.css("display") == "none") {
                        elem.picture_box.show();
                        space_common.locationBelow(elem.picture_box.find(".box_bg").show(), elem.btn_picture);
                    } else {
                        elem.expression.hide();
                    }
                } else {
                    elem.picture_box = $(EditorElem.picture_box());
                    elem.main.append(elem.picture_box);
                    window.upcallback = function (id, url) {
                        self.file_id = id;
                        elem.picture_box.find('img').attr('src', url);
                    };
                    elem.picture_box.find(".btn_close").click(function () {
                        elem.picture_box.hide();
                    });
                    elem.picture_box.find("form input[type='file']").change(function () {
                        var now = new Date();
                        elem.picture_box.find("input[name='refresh']").val(now.getTime());
                        elem.picture_box.find("form").submit();
                    });
                    elem.picture_box.find('a[action="delete"]').click(function () {
                        self.file_id = 0;
                        elem.picture_box.find('img').attr('src', elem.picture_box.find('img').data('origin_src'));
                    });
                    elem.picture_box.show();
                    space_common.locationBelow(elem.picture_box.find(".box_bg").show(), elem.btn_picture, 0, 8);
                }
            });
            elem.submit.click(function () {
                if (!elem.submit.hasClass('disable') && !elem.submit.hasClass('submiting')) {
                    callback();
                }
            });
            return self;
        }, enableSubmit: function () {
            this.elem.submit.removeClass('submiting').val(this.param.submit_value);
            return this;
        }, disableSubmit: function () {
            this.elem.submit.addClass('submiting').val('提交中...');
            return this;
        }, disableButton: function () {
            this.elem.submit.removeClass('diabled');
            return this;
        }, enableButton: function () {
            this.elem.submit.addClass('diabled');
        }, val: function () {
            return this.elem.textarea.val();
        }, fileId: function () {
            return parseInt(this.file_id);
        }, setVal: function (value) {
            this.elem.textarea.val(value);
            return this;
        }, insertVal: function (value) {
            this.elem.textarea.val("");
            TT.add(this.elem.textarea.get(0), value);
            return this;
        }, reset: function () {
            this.elem.textarea.val("");
            this.elem.choice.find("input").removeAttr("checked");
            return this;
        }, choice_share: function () {
            return this.elem.choice.find("[name='share']:checked").length;
        }, choice_comment: function () {
            return this.elem.choice.find("[name='comment']:checked").length;
        }, choice_comment_to_source: function () {
            return this.elem.choice.find("[name='comment_to_source']:checked").length;
        }, focus: function () {
            this.elem.textarea.focus();
            return this;
        }
    }
    Editor.fn.init.prototype = Editor.prototype;
    window.Editor = Editor;
})();
;
/* EgpM2.js */
(function () {
    var TT = {
        getCursorPosition: function (t) {
            if (document.selection) {
                t.focus();
                var ds = document.selection;
                var range = ds.createRange();
                var stored_range = range.duplicate();
                stored_range.moveToElementText(t);
                stored_range.setEndPoint("EndToEnd", range);
                t.selectionStart = stored_range.text.length - range.text.length;
                t.selectionEnd = t.selectionStart + range.text.length;
                return t.selectionStart;
            } else {
                return t.selectionStart;
            }
        }, setCursorPosition: function (t, p) {
            this.sel(t, p, p);
        }, add: function (t, txt) {
            var val = t.value;
            if (document.selection) {
                t.focus();
                document.selection.createRange().text = txt;
            } else {
                var cp = t.selectionStart;
                var ubbLength = t.value.length;
                var s = t.scrollTop;
                t.value = t.value.slice(0, t.selectionStart) + txt + t.value.slice(t.selectionStart, ubbLength);
                this.setCursorPosition(t, cp + txt.length);
                firefox = navigator.userAgent.toLowerCase().match(/firefox\/([\d\.]+)/) && setTimeout(function () {
                    if (t.scrollTop != s)
                        t.scrollTop = s;
                }, 0);
            }
            ;
        }, del: function (t, n) {
            var p = this.getCursorPosition(t);
            var s = t.scrollTop;
            var val = t.value;
            t.value = n > 0 ? val.slice(0, p - n) + val.slice(p) : val.slice(0, p) + val.slice(p - n);
            this.setCursorPosition(t, p - (n < 0 ? 0 : n));
            firefox = navigator.userAgent.toLowerCase().match(/firefox\/([\d\.]+)/) && setTimeout(function () {
                if (t.scrollTop != s)
                    t.scrollTop = s;
            }, 10);
        }, sel: function (t, s, z) {
            if (document.selection) {
                var range = t.createTextRange();
                range.moveEnd('character', -t.value.length);
                range.moveEnd('character', z);
                range.moveStart('character', s);
                range.select();
            } else {
                t.setSelectionRange(s, z);
                t.focus();
            }
        }, selString: function (t, s) {
            var index = t.value.indexOf(s);
            index != -1 ? this.sel(t, index, index + s.length) : false;
        }
    };
    $(document).ready(function () {
        $('#sh_modify_signature').click(function (event) {
            if (!$(event.target).hasClass('sh_modify')) {
                return false;
            }
            $('#sh_modify_signature').hide();
            $('#sh_modify_signature_area').show();
            $('#sh_modify_brief').show();
            $('#sh_modify_brief_area').hide();
            $('#sh_modify_signature_area input[type="text"]').focus();
        });
        $('#sh_modify_signature_area input[type="text"]').bind('keyup', function (event) {
            if (event.keyCode == 13) {
                modifySignature();
            }
        }).bind('blur', function () {
            setTimeout(function () {
                $('#sh_modify_signature').show();
                $('#sh_modify_signature_area').hide();
            }, 200);
        });
        $('#sh_modify_signature_area').find('.sh_modify_save').click(function () {
            modifySignature();
        });
        $('#sh_modify_signature_area input[type="text"]').keyup(function () {
            var value = $('#sh_modify_signature_area input[type="text"]').val();
            if (value.length > 30) {
                $('#sh_modify_signature_area input[type="text"]').val(value.substr(0, 30));
            }
        });

        function modifySignature() {
            var data = {};
            data.action = 'signature';
            data.content = $('#sh_modify_signature_area input[type="text"]').val();
            space_common.post('/uc/ajax/user_modify.php', data, function (res) {
                var btn_text = '<span class="sh_modify"><span>&nbsp;</span>修改</span>';
                if (res.sign == '') {
                    btn_text = '<span class="sh_modify sh_m_show"><span>&nbsp;</span>编辑个人签名</span>';
                }
                $('#sh_modify_signature .sh_dl_content').html(res.sign + btn_text + '');
                $('#sh_modify_signature').show();
                $('#sh_modify_signature_area').hide();
            });
        }

        $('#sh_modify_brief').click(function (event) {
            if (!$(event.target).hasClass('sh_modify')) {
                return false;
            }
            $('#sh_modify_brief').hide();
            $('#sh_modify_brief_area').show();
            $('#sh_modify_signature').show();
            $('#sh_modify_signature_area').hide();
            $('#sh_modify_brief_area textarea').focus();
            TT.setCursorPosition($('#sh_modify_brief_area textarea').get(0), 10000);
            var value = $('#sh_modify_brief_area textarea').val();
            if (value.length > 100) {
                value = value.substr(0, 100);
                $('#sh_modify_brief_area textarea').val(value);
            }
            $('#sh_modify_brief_number').html(value.length + '/' + 100);
        });
        $('#sh_modify_brief_area textarea').keyup(function (event) {
            if (event.keyCode == 13) {
                modifyBrief();
            }
        }).bind('blur', function () {
            setTimeout(function () {
                $('#sh_modify_brief').show();
                $('#sh_modify_brief_area').hide();
            }, 200);
        });
        $('#sh_modify_brief_area').find('.sh_modify_save').click(function () {
            modifyBrief();
        });
        $('#sh_modify_brief_area textarea').keyup(function () {
            var value = $('#sh_modify_brief_area textarea').val();
            if (value.length > 100) {
                value = value.substr(0, 100);
                $('#sh_modify_brief_area textarea').val(value);
            }
            $('#sh_modify_brief_number').html(value.length + '/' + 100);
        }).keypress(function (event) {
            if (event.keyCode == 13) {
                event.preventDefault();
            }
        });

        function modifyBrief() {
            var data = {};
            data.action = 'brief';
            data.content = $('#sh_modify_brief_area textarea').val();
            space_common.post('/uc/ajax/user_modify.php', data, function (res) {
                var btn_text = '<span class="sh_modify" ><span>&nbsp;</span>修改</span>';
                if (res.brief == '') {
                    btn_text = '<span class="sh_modify sh_m_show" ><span>&nbsp;</span>编辑个人简介</span>';
                }
                $('#sh_modify_brief .sh_dl_content').html(res.brief + btn_text);
                $('#sh_modify_brief').show();
                $('#sh_modify_brief_area').hide();
            });
        }

        var bg_box = null;
        $('#sh_btn_space_image').click(function () {
            if (bg_box == null) {
                createImageBox();
            }
            space_common.locationCenter(bg_box.find('.box_bg').show(), 10, 0);
            bg_box.show();
        });

        function createImageBox() {
            var list_1 = [{'id': 1, 'file': 'default.jpg', 'name': '默认'}, {
                'id': 2,
                'file': 'sky.png',
                'name': '灿烂星空'
            }, {'id': 3, 'file': 'grass.png', 'name': '草地'}, {'id': 4, 'file': 'pinwheel.png', 'name': '大风车'}, {
                'id': 5,
                'file': 'straw.png',
                'name': '稻草人'
            }, {'id': 6, 'file': 'snow.png', 'name': '冬日大雪'}, {
                'id': 7,
                'file': 'castles.png',
                'name': '空中城堡'
            }, {'id': 8, 'file': 'tree.png', 'name': '快乐之数'}];
            var list_2 = [{'id': 9, 'file': 'butterfly.png', 'name': '美丽蝴蝶'}, {
                'id': 10,
                'file': 'grape.png',
                'name': '葡萄'
            }, {'id': 11, 'file': 'rainbow.png', 'name': '七色彩虹'}, {'id': 12, 'file': 'autumn.png', 'name': '绚烂深秋'}];
            var html = new Array();
            html.push("<div class='sh_image_box box_layer'>");
            html.push("<div class='box_cover'></div>");
            html.push("<div class='box_bg'>");
            html.push("<div class='box'>");
            html.push("<h2>封面模版<a href='javascript:;' class='btn_close'></a></h2>");
            html.push("<div class='sh_ib_main'>");
            html.push('<ul class="sh_ib_list clearfix" id="shib_page_area_1">');
            var current_id = $('#sh_space_image').data('id');
            for (var i in list_1) {
                var is_selected = '';
                if (current_id == list_1[i]['id']) {
                    is_selected = 'selected';
                }
                html.push('<li class="' + is_selected + '"><img src="http://www.dddd.com:8080/xiaoyu_pc/images/' + list_1[i]['file'] + '" data-id="' + list_1[i]['id'] + '"/><div>' + list_1[i]['name'] + '</div></li>');
            }
            html.push('</ul>');
            html.push('<ul class="sh_ib_list clearfix" id="shib_page_area_2" style="display:none;">');
            for (var i in list_2) {
                var is_selected = '';
                if (current_id == i) {
                    is_selected = 'selected';
                }
                html.push('<li class="' + is_selected + '"><img src="http://www.dddd.com:8080/xiaoyu_pc/images/' + list_2[i]['file'] + '" data-id="' + list_2[i]['id'] + '"/><div>' + list_2[i]['name'] + '</div></li>');
            }
            html.push('</ul>');
            html.push('<div class="sh_ib_page"><a href="javascript:;" class="selected" id="shib_page_1">1</a><a href="javascript:;" id="shib_page_2">2</a></div>')
            html.push("<div class='action'><a class='cancel' href='javascript:;'>取消</a><a class='confirm' href='javascript:;'>确定</a></div>")
            html.push('</div>');
            html.push("</div>");
            html.push("</div>");
            html.push("</div>");
            bg_box = $(html.join(''));
            var sh_image = $('#sh_space_image');
            bg_box.find('a.btn_close').click(function () {
                bg_box.hide();
                sh_image.attr('src', sh_image.data('origin_src'));
            });
            bg_box.find('a.cancel').click(function () {
                bg_box.hide();
                sh_image.attr('src', sh_image.data('origin_src'));
            });
            bg_box.find("li").click(function () {
                bg_box.find("li").removeClass('selected');
                sh_image.attr('src', $(this).addClass('selected').find('img').attr('src'));
            });
            $("body").append(bg_box);
            bg_box.find('a.confirm').click(function () {
                var data = {};
                data.action = 'header_bg';
                data.id = bg_box.find("li.selected img").data('id');
                if (!data.id) {
                    return false;
                }
                space_common.post('/uc/ajax/user_modify.php', data, function () {
                    sh_image.data('origin_src', sh_image.attr('src'));
                    bg_box.hide();
                });
            });
            var page_1 = $('#shib_page_1');
            var page_2 = $('#shib_page_2');
            var pagearea_1 = $('#shib_page_area_1');
            var pagearea_2 = $('#shib_page_area_2');
            page_1.click(function () {
                pagearea_1.show();
                pagearea_2.hide();
            });
            page_2.click(function () {
                page_1.removeClass('selected');
                page_2.addClass('selected');
                pagearea_1.hide();
                pagearea_2.show();
            });
        }
    });
})();
;
/* s0SPE.js */
(function () {
    $(document).ready(function () {
        $(".follow_button").each(function () {
            bindAction($(this));
        });

        function bindAction(t) {
            t.find('a[action]').click(function () {
                var e = $(this);
                var data = {};
                data.host_uid = t.data('uid');
                data.action = e.attr('action');
                var sendRequest = function () {
                    space_common.post('/uc/ajax/space_follow_button_action.php', data, function (res) {
                        space_common.showmsg(msg_type + '成功');
                        var new_follow_button = $(demo(res.follow_status, data.host_uid, t.data('nickname')));
                        t.before(new_follow_button);
                        t.remove();
                        bindAction(new_follow_button);
                    }, function () {
                        space_common.showmsg(msg_type + '失败', "error");
                    });
                }
                if (data.action == 'dofollow') {
                    msg_type = '关注';
                    sendRequest();
                }
                else if (data.action == 'unfollow') {
                    msg_type = '取消关注';
                    space_common.confirm("提示", "确定要取消对" + t.data('nickname') + "的关注吗?", sendRequest);
                }
            });
        }
    });
    var demo = function (status, uid, nickname) {
        switch (status) {
            case 0: {
                return "<div item='follow_status' data-uid='" + uid + "' data-nickname='" + nickname + "' class='follow_button dofollow'><a action='dofollow' href='javascript:'>关注</a></div>";
            }
                ;
            case 1: {
                return "<div item='follow_status' data-uid='" + uid + "' data-nickname='" + nickname + "'  class='follow_button dofollow'><a action='dofollow' href='javascript:'>关注</a></div>";
            }
                ;
            case 2: {
                return "<div item='follow_status' data-uid='" + uid + "' data-nickname='" + nickname + "'  class='follow_button alerady_follow'><span>已关注</span><span class='sep'>|</span><a action='unfollow' class='cancel' href='javascript:;'>取消</a></div>";
            }
                ;
            case 3: {
                return "<div item='follow_status' data-uid='" + uid + "' data-nickname='" + nickname + "'  class='follow_button all_follow'><span>互相关注</span><span class='sep'>|</span><a action='unfollow' class='cancel' href='javascript:;'>取消</a></div>";
            }
                ;
            default: {
                break;
            }
        }
    }
})();