$(function () {

    $("#gopay").on('click', function () {

        var kec = $("#shop_title").attr("data-title"); //课程名称
        // var order = parseFloat($("#order").attr("data-order")); //原价
        // var amount = parseFloat($("#amount").attr("data-amount")); //折扣价
        var relcost = parseFloat($("#relcost").html()); //实付款
        var paytype = $("#paytype").html(); //付款类型

        var disId = 10;//测试

        $("#gopay").html("正在跳转...");


        if (paytype === "WEIXIN") {
            //去付款-微信支付
            gopay(parseInt(courseId), parseInt(Kid), parseInt(disId), paytype, relcost, kec);

        } else if (paytype === "ALIPAY") {

            window.location.href = "./alipay.php?do=ALIPAY&courseId=" + courseId + "&Kid=" + Kid + "&kec=" + kec;

        }


    });


    $("#freequan").on("change", function () {

        var amount = parseFloat($("#amount").attr("data-amount")); //折扣价
        var free_cost = parseFloat($(this).children('option:selected').val());
        // $("#relcost").attr("data-relcost",parseFloat(amount*free_cost));
        $("#relcost").html(parseFloat(amount * free_cost));

    });


    /**
     *
     * @param amount
     * @param kec
     * @param order_id
     * @param requestId
     */
    function gopay2(amount, kec, order_id, requestId) {

        window.location.href = "http://www.91xiaoyu.com/payAct/weixinpay/QRcode/native.php?amount=" + amount + "&kec=" + kec + "&order_id=" + order_id + "&requestId=" + requestId;

    }


    /**
     *
     * @param courseId
     * @param Kid
     * @param disId
     * @param paytype
     * @param relcost
     * @param kec
     */
    function gopay(courseId, Kid, disId, paytype, relcost, kec) {
        $.ajax({

            type: "POST",
            url: "./RESTApi/gopay.php",
            data: {
                do: "payAct",
                courseId: courseId,
                Kid: Kid,
                disId: disId,
                paytype: paytype,
                relcost: relcost,
                kec: kec
            },
            datatype: "json",

            beforeSend: function (XMLHttpRequest) {
                //todo
            },

            success: function (data) {

                var jsondata = $.parseJSON(data);

                console.log(jsondata);

                if (jsondata.code === 0) {
                    var amount = jsondata.data.amount;//实际支付
                    // var courseName = jsondata.data.courseName;//订单名称
                    //var createTime = jsondata.data.createTime;//创建时间
                    var requestId = jsondata.data.requestId; //订单号
                    //var studentName = jsondata.data.studentName; //付款人
                    var order_id = jsondata.data.id; //订单id【平台】

                    gopay2(amount, kec, order_id, requestId);

                }


                //todo
            },

            complete: function (XMLHttpRequest, textStatus) {
                //todo
            },

            error: function () {
                //todo
            }
        });

    }


});