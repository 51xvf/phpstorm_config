;
/* 16SkAx.js */

// $(document).ready(function(){$.get('ajax/sign.php');});

;
/* uf7HB.js */
(function () {
    var animates = [];
    var interval = setInterval(function () {
        var now = new Date().getTime();
        for (var i = 0; i < animates.length; i++) {
            var animate_time = now - animates[i].start_time;
            if (animates[i].finished == true) {
                animates.splice(i, 1);
                continue;
            }
            for (var j = animates[i]['actions'].length - 1; j >= 0; j--) {
                var param = animates[i]['actions'][j];
                if (animate_time < param.start || (animate_time - param.start) / param.interval < param.tick)
                    continue;
                param.tick++;
                var is_end = false;
                if (param.last != 0) {
                    var progress = (animate_time - param.start) / param.last;
                    if (progress > 1) {
                        progress = 1;
                        is_end = true;
                    }
                    if (param.func(param.tick, progress) == true) {
                        is_end = true;
                    }
                } else {
                    is_end = param.func(param.tick);
                }
                if (is_end == true) {
                    animates[i]['actions'].splice(j, 1);
                    if (animates[i]['actions'].length <= 0) {
                        animates.splice(i, 1);
                    }
                }
            }
        }
    }, 20);
    window.Animate = function (global_interval) {
        this.actions = [];
        this.finished = false;
        this.start_time = 0;
        var interval_id, start_time, actions = this.actions,
            global_interval = global_interval == undefined ? 20 : global_interval;
        this.start = function () {
            if (this.actions.length <= 0) {
                return false;
            }
            this.start_time = new Date().getTime();
            animates.push(this);
        };
        this.stop = function () {
            this.finished = true;
        };
        this.push = function (func, start, last, interval) {
            actions.push({
                func: func,
                start: start == undefined ? 0 : start,
                last: last == undefined ? 0 : last,
                interval: interval == undefined ? global_interval : interval,
                tick: 0
            });
        };
        this.pushClip = function (clip, start) {
            start = start == undefined ? 0 : start;
            for (var i = clip.actions.length - 1; i >= 0; i--) {
                clip.actions[i].start += start;
                actions.push(clip.actions[i]);
            }
        };
    };
    window.loadImage = function (images, callback) {
        var loading_count = 0;
        for (i in images) {
            loading_count++;
            var src = images[i];
            images[i] = new Image();
            images[i].src = src;
            images[i].onload = function () {
                loading_count--;
                if (loading_count == 0) {
                    typeof callback == 'function' ? callback() : '';
                }
            };
        }
    };
})();
;
/* 6BWrt.js */
(function () {
    try {
        Object.defineProperty({}, 'props', {
            value: function () {
            }
        })
    }
    catch (e) {
        window.g = {};
        (function () {
            g.easing = function (percent, from, to, method) {
                percent = percent > 1 ? 1 : (percent < 0 ? 0 : percent);
                return method(percent) * (to - from) + from;
            };
            g.easing.Quadratic = {
                In: function (k) {
                    return k * k;
                }, Out: function (k) {
                    return k * (2 - k);
                }, InOut: function (k) {
                    if ((k *= 2) < 1)
                        return 0.5 * k * k;
                    return -0.5 * (--k * (k - 2) - 1);
                }
            };
            g.easing.Linear = {
                In: function (k) {
                    return k;
                }, Out: function (k) {
                    return k;
                }
            };
            g.easing.Cubic = {
                In: function (k) {
                    return k * k * k;
                }, Out: function (k) {
                    return --k * k * k + 1;
                }, InOut: function (k) {
                    if ((k *= 2) < 1)
                        return 0.5 * k * k * k;
                    return 0.5 * ((k -= 2) * k * k + 2);
                }
            };
            g.easing.Bounce = {
                In: function (k) {
                    return 1 - easing.Bounce.Out(1 - k);
                }, Out: function (k) {
                    if (k < (1 / 2.75)) {
                        return 7.5625 * k * k;
                    } else if (k < (2 / 2.75)) {
                        return 7.5625 * (k -= (1.5 / 2.75)) * k + 0.75;
                    } else if (k < (2.5 / 2.75)) {
                        return 7.5625 * (k -= (2.25 / 2.75)) * k + 0.9375;
                    } else {
                        return 7.5625 * (k -= (2.625 / 2.75)) * k + 0.984375;
                    }
                }, InOut: function (k) {
                    if (k < 0.5)
                        return easing.Bounce.In(k * 2) * 0.5;
                    return easing.Bounce.Out(k * 2 - 1) * 0.5 + 0.5;
                }
            };
            g.easing.Elastic = {
                In: function (k) {
                    var s, a = 0.1, p = 0.4;
                    if (k === 0) return 0;
                    if (k === 1) return 1;
                    if (!a || a < 1) {
                        a = 1;
                        s = p / 4;
                    }
                    else s = p * Math.asin(1 / a) / (2 * Math.PI);
                    return -(a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
                }, Out: function (k) {
                    var s, a = 0.1, p = 0.4;
                    if (k === 0) return 0;
                    if (k === 1) return 1;
                    if (!a || a < 1) {
                        a = 1;
                        s = p / 4;
                    }
                    else s = p * Math.asin(1 / a) / (2 * Math.PI);
                    return (a * Math.pow(2, -10 * k) * Math.sin((k - s) * (2 * Math.PI) / p) + 1);
                }, InOut: function (k) {
                    var s, a = 0.1, p = 0.4;
                    if (k === 0) return 0;
                    if (k === 1) return 1;
                    if (!a || a < 1) {
                        a = 1;
                        s = p / 4;
                    }
                    else s = p * Math.asin(1 / a) / (2 * Math.PI);
                    if ((k *= 2) < 1) return -0.5 * (a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
                    return a * Math.pow(2, -10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p) * 0.5 + 1;
                }
            };
        })();
        (function () {
            g.m = new function () {
                var objects = {};

                function get(e) {
                    if (objects[e] == null)
                        objects[e] = [];
                    return objects[e];
                }

                this.listen = function (e, callback) {
                    if (e == null)
                        get("*").push({callback: callback}); else if (typeof(e) == "array") {
                        for (var i = 0; i < e.length; i++)
                            get(e[i]).push({callback: callback});
                    }
                    else {
                        get(e).push({callback: callback});
                    }
                    return this;
                }
                this.remove = function (e, callback) {
                    for (var evt in objects) {
                        if (evt == e || e == undefined) {
                            for (var i = 0; i < objects[evt].length; i++) {
                                if (objects[evt][i].callback == callback) {
                                    objects[evt].splice(i, 1);
                                    break;
                                }
                            }
                        }
                    }
                    return this;
                }
                this.send = function (e, args) {
                    var i, j;
                    var controls = get(e);
                    for (var i = 0; i < controls.length; i++) {
                        if (controls[i].callback(args) == true)
                            return this;
                    }
                    controls = get("*");
                    for (var i = 0; i < controls.length; i++) {
                        if (controls[i].callback(args) == true)
                            break;
                    }
                    return this;
                }
            };
        })();
        return;
    }
    Object.getPrototypeOf = Object.getPrototypeOf || function (obj) {
        return obj.__proto__;
    };
    Object.setPrototypeOf = Object.setPrototypeOf || function (obj, prototype) {
        obj.__proto__ = prototype;
        return obj;
    };
    if (!Object.defineProperty) {
        Object.defineProperty = function (obj, prop, desc) {
            if (obj.__defineGetter__) {
                if (desc.get) {
                    obj.__defineGetter__(prop, desc.get);
                }
                if (desc.set) {
                    obj.__defineSetter__(prop, desc.set);
                }
            } else {
                throw new TypeError("Object.defineProperty not supported");
            }
        };
    }
    if (typeof Object.create !== "function") {
        Object.create = function (o) {
            var Fn = function () {
            };
            Fn.prototype = o;
            return new Fn();
        };
    }
    if (!Function.prototype.bind) {
        var Empty = function () {
        };
        Function.prototype.bind = function bind(that) {
            var target = this;
            if (typeof target !== "function") {
                throw new TypeError("Function.prototype.bind called on incompatible " + target);
            }
            var args = Array.prototype.slice.call(arguments, 1);
            var bound = function () {
                if (this instanceof bound) {
                    var result = target.apply(this, args.concat(Array.prototype.slice.call(arguments)));
                    if (Object(result) === result) {
                        return result;
                    }
                    return this;
                } else {
                    return target.apply(that, args.concat(Array.prototype.slice.call(arguments)));
                }
            };
            if (target.prototype) {
                Empty.prototype = target.prototype;
                bound.prototype = new Empty();
                Empty.prototype = null;
            }
            return bound;
        };
    }
    (function () {
        Object.defineProperty(Object.prototype, "extend", {
            "value": function () {
                var methods = {};
                var mixins = Array.prototype.slice.call(arguments, 0);

                function Class() {
                    this.init.apply(this, arguments);
                    return this;
                }

                Class.prototype = Object.create(this.prototype);
                mixins.forEach(function (mixin) {
                    apply_methods(Class, methods, mixin.__methods__ || mixin);
                });
                if (!("init" in Class.prototype)) {
                    throw new TypeError("extend: Class is missing a constructor named `init`");
                }
                Object.defineProperty(Class.prototype, "_super", {"value": _super});
                Object.defineProperty(Class, "__methods__", {"value": methods});
                return Class;
            }
        });

        function apply_methods(Class, methods, descriptor) {
            Object.keys(descriptor).forEach(function (method) {
                methods[method] = descriptor[method];
                if (typeof(descriptor[method]) !== "function") {
                    throw new TypeError("extend: Method `" + method + "` is not a function");
                }
                Object.defineProperty(Class.prototype, method, {"configurable": true, "value": descriptor[method]});
            });
        }

        function _super(superClass, method, args) {
            return superClass.prototype[method].apply(this, args);
        }
    })();
    Math.rand = function (min, max) {
        return Math.random() * (max - min) + min;
    };
    Number.prototype.clamp = function (low, high) {
        return this < low ? low : this > high ? high : +this;
    };
    window.requestAnimationFrame = (function () {
        return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || function (callback) {
            return window.setTimeout(callback, 1000 / 60);
        };
    })();
    window.cancelAnimationFrame = (function () {
        return window.cancelAnimationFrame || window.webkitCancelAnimationFrame || window.mozCancelAnimationFrame || window.oCancelAnimationFrame || function (id) {
            window.clearTimeout(id);
        };
    })();
    window.performance = window.performance || {};
    window.performance.now = (function () {
        if (window.performance && window.performance.now)
            return window.performance.now.bind(window.performance); else if (Date.now)
            return Date.now.bind(Date); else
            return function () {
                return (new Date()).getTime();
            }
    })();
    Function.prototype.defer = function () {
        return setTimeout(this.bind.apply(this, arguments), 0.01);
    };
    window.g = window.g || {
        world: null, pool: null, views: [], isInit: false, init: function () {
            if (this.isInit)
                return true;
            this.clock = 0;
            this.error = null;
            var self = this;
            var lastTime = ~~window.performance.now();

            function loop() {
                try {
                    var now = ~~window.performance.now();
                    var dt = now - lastTime;
                    lastTime = now;
                    self.update(dt);
                } catch (e) {
                    if (this.error == null) {
                        this.error = e;
                        console.error(e.stack);
                    }
                }
                window.requestAnimationFrame(loop);
            }

            loop();
            this.isInit = true;
        }, initView: function (mixValue, width, height, initEvent) {
            g.view = new g.TheView(mixValue, width, height);
            this.views.push(g.view);
            g.world = g.view.world;
            if (initEvent !== false) {
                g.event.init(g.view.canvas);
            }
            return g.view;
        }, addView: function (mixValue, width, height) {
            var view = new g.TheView(mixValue, width, height);
            this.views.push(view);
            return view;
        }, update: function (dt) {
            this.clock += dt;
            g.timer.update(dt);
            for (var i = 0, len = this.views.length; i < len; i++) {
                this.views[i].update(dt);
                this.views[i].draw();
            }
        }
    };
    g.timer = new (function () {
        var timerId = 0;
        var timers = [];
        var clock = 0;
        this.update = function (dt) {
            for (var i = timers.length - 1; i >= 0; i--) {
                if (timers[i].cleared) {
                    timers.splice(i, 1);
                }
            }
            clock += dt;
            for (var i = timers.length - 1; i >= 0; i--) {
                timers[i].clock += dt;
                if (timers[i].clock >= timers[i].interval) {
                    if (timers[i].isTimeout === false) {
                        timers[i].time += timers[i].clock;
                        timers[i].callback(timers[i].clock, timers[i].time);
                        timers[i].clock -= timers[i].interval;
                    } else {
                        timers[i].callback(timers[i].clock);
                        timers[i].cleared = true;
                    }
                } else if (timers[i].interval == undefined && timers[i].isTimeout === false) {
                    timers[i].time += dt;
                    timers[i].callback(dt, timers[i].time);
                }
            }
        };
        this.setTimeout = function (callback, delay) {
            timers.unshift({
                clock: 0,
                time: 0,
                interval: delay,
                callback: callback,
                timerId: ++timerId,
                isTimeout: true,
                cleared: false
            });
            return timerId;
        };
        this.setInterval = function (callback, duration) {
            timers.unshift({
                clock: 0,
                time: 0,
                nextCallClock: duration,
                interval: duration,
                callback: callback,
                timerId: ++timerId,
                isTimeout: false,
                cleared: false
            });
            return timerId;
        };
        this.clearTimer = function (timerId) {
            for (var i = 0, len = timers.length; i < len; i++) {
                if (timers[i].timerId == timerId) {
                    timers[i].cleared = true;
                    break;
                }
            }
        };
    })();
    g.init();
    g.Font = Object.extend({
        init: function (settings) {
            this.fontWeight = settings.fontWeight || '';
            this.fontStyle = settings.fontStyle || '';
            this.fontSize = parseInt(settings.fontSize, 10);
            this.fontFamily = settings.fontFamily || 'Arial';
            this.color = settings.color || '#000';
            this.lineHeight = settings.lineHeight || 1.0;
            this.textBaseline = settings.textBaseline || 'middle';
            this.size = {x: this.fontSize, y: this.fontSize};
            if (typeof this.fontSize === 'number') {
                this.fontSize += 'px';
            }
            this.font = [this.fontWeight, this.fontStyle, this.fontSize, this.fontFamily].join(' ');
        }, copy: function (settings) {
            var set = {};
            var props = ['fontWeight', 'fontStyle', 'fontSize', 'color', 'fontFamily'];
            for (var i in props) {
                set[props[i]] = settings[props[i]] === undefined ? this[props] : settings[props[i]];
            }
            return new g.Font(settings);
        }, measureText: function (ctx, text) {
            ctx.save();
            ctx.font = this.font;
            ctx.fillStyle = this.color;
            var size = {width: ctx.measureText(text).width, height: this.size * this.lineHeight}
            ctx.restore();
            return size;
        }, draw: function (ctx, text, x, y, textAlign) {
            ctx.font = this.font;
            ctx.fillStyle = this.color;
            ctx.textAlign = textAlign == undefined ? 'left' : textAlign;
            ctx.textBaseline = this.textBaseline;
            var strings = ('' + text).split("\n");
            for (var i = 0; i < strings.length; i++) {
                ctx.fillText(strings[i], ~~x, ~~(y + this.size.y * this.lineHeight / 2));
                y += this.size.y * this.lineHeight;
            }
        }
    });
    g.BitmapFont = g.Font.extend({
        init: function (settings) {
            this._super(g.Font, 'init', [settings]);
            var scale = settings.scale || 1;
            this.fontSize = settings.fontSize;
            this.firstChar = settings.firstChar || 0x20;
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.loadFontMetrics(settings.image, settings.fontSize, settings.charCount);
            if (scale != 1) {
                this.size.x = ~~(this.size.x * scale);
                this.size.y = ~~(this.size.y * scale);
            }
            this.textBaseline = 'top';
        }, loadFontMetrics: function (image, size, charCount) {
            this.fontSize.x = size.x || size;
            this.fontSize.y = size.y || this.font.height;
            this.size.x = this.fontSize.x;
            this.size.y = this.fontSize.y;
            this.height = this.size.y;
            this.charCount = charCount || ~~(image.width / this.fontSize.x);
        }, measureText: function (ctx, text) {
            var strings = ('' + text).split("\n");
            this.height = this.width = 0;
            for (var i = 0; i < strings.length; i++) {
                this.width = (strings[i].length * this.size.x) > this.width ? (strings[i].length * this.size.x) : this.width;
                this.height += this.size.y * this.lineHeight;
            }
            return {width: this.width, height: this.height};
        }, draw: function (ctx, text, x, y, textAlign) {
            var strings = ("" + text).split("\n");
            var lX = x;
            var height = this.size.y * this.lineHeight;
            for (var i = 0; i < strings.length; i++) {
                x = lX;
                var string = strings[i];
                var width = string.length * this.size.x;
                if (textAlign == 'right')
                    x -= width; else if (textAlign == 'center')
                    x -= width * 0.5;
                switch (this.textBaseline) {
                    case"middle":
                        y -= height * 0.5;
                        break;
                    case"ideographic":
                    case"alphabetic":
                    case"bottom":
                        y -= height;
                        break;
                    default:
                        break;
                }
                for (var c = 0, len = string.length; c < len; c++) {
                    var idx = string.charCodeAt(c) - this.firstChar;
                    if (idx >= 0) {
                        ctx.drawImage(this.image, this.sx + this.fontSize.x * (idx % this.charCount), this.sy + this.fontSize.y * ~~(idx / this.charCodeAtunt), this.fontSize.x, this.fontSize.y, ~~x, ~~y, this.size.x, this.size.y);
                    }
                    x += this.size.x;
                }
                y += height;
            }
        }
    });
    (function () {
        var cache = {};
        var ctx = null, usingWebAudio = true, noAudio = false;
        try {
            if (typeof AudioContext !== 'undefined') {
                ctx = new AudioContext();
            } else if (typeof webkitAudioContext !== 'undefined') {
                ctx = new webkitAudioContext();
            } else {
                usingWebAudio = false;
            }
        } catch (e) {
            usingWebAudio = false;
        }
        if (!usingWebAudio) {
            if (typeof Audio !== 'undefined') {
                try {
                    new Audio();
                } catch (e) {
                    noAudio = true;
                }
            } else {
                noAudio = true;
            }
        }
        if (usingWebAudio) {
            var masterGain = (typeof ctx.createGain === 'undefined') ? ctx.createGainNode() : ctx.createGain();
            masterGain.gain.value = 1;
            masterGain.connect(ctx.destination);
        }
        var HowlerGlobal = function (codecs) {
            this._volume = 1;
            this._muted = false;
            this.usingWebAudio = usingWebAudio;
            this.ctx = ctx;
            this.noAudio = noAudio;
            this._howls = [];
            this._codecs = codecs;
            this.iOSAutoEnable = true;
        };
        HowlerGlobal.prototype = {
            volume: function (vol) {
                var self = this;
                vol = parseFloat(vol);
                if (vol >= 0 && vol <= 1) {
                    self._volume = vol;
                    if (usingWebAudio) {
                        masterGain.gain.value = vol;
                    }
                    for (var key in self._howls) {
                        if (self._howls.hasOwnProperty(key) && self._howls[key]._webAudio === false) {
                            for (var i = 0; i < self._howls[key]._audioNode.length; i++) {
                                self._howls[key]._audioNode[i].volume = self._howls[key]._volume * self._volume;
                            }
                        }
                    }
                    return self;
                }
                return (usingWebAudio) ? masterGain.gain.value : self._volume;
            }, mute: function () {
                this._setMuted(true);
                return this;
            }, unmute: function () {
                this._setMuted(false);
                return this;
            }, _setMuted: function (muted) {
                var self = this;
                self._muted = muted;
                if (usingWebAudio) {
                    masterGain.gain.value = muted ? 0 : self._volume;
                }
                for (var key in self._howls) {
                    if (self._howls.hasOwnProperty(key) && self._howls[key]._webAudio === false) {
                        for (var i = 0; i < self._howls[key]._audioNode.length; i++) {
                            self._howls[key]._audioNode[i].muted = muted;
                        }
                    }
                }
            }, codecs: function (ext) {
                return this._codecs[ext];
            }, _enableiOSAudio: function () {
                var self = this;
                if (ctx && (self._iOSEnabled || !/iPhone|iPad|iPod/i.test(navigator.userAgent))) {
                    return;
                }
                self._iOSEnabled = false;
                var unlock = function () {
                    var buffer = ctx.createBuffer(1, 1, 22050);
                    var source = ctx.createBufferSource();
                    source.buffer = buffer;
                    source.connect(ctx.destination);
                    if (typeof source.start === 'undefined') {
                        source.noteOn(0);
                    } else {
                        source.start(0);
                    }
                    setTimeout(function () {
                        if ((source.playbackState === source.PLAYING_STATE || source.playbackState === source.FINISHED_STATE)) {
                            self._iOSEnabled = true;
                            self.iOSAutoEnable = false;
                            window.removeEventListener('touchstart', unlock, false);
                        }
                    }, 0);
                };
                window.addEventListener('touchstart', unlock, false);
                return self;
            }
        };
        var audioTest = null;
        var codecs = {};
        if (!noAudio) {
            audioTest = new Audio();
            codecs = {
                mp3: !!audioTest.canPlayType('audio/mpeg;').replace(/^no$/, ''),
                opus: !!audioTest.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/, ''),
                ogg: !!audioTest.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ''),
                wav: !!audioTest.canPlayType('audio/wav; codecs="1"').replace(/^no$/, ''),
                aac: !!audioTest.canPlayType('audio/aac;').replace(/^no$/, ''),
                m4a: !!(audioTest.canPlayType('audio/x-m4a;') || audioTest.canPlayType('audio/m4a;') || audioTest.canPlayType('audio/aac;')).replace(/^no$/, ''),
                mp4: !!(audioTest.canPlayType('audio/x-mp4;') || audioTest.canPlayType('audio/mp4;') || audioTest.canPlayType('audio/aac;')).replace(/^no$/, ''),
                weba: !!audioTest.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, '')
            };
        }
        var Howler = new HowlerGlobal(codecs);
        var Howl = function (o) {
            var self = this;
            self._autoplay = o.autoplay || false;
            self._buffer = o.buffer || false;
            self._duration = o.duration || 0;
            self._format = o.format || null;
            self._loop = o.loop || false;
            self._loaded = false;
            self._sprite = o.sprite || {};
            self._src = o.src || '';
            self._pos3d = o.pos3d || [0, 0, -0.5];
            self._volume = o.volume !== undefined ? o.volume : 1;
            self._urls = o.urls || [];
            self._rate = o.rate || 1;
            self._model = o.model || null;
            self._onload = [o.onload || function () {
            }];
            self._onloaderror = [o.onloaderror || function () {
            }];
            self._onend = [o.onend || function () {
            }];
            self._onpause = [o.onpause || function () {
            }];
            self._onplay = [o.onplay || function () {
            }];
            self._onendTimer = [];
            self._webAudio = usingWebAudio && !self._buffer;
            self._audioNode = [];
            if (self._webAudio) {
                self._setupAudioNode();
            }
            if (typeof ctx !== 'undefined' && ctx && Howler.iOSAutoEnable) {
                Howler._enableiOSAudio();
            }
            Howler._howls.push(self);
            self.load();
        };
        Howl.prototype = {
            load: function () {
                var self = this, url = null;
                if (noAudio) {
                    self.on('loaderror');
                    return;
                }
                for (var i = 0; i < self._urls.length; i++) {
                    var ext, urlItem;
                    if (self._format) {
                        ext = self._format;
                    } else {
                        urlItem = self._urls[i];
                        ext = /^data:audio\/([^;,]+);/i.exec(urlItem);
                        if (!ext) {
                            ext = /\.([^.]+)$/.exec(urlItem.split('?', 1)[0]);
                        }
                        if (ext) {
                            ext = ext[1].toLowerCase();
                        } else {
                            self.on('loaderror');
                            return;
                        }
                    }
                    if (codecs[ext]) {
                        url = self._urls[i];
                        break;
                    }
                }
                if (!url) {
                    self.on('loaderror');
                    return;
                }
                self._src = url;
                if (self._webAudio) {
                    loadBuffer(self, url);
                } else {
                    var newNode = new Audio();
                    newNode.addEventListener('error', function () {
                        if (newNode.error && newNode.error.code === 4) {
                            HowlerGlobal.noAudio = true;
                        }
                        self.on('loaderror', {type: newNode.error ? newNode.error.code : 0});
                    }, false);
                    self._audioNode.push(newNode);
                    newNode.src = url;
                    newNode._pos = 0;
                    newNode.preload = 'auto';
                    newNode.volume = (Howler._muted) ? 0 : self._volume * Howler.volume();
                    var listener = function () {
                        self._duration = Math.ceil(newNode.duration * 10) / 10;
                        if (Object.getOwnPropertyNames(self._sprite).length === 0) {
                            self._sprite = {_default: [0, self._duration * 1000]};
                        }
                        if (!self._loaded) {
                            self._loaded = true;
                            self.on('load');
                        }
                        if (self._autoplay) {
                            self.play();
                        }
                        newNode.removeEventListener('canplaythrough', listener, false);
                    };
                    newNode.addEventListener('canplaythrough', listener, false);
                    newNode.load();
                }
                return self;
            }, urls: function (urls) {
                var self = this;
                if (urls) {
                    self.stop();
                    self._urls = (typeof urls === 'string') ? [urls] : urls;
                    self._loaded = false;
                    self.load();
                    return self;
                } else {
                    return self._urls;
                }
            }, play: function (sprite, callback) {
                var self = this;
                if (typeof sprite === 'function') {
                    callback = sprite;
                }
                if (!sprite || typeof sprite === 'function') {
                    sprite = '_default';
                }
                if (!self._loaded) {
                    self.on('load', function () {
                        self.play(sprite, callback);
                    });
                    return self;
                }
                if (!self._sprite[sprite]) {
                    if (typeof callback === 'function') callback();
                    return self;
                }
                self._inactiveNode(function (node) {
                    node._sprite = sprite;
                    var pos = (node._pos > 0) ? node._pos : self._sprite[sprite][0] / 1000;
                    var duration = 0;
                    if (self._webAudio) {
                        duration = self._sprite[sprite][1] / 1000 - node._pos;
                        if (node._pos > 0) {
                            pos = self._sprite[sprite][0] / 1000 + pos;
                        }
                    } else {
                        duration = self._sprite[sprite][1] / 1000 - (pos - self._sprite[sprite][0] / 1000);
                    }
                    var loop = !!(self._loop || self._sprite[sprite][2]);
                    var soundId = (typeof callback === 'string') ? callback : Math.round(Date.now() * Math.random()) + '',
                        timerId;
                    (function () {
                        var data = {id: soundId, sprite: sprite, loop: loop};
                        timerId = setTimeout(function () {
                            if (!self._webAudio && loop) {
                                self.stop(data.id).play(sprite, data.id);
                            }
                            if (self._webAudio && !loop) {
                                self._nodeById(data.id).paused = true;
                                self._nodeById(data.id)._pos = 0;
                                self._clearEndTimer(data.id);
                            }
                            if (!self._webAudio && !loop) {
                                self.stop(data.id);
                            }
                            self.on('end', soundId);
                        }, duration * 1000);
                        self._onendTimer.push({timer: timerId, id: data.id});
                    })();
                    if (self._webAudio) {
                        var loopStart = self._sprite[sprite][0] / 1000, loopEnd = self._sprite[sprite][1] / 1000;
                        node.id = soundId;
                        node.paused = false;
                        refreshBuffer(self, [loop, loopStart, loopEnd], soundId);
                        self._playStart = ctx.currentTime;
                        node.gain.value = self._volume;
                        if (typeof node.bufferSource.start === 'undefined') {
                            node.bufferSource.noteGrainOn(0, pos, duration);
                        } else {
                            node.bufferSource.start(0, pos, duration);
                        }
                    } else {
                        if (node.readyState === 4 || !node.readyState && navigator.isCocoonJS) {
                            node.readyState = 4;
                            node.id = soundId;
                            node.currentTime = pos;
                            node.muted = Howler._muted || node.muted;
                            node.volume = self._volume * Howler.volume();
                            setTimeout(function () {
                                node.play();
                            }, 0);
                        } else {
                            self._clearEndTimer(soundId);
                            (function () {
                                var sound = self, playSprite = sprite, fn = callback, newNode = node;
                                var listener = function () {
                                    sound.play(playSprite, fn);
                                    newNode.removeEventListener('canplaythrough', listener, false);
                                };
                                newNode.addEventListener('canplaythrough', listener, false);
                            })();
                            return self;
                        }
                    }
                    self.on('play');
                    if (typeof callback === 'function') callback(soundId);
                    return self;
                });
                return self;
            }, pause: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.pause(id);
                    });
                    return self;
                }
                self._clearEndTimer(id);
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    activeNode._pos = self.pos(null, id);
                    if (self._webAudio) {
                        if (!activeNode.bufferSource || activeNode.paused) {
                            return self;
                        }
                        activeNode.paused = true;
                        if (typeof activeNode.bufferSource.stop === 'undefined') {
                            activeNode.bufferSource.noteOff(0);
                        } else {
                            activeNode.bufferSource.stop(0);
                        }
                    } else {
                        activeNode.pause();
                    }
                }
                self.on('pause');
                return self;
            }, stop: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.stop(id);
                    });
                    return self;
                }
                self._clearEndTimer(id);
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    activeNode._pos = 0;
                    if (self._webAudio) {
                        if (!activeNode.bufferSource || activeNode.paused) {
                            return self;
                        }
                        activeNode.paused = true;
                        if (typeof activeNode.bufferSource.stop === 'undefined') {
                            activeNode.bufferSource.noteOff(0);
                        } else {
                            activeNode.bufferSource.stop(0);
                        }
                    } else if (!isNaN(activeNode.duration)) {
                        activeNode.pause();
                        activeNode.currentTime = 0;
                    }
                }
                return self;
            }, mute: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.mute(id);
                    });
                    return self;
                }
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    if (self._webAudio) {
                        activeNode.gain.value = 0;
                    } else {
                        activeNode.muted = true;
                    }
                }
                return self;
            }, unmute: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.unmute(id);
                    });
                    return self;
                }
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    if (self._webAudio) {
                        activeNode.gain.value = self._volume;
                    } else {
                        activeNode.muted = false;
                    }
                }
                return self;
            }, volume: function (vol, id) {
                var self = this;
                vol = parseFloat(vol);
                if (vol >= 0 && vol <= 1) {
                    self._volume = vol;
                    if (!self._loaded) {
                        self.on('play', function () {
                            self.volume(vol, id);
                        });
                        return self;
                    }
                    var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                    if (activeNode) {
                        if (self._webAudio) {
                            activeNode.gain.value = vol;
                        } else {
                            activeNode.volume = vol * Howler.volume();
                        }
                    }
                    return self;
                } else {
                    return self._volume;
                }
            }, loop: function (loop) {
                var self = this;
                if (typeof loop === 'boolean') {
                    self._loop = loop;
                    return self;
                } else {
                    return self._loop;
                }
            }, sprite: function (sprite) {
                var self = this;
                if (typeof sprite === 'object') {
                    self._sprite = sprite;
                    return self;
                } else {
                    return self._sprite;
                }
            }, pos: function (pos, id) {
                var self = this;
                if (!self._loaded) {
                    self.on('load', function () {
                        self.pos(pos);
                    });
                    return typeof pos === 'number' ? self : self._pos || 0;
                }
                pos = parseFloat(pos);
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    if (pos >= 0) {
                        self.pause(id);
                        activeNode._pos = pos;
                        self.play(activeNode._sprite, id);
                        return self;
                    } else {
                        return self._webAudio ? activeNode._pos + (ctx.currentTime - self._playStart) : activeNode.currentTime;
                    }
                } else if (pos >= 0) {
                    return self;
                } else {
                    for (var i = 0; i < self._audioNode.length; i++) {
                        if (self._audioNode[i].paused && self._audioNode[i].readyState === 4) {
                            return (self._webAudio) ? self._audioNode[i]._pos : self._audioNode[i].currentTime;
                        }
                    }
                }
            }, pos3d: function (x, y, z, id) {
                var self = this;
                y = (typeof y === 'undefined' || !y) ? 0 : y;
                z = (typeof z === 'undefined' || !z) ? -0.5 : z;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.pos3d(x, y, z, id);
                    });
                    return self;
                }
                if (x >= 0 || x < 0) {
                    if (self._webAudio) {
                        var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                        if (activeNode) {
                            self._pos3d = [x, y, z];
                            activeNode.panner.setPosition(x, y, z);
                            activeNode.panner.panningModel = self._model || 'HRTF';
                        }
                    }
                } else {
                    return self._pos3d;
                }
                return self;
            }, fade: function (from, to, len, callback, id) {
                var self = this, diff = Math.abs(from - to), dir = from > to ? 'down' : 'up', steps = diff / 0.01,
                    stepTime = len / steps;
                if (!self._loaded) {
                    self.on('load', function () {
                        self.fade(from, to, len, callback, id);
                    });
                    return self;
                }
                self.volume(from, id);
                for (var i = 1; i <= steps; i++) {
                    (function () {
                        var change = self._volume + (dir === 'up' ? 0.01 : -0.01) * i,
                            vol = Math.round(1000 * change) / 1000, toVol = to;
                        setTimeout(function () {
                            self.volume(vol, id);
                            if (vol === toVol) {
                                if (callback) callback();
                            }
                        }, stepTime * i);
                    })();
                }
            }, fadeIn: function (to, len, callback) {
                return this.volume(0).play().fade(0, to, len, callback);
            }, fadeOut: function (to, len, callback, id) {
                var self = this;
                return self.fade(self._volume, to, len, function () {
                    if (callback) callback();
                    self.pause(id);
                    self.on('end');
                }, id);
            }, _nodeById: function (id) {
                var self = this, node = self._audioNode[0];
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (self._audioNode[i].id === id) {
                        node = self._audioNode[i];
                        break;
                    }
                }
                return node;
            }, _activeNode: function () {
                var self = this, node = null;
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (!self._audioNode[i].paused) {
                        node = self._audioNode[i];
                        break;
                    }
                }
                self._drainPool();
                return node;
            }, _inactiveNode: function (callback) {
                var self = this, node = null;
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (self._audioNode[i].paused && self._audioNode[i].readyState === 4) {
                        callback(self._audioNode[i]);
                        node = true;
                        break;
                    }
                }
                self._drainPool();
                if (node) {
                    return;
                }
                var newNode;
                if (self._webAudio) {
                    newNode = self._setupAudioNode();
                    callback(newNode);
                } else {
                    self.load();
                    newNode = self._audioNode[self._audioNode.length - 1];
                    var listenerEvent = navigator.isCocoonJS ? 'canplaythrough' : 'loadedmetadata';
                    var listener = function () {
                        newNode.removeEventListener(listenerEvent, listener, false);
                        callback(newNode);
                    };
                    newNode.addEventListener(listenerEvent, listener, false);
                }
            }, _drainPool: function () {
                var self = this, inactive = 0, i;
                for (i = 0; i < self._audioNode.length; i++) {
                    if (self._audioNode[i].paused) {
                        inactive++;
                    }
                }
                for (i = self._audioNode.length - 1; i >= 0; i--) {
                    if (inactive <= 5) {
                        break;
                    }
                    if (self._audioNode[i].paused) {
                        if (self._webAudio) {
                            self._audioNode[i].disconnect(0);
                        }
                        inactive--;
                        self._audioNode.splice(i, 1);
                    }
                }
            }, _clearEndTimer: function (soundId) {
                var self = this, index = 0;
                for (var i = 0; i < self._onendTimer.length; i++) {
                    if (self._onendTimer[i].id === soundId) {
                        index = i;
                        break;
                    }
                }
                var timer = self._onendTimer[index];
                if (timer) {
                    clearTimeout(timer.timer);
                    self._onendTimer.splice(index, 1);
                }
            }, _setupAudioNode: function () {
                var self = this, node = self._audioNode, index = self._audioNode.length;
                node[index] = (typeof ctx.createGain === 'undefined') ? ctx.createGainNode() : ctx.createGain();
                node[index].gain.value = self._volume;
                node[index].paused = true;
                node[index]._pos = 0;
                node[index].readyState = 4;
                node[index].connect(masterGain);
                node[index].panner = ctx.createPanner();
                node[index].panner.panningModel = self._model || 'equalpower';
                node[index].panner.setPosition(self._pos3d[0], self._pos3d[1], self._pos3d[2]);
                node[index].panner.connect(node[index]);
                return node[index];
            }, on: function (event, fn) {
                var self = this, events = self['_on' + event];
                if (typeof fn === 'function') {
                    events.push(fn);
                } else {
                    for (var i = 0; i < events.length; i++) {
                        if (fn) {
                            events[i].call(self, fn);
                        } else {
                            events[i].call(self);
                        }
                    }
                }
                return self;
            }, off: function (event, fn) {
                var self = this, events = self['_on' + event], fnString = fn ? fn.toString() : null;
                if (fnString) {
                    for (var i = 0; i < events.length; i++) {
                        if (fnString === events[i].toString()) {
                            events.splice(i, 1);
                            break;
                        }
                    }
                } else {
                    self['_on' + event] = [];
                }
                return self;
            }, unload: function () {
                var self = this;
                var nodes = self._audioNode;
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (!nodes[i].paused) {
                        self.stop(nodes[i].id);
                        self.on('end', nodes[i].id);
                    }
                    if (!self._webAudio) {
                        nodes[i].src = '';
                    } else {
                        nodes[i].disconnect(0);
                    }
                }
                for (i = 0; i < self._onendTimer.length; i++) {
                    clearTimeout(self._onendTimer[i].timer);
                }
                var index = Howler._howls.indexOf(self);
                if (index !== null && index >= 0) {
                    Howler._howls.splice(index, 1);
                }
                delete cache[self._src];
                self = null;
            }
        };
        if (usingWebAudio) {
            var loadBuffer = function (obj, url) {
                if (url in cache) {
                    obj._duration = cache[url].duration;
                    loadSound(obj);
                    return;
                }
                if (/^data:[^;]+;base64,/.test(url)) {
                    var data = atob(url.split(',')[1]);
                    var dataView = new Uint8Array(data.length);
                    for (var i = 0; i < data.length; ++i) {
                        dataView[i] = data.charCodeAt(i);
                    }
                    decodeAudioData(dataView.buffer, obj, url);
                } else {
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', url, true);
                    xhr.responseType = 'arraybuffer';
                    xhr.onload = function () {
                        decodeAudioData(xhr.response, obj, url);
                    };
                    xhr.onerror = function () {
                        if (obj._webAudio) {
                            obj._buffer = true;
                            obj._webAudio = false;
                            obj._audioNode = [];
                            delete obj._gainNode;
                            delete cache[url];
                            obj.load();
                        }
                    };
                    try {
                        xhr.send();
                    } catch (e) {
                        xhr.onerror();
                    }
                }
            };
            var decodeAudioData = function (arraybuffer, obj, url) {
                ctx.decodeAudioData(arraybuffer, function (buffer) {
                    if (buffer) {
                        cache[url] = buffer;
                        loadSound(obj, buffer);
                    }
                }, function (err) {
                    obj.on('loaderror');
                });
            };
            var loadSound = function (obj, buffer) {
                obj._duration = (buffer) ? buffer.duration : obj._duration;
                if (Object.getOwnPropertyNames(obj._sprite).length === 0) {
                    obj._sprite = {_default: [0, obj._duration * 1000]};
                }
                if (!obj._loaded) {
                    obj._loaded = true;
                    obj.on('load');
                }
                if (obj._autoplay) {
                    obj.play();
                }
            };
            var refreshBuffer = function (obj, loop, id) {
                var node = obj._nodeById(id);
                node.bufferSource = ctx.createBufferSource();
                node.bufferSource.buffer = cache[obj._src];
                node.bufferSource.connect(node.panner);
                node.bufferSource.loop = loop[0];
                if (loop[0]) {
                    node.bufferSource.loopStart = loop[1];
                    node.bufferSource.loopEnd = loop[1] + loop[2];
                }
                node.bufferSource.playbackRate.value = obj._rate;
            };
        }
        if (typeof define === 'function' && define.amd) {
            define(function () {
                return {Howler: Howler, Howl: Howl};
            });
        }
        if (typeof exports !== 'undefined') {
            exports.Howler = Howler;
            exports.Howl = Howl;
        }
        if (typeof window !== 'undefined') {
            window.Howler = Howler;
            window.Howl = Howl;
        }
    })();
    (function () {
        var _audioSources = {};
        var _audioInstances = {};

        function initAudio(initInfo) {
            var howl = new Howl(initInfo);
            howl.play = function (sprite, callback) {
                if (howl._loop) {
                    return Howl.prototype.play.call(howl, sprite, callback);
                } else {
                    if (howl._loaded) {
                        return Howl.prototype.play.call(howl, sprite, callback);
                    } else {
                        return Howl.prototype.play.call(howl, sprite, callback);
                    }
                }
            };
            return howl;
        }

        g.audio = new function () {
            this.prepare = function (audios) {
                for (var p in audios) {
                    if (audios[p].preload == true) {
                        _audioInstances[p] = initAudio(audios[p]);
                    }
                    _audioSources[p] = audios[p];
                }
            };
            this.get = function (key) {
                if (_audioInstances[key] == undefined) {
                    if (_audioSources[key] != undefined)
                        _audioInstances[key] = initAudio(_audioSources[key]); else {
                        console.error('audio %s not exisist.', key);
                        return null;
                    }
                }
                return _audioInstances[key];
            };
        };
    })();
    g.Renderable = Object.extend({
        init: function (settings) {
            this.left = settings.left || 0;
            this.top = settings.top || 0;
            this.width = settings.width || 0;
            this.height = settings.height || 0;
            this.transformX = ~~(this.width / 2);
            this.transformY = ~~(this.height / 2);
            this.opacity = 1;
            this.rotate = 0;
            this.scaleX = 1;
            this.scaleY = 1;
            this.zIndex = 0;
            this.showBorder = false;
            this.visiable = true;
            this.isDirty = true;
            this.isMoved = true;
            this.isContentCacheable = false;
            this.cacheMargin = 0;
            this.cacheImage = null;
            this._id = null;
            this.parentNode = null;
            this._clips = null;
            Object.defineProperties(this, {
                centerX: {
                    get: function () {
                        return ~~(this.left + this.width / 2);
                    }, set: function (x) {
                        this.left = ~~(x - this.width / 2);
                    }
                }, centerY: {
                    get: function () {
                        return ~~(this.top + this.height / 2);
                    }, set: function (y) {
                        this.top = ~~(y - this.height / 2);
                    }
                }, id: {
                    get: function () {
                        return this._id;
                    }, set: function (newId) {
                        this._id = newId;
                    }
                }
            });
            this.setProperty(this.getSettings(settings, ['opacity', 'rotate', 'opacity', 'scaleX', 'scaleY', 'zIndex', 'showBorder', 'visiable', 'id', 'centerX', 'centerY', 'marginLeft', 'isContentCacheable', 'transformX', 'transformY']));
        }, scale: function (scaleX, scaleY) {
            this.scaleX = scaleX;
            this.scaleY = scaleY == undefined ? scaleX : scaleY;
            return this;
        }, getSettings: function (set, keys) {
            if (!keys) {
                return {};
            }
            var childSet = {};
            for (var i = 1, len = keys.length; i < len; i++) {
                if (set[keys[i]] !== undefined) {
                    childSet[keys[i]] = set[keys[i]];
                }
            }
            return childSet;
        }, setProperty: function (property, value) {
            if (typeof property == 'object') {
                for (var i in property) {
                    if (typeof property[i] == 'function')
                        this[i] = property[i].bind(this); else
                        this[i] = property[i];
                }
            } else {
                if (typeof value == 'function')
                    this[property] = value.bind(this); else
                    this[property] = value;
            }
            return this;
        }, isPointInPath: function (x, y) {
            var rect = this.getBoundingClientRect();
            return x >= rect.left && y >= rect.top && x <= rect.left + rect.width && y <= rect.top + rect.height;
        }, getBoundingClientRect: function () {
            if (this.parentNode != null) {
                var parentRect = this.parentNode.getBoundingClientRect();
                return {
                    top: this.top + parentRect.top,
                    left: this.left + parentRect.left,
                    width: this.width,
                    height: this.height
                };
            } else {
                return {top: this.top, left: this.left, width: this.width, height: this.height};
            }
        }, isVisiable: function () {
            return this.visiable;
        }, remove: function () {
            if (this.parentNode)
                this.parentNode.removeChild(this);
            return this;
        }, pushClip: function (callback, delay, duration) {
            if (this._clips == null) {
                this._clips = [];
            }
            this._clips.push({cleared: false, clock: -delay, callback: callback.bind(this), duration: duration || -1});
            return this;
        }, _clipsUpdate: function (dt) {
            for (var i = 0, len = this._clips.length; i < len; i++) {
                this._clips[i].clock += dt;
                if (this._clips[i].clock > 0) {
                    if (this._clips[i].callback(this._clips[i].clock) == true || this._clips[i].clock >= this._clips[i].duration) {
                        this._clips[i].cleared = true;
                    }
                }
            }
            for (var i = this._clips.length - 1; i >= 0; i--) {
                if (this._clips[i].cleared) {
                    this._clips.splice(i, 1);
                    if (this._clips.length == 0) {
                        this._clips = null;
                        break;
                    }
                }
            }
        }, appendTo: function (world) {
            world.appendChild(this);
            return this;
        }, update: function (dt) {
        }, draw: function (ctx) {
        }, destory: function () {
            if (this.cacheImage != null) {
                this.cacheImage.remove && this.cacheImage.remove();
            }
        }
    });
    g.Container = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.children = [];
        }, removeAllChild: function () {
            for (var j = this.children.length - 1; j >= 0; j--) {
                if (this.children[j].destory)
                    this.children[j].destory();
            }
            this.children = [];
            this.isDirty = true;
            return this;
        }, appendChild: function () {
            for (var i = 0; i < arguments.length; i++) {
                var isInsert = false;
                for (var j = this.children.length - 1; j >= 0; j--) {
                    if (this.children[j].zIndex <= arguments[i].zIndex) {
                        this.children.splice(j + 1, 0, arguments[i]);
                        isInsert = true;
                        break;
                    }
                }
                if (isInsert == false) {
                    this.children.unshift(arguments[i]);
                }
                arguments[i].parentNode = this;
            }
            this.isDirty = true;
            return this;
        }, removeChild: function (o) {
            for (var i = 0; i < this.children.length; i++) {
                if (this.children[i] == o) {
                    this.children.splice(i, 1);
                    if (o.destory)
                        o.destory();
                    break;
                }
            }
            this.isDirty = true;
            return this;
        }
    });
    g.Sprite = g.Renderable.extend({
        init: function (settings) {
            this.image = settings.image;
            settings.width = settings.width == undefined ? this.image.width : settings.width;
            settings.height = settings.height == undefined ? this.image.height : settings.height;
            this._super(g.Renderable, 'init', [settings]);
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
        }, draw: function (ctx) {
            ctx.drawImage(this.image, this.sx, this.sy, this.width, this.height, 0, 0, this.width, this.height);
        }
    });
    g.AnimateSheet = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.speed = settings.speed;
            this.frames = settings.frames;
            this.lineFrames = settings.lineFrames;
            this._currentAnimate = 'default';
            this._currentAnimateIndex = 0;
            this._currentFrame = -1;
            this._playTimes = Infinity;
            this._timeEndCallback = null;
            this.isStart = false;
            this.animates = {};
            this.clock = 0;
            this._maps = [];
            for (var i = 0; i < this.frames; i++) {
                this._maps[i] = {
                    sx: (i % this.lineFrames) * this.width + this.sx,
                    sy: (~~(i / this.lineFrames)) * this.height + this.sy
                };
            }
            this.addAnimate('default', [-1]);
            this.setCurrentAnimate('default');
        }, update: function (dt) {
            if (!this.isStart) {
                return;
            }
            this.clock += dt;
            if (this.clock > this.animates[this._currentAnimate].speed && this.animates[this._currentAnimate].frames.length > 1) {
                this.clock -= this.animates[this._currentAnimate].speed;
                this._currentAnimateIndex++;
                if (this._currentAnimateIndex > this.animates[this._currentAnimate].frames.length - 1) {
                    this._currentAnimateIndex = 0;
                    this._playTimes -= 1;
                    if (this._playTimes <= 0) {
                        this.isStart = false;
                        typeof this._timeEndCallback == 'function' && this._timeEndCallback.call(this);
                    }
                }
                this._currentFrame = this.animates[this._currentAnimate].frames[this._currentAnimateIndex];
                this.isDirty = true;
            }
        }, addAnimate: function (name, index, speed) {
            if (index.length == 0) {
                index = [-1];
            }
            this.animates[name] = {name: name, frames: index, speed: speed || this.speed};
            return this;
        }, setCurrentAnimate: function (name, times, callback) {
            this.clock = 0;
            this._currentAnimate = name;
            this._currentAnimateIndex = 0;
            this._currentFrame = this.animates[name].frames[0];
            this._playTimes = times || Infinity;
            this._timeEndCallback = callback || null;
            this.isStart = true;
            return this;
        }, getCurrentAnimate: function () {
            return this._currentAnimate;
        }, setCurrentAnimateIndex: function (index) {
            this._currentAnimateIndex = index;
            if (this._currentAnimateIndex > this.animates[this._currentAnimate].frames.length - 1) {
                this._currentAnimateIndex = 0;
            }
        }, draw: function (ctx) {
            if (this._currentFrame >= 0 && this.isStart) {
                ctx.drawImage(this.image, this._maps[this._currentFrame].sx, this._maps[this._currentFrame].sy, this.width, this.height, 0, 0, this.width, this.height);
            }
        }
    });
    (function () {
        g.animate = new g.Renderable({});
        g.animate.push = g.animate.pushClip;
        g.timer.setInterval(function (dt, clock) {
            if (g.animate._clips != null) {
                g.animate._clipsUpdate(dt);
            }
        });
    })();
    g.Debug = g.Renderable.extend({
        init: function (settings) {
            settings = settings || {};
            this._super(g.Renderable, 'init', [{zIndex: 100000, top: 0, left: 0, width: 160, height: 42}]);
            this.font = new g.Font({fontFamily: 'microsoft yahei', fontSize: 12, color: '#FFF'});
            this.view = settings.view || g.view;
        }, draw: function (ctx) {
            ctx.save();
            if (this.top != 0 || this.left != 0)
                ctx.translate(this.top, this.left);
            ctx.fillStyle = 'rgba(0, 0, 0)';
            ctx.fillRect(0, 0, this.width, this.height);
            this.font.draw(ctx, 'udt: ' + this.view.debug.updateTime.toFixed(2) + 'ms', 0, 0, 'left');
            this.font.draw(ctx, 'draw: ' + this.view.debug.drawTime.toFixed(2) + 'ms', 0, 14, 'left');
            this.font.draw(ctx, 'objs: ' + this.view.debug.objs, 0, 28, 'left');
            this.font.draw(ctx, 'draws: ' + this.view.debug.draws, 90, 28, 'left');
            this.font.draw(ctx, 'ufps: ' + this.view.debug.updateFps, 90, 0, 'left');
            this.font.draw(ctx, 'dfps: ' + this.view.debug.drawFps, 90, 14, 'left');
            ctx.restore();
        }
    });
    (function () {
        var events = [];
        var tempMouseDown = [];
        var mousedownElements = [];
        var mouseoverElements = [];
        g.event = {
            init: function (canvas) {
                function mouseDown(x, y, event) {
                    var myEvent = {clientX: x, clientY: y};
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mousedown || events[i].click) && events[i].target.isVisiable()) {
                            if (events[i].target.isPointInPath(x, y)) {
                                if (events[i].mousedown)
                                    for (var j = 0, len1 = events[i].mousedown.length; j < len1; j++)
                                        events[i].mousedown[j](myEvent);
                                if (events[i].click) {
                                    tempMouseDown.push(events[i]);
                                    events[i].isMouseDown = true;
                                }
                            }
                        }
                    }
                }

                function mouseUp(x, y, event) {
                    var myEvent = {clientX: x, clientY: y};
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mouseup || events[i].click) && events[i].target.isVisiable()) {
                            if (events[i].target.isPointInPath(x, y)) {
                                if (events[i].mouseup)
                                    for (var j = 0, len1 = events[i].mouseup.length; j < len1; j++)
                                        events[i].mouseup[j](myEvent);
                                if (events[i].click && events[i].isMouseDown == true)
                                    for (var j = 0, len1 = events[i].click.length; j < len1; j++)
                                        events[i].click[j](myEvent);
                            }
                        }
                    }
                    for (var i = 0, len = tempMouseDown.length; i < len; i++) {
                        tempMouseDown[i].isMouseDown = undefined;
                    }
                    tempMouseDown = [];
                }

                function mouseMove(x, y, event) {
                    var myEvent = {clientX: x, clientY: y};
                    var overCalls = [];
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mousemove || events[i].mouseover || events[i].mouseout) && events[i].target.isVisiable()) {
                            if (events[i].target.isPointInPath(x, y)) {
                                if (events[i].mousemove)
                                    for (var j = 0, len1 = events[i].mousemove.length; j < len1; j++)
                                        events[i].mousemove[j](myEvent);
                                if (events[i].mouseover && events[i].isMouseOver != true) {
                                    for (var j = 0, len1 = events[i].mouseover.length; j < len1; j++)
                                        overCalls.push(events[i].mouseover[j])
                                }
                                events[i].isMouseOver = true;
                            } else if (events[i].isMouseOver) {
                                events[i].isMouseOver = undefined;
                                if (events[i].mouseout)
                                    for (var j = 0, len1 = events[i].mouseout.length; j < len1; j++)
                                        events[i].mouseout[j](myEvent);
                            }
                        }
                    }
                    for (var i = 0, len = overCalls.length; i < len; i++) {
                        overCalls[i]();
                    }
                }

                function mouseOut() {
                    var myEvent = {};
                    for (var i = 0, len = tempMouseDown.length; i < len; i++) {
                        tempMouseDown[i].isMouseDown = undefined;
                    }
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mouseover || events[i].mouseout) && events[i].isMouseOver == true) {
                            if (events[i].target.isVisiable()) {
                                for (var j = 0, len1 = events[i].mouseout.length; j < len1; j++)
                                    events[i].mouseout[j]();
                                events[i].isMouseOver = undefined;
                            }
                        }
                    }
                }

                canvas.addEventListener('mousemove', function (event) {
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.clientX - left0;
                    var y = event.clientY - top0;
                    mouseMove(x, y, event);
                });
                canvas.addEventListener('mousedown', function (event) {
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.clientX - left0;
                    var y = event.clientY - top0;
                    mouseDown(x, y, event);
                });
                canvas.addEventListener('mouseup', function (event) {
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.clientX - left0;
                    var y = event.clientY - top0;
                    mouseUp(x, y, event);
                });
                canvas.addEventListener('mouseout', function (event) {
                    mouseOut();
                });
                canvas.addEventListener('touchmove', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.changedTouches[0].clientX - left0;
                    var y = event.changedTouches[0].clientY - top0;
                    mouseMove(x, y, event);
                });
                canvas.addEventListener('touchstart', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.changedTouches[0].clientX - left0;
                    var y = event.changedTouches[0].clientY - top0;
                    mouseDown(x, y, event);
                });
                canvas.addEventListener('touchend', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.changedTouches[0].clientX - left0;
                    var y = event.changedTouches[0].clientY - top0;
                    mouseUp(x, y, event);
                });
            }, bind: function (target, type, handle) {
                var t = null;
                for (var i = 0, len = events.length; i < len; i++) {
                    if (events[i].target == target)
                        t = events[i];
                }
                if (t == null) {
                    t = {target: target, handles: 0}
                    events.push(t);
                }
                if (t[type] == undefined)
                    t[type] = [];
                t[type].push(handle);
                t.handles += 1;
                t = null;
                return this;
            }, unbind: function (target, type, handle) {
                for (var i = 0, len = events.length; i < len; i++) {
                    if (events[i].target == target) {
                        if (handle == undefined) {
                            events.splice(i, 1);
                            return;
                        } else {
                            for (var j = 0, len1 = events[i][type].length; j < len; j++) {
                                if (events[i][type][j] == handle) {
                                    events[i][type].splice(j, 1);
                                    events[i].handles -= 1;
                                    j--;
                                    len1--;
                                    if (events[i].handles == 0) {
                                        events.splice(i, 1);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }, call: function (target, type) {
                for (var i = 0, len = events.length; i < len; i++) {
                    if (events[i].target == target) {
                        for (var j = 0, lenj = events[i][type].length; i < lenj; j++) {
                            events[i][type][j]();
                        }
                    }
                }
            }
        };
    })();
    g.loadImage = function (resources, callback) {
        var reses = resources;
        if (typeof resources == 'string') {
            reses = {'default': resources};
        }
        var loading_count = 0;
        var images = {};
        for (i in reses) {
            loading_count++;
            var src = reses[i];
            images[i] = new Image();
            images[i].src = src;
            images[i].onload = function () {
                loading_count--;
                this.isLoad = true;
                if (loading_count == 0) {
                    typeof callback == 'function' ? callback(images) : '';
                }
            }
        }
        if (typeof resources == 'string') {
            return images['default'];
        } else {
            return images;
        }
    };
    g.divideImage = function (resources, callback) {
        var res = {};
        for (var i in resources) {
            res[i] = g.TheView.prototype.toImage(function (ctx) {
                ctx.drawImage(resources[i][0], resources[i][1], resources[i][2], resources[i][3], resources[i][4], 0, 0, resources[i][3], resources[i][4]);
            }, resources[i][3], resources[i][4]);
        }
        return res;
    };
    (function () {
        g.m = new function () {
            var objects = {};

            function get(e) {
                if (objects[e] == null)
                    objects[e] = [];
                return objects[e];
            }

            this.listen = function (e, callback) {
                if (e == null)
                    get("*").push({callback: callback}); else if (typeof(e) == "array") {
                    for (var i = 0; i < e.length; i++)
                        get(e[i]).push({callback: callback});
                }
                else {
                    get(e).push({callback: callback});
                }
                return this;
            }
            this.remove = function (e, callback) {
                for (var evt in objects) {
                    if (evt == e || e == undefined) {
                        for (var i = 0; i < objects[evt].length; i++) {
                            if (objects[evt][i].callback == callback) {
                                objects[evt].splice(i, 1);
                                break;
                            }
                        }
                    }
                }
                return this;
            }
            this.send = function (e, args) {
                var i, j;
                var controls = get(e);
                for (var i = 0; i < controls.length; i++) {
                    if (controls[i].callback(args) == true)
                        return this;
                }
                controls = get("*");
                for (var i = 0; i < controls.length; i++) {
                    if (controls[i].callback(args) == true)
                        break;
                }
                return this;
            }
        };
    })();
    g.TheView = Object.extend({
        init: function (mixValue, width, height) {
            this.canvas = typeof mixValue == 'string' ? document.getElementById(mixValue) : mixValue;
            this.canvas.width = width || this.canvas.clientWidth;
            this.canvas.height = height || this.canvas.clientHeight;
            this.context = this.canvas.getContext('2d');
            this.world = new g.Container({width: this.canvas.width, height: this.canvas.height});
            this.fps = 60;
            this.fpsCountClock = 0;
            this.updateFps = 0;
            this.drawFps = 0;
            this.draws = 0;
            this.debug = {objs: 0, draws: 0, drawTime: 0, updateTime: 0, drawFps: 0, updateFps: 0};
            this.isPause = false;
            this.isDirty = false;
            this.cursors = [];
            this.isShowDebugPanel = false;
            this.clearBeforeDraw = false;
        }, showDebugPanel: function (x, y) {
            this.isShowDebugPanel = true;
            this.debugPanel = new g.Debug({top: y, left: x, view: this});
        }, setCursor: function (cursor) {
            this.canvas.style.cursor = cursor;
        }, saveCursor: function () {
            this.cursors.push(this.canvas.style.cursor);
        }, restoreCursor: function () {
            if (this.cursors.length > 0) {
                this.canvas.style.cursor = this.cursors.pop();
            }
        }, update: function (dt) {
            if (this.world != null && this.isPause == false) {
                this.updateFps++;
                this.debug.objs = 0;
                var start = window.performance.now();
                this.__updateContainer(this.world, dt);
                this.debug.updateTime = window.performance.now() - start;
            }
            this.fpsCountClock += dt;
            if (this.fpsCountClock >= 1000) {
                this.debug.updateFps = this.updateFps;
                this.debug.drawFps = this.drawFps;
                this.fpsCountClock -= 1000;
                this.updateFps = 0;
                this.drawFps = 0;
            }
        }, __updateContainer: function (container, dt) {
            for (var i = 0, len = container.children.length; i < len; i++) {
                this.debug.objs++;
                container.children[i].update(dt);
                if (container.children[i]._clips != null)
                    container.children[i]._clipsUpdate(dt);
                if (container.children[i] instanceof g.Container)
                    this.__updateContainer(container.children[i], dt);
                if (container.children[i].isMoved) {
                    container.isMoved = true;
                    container.isDirty = true;
                }
                if (container.children[i].isDirty) {
                    container.isDirty = true;
                }
            }
        }, draw: function () {
            if (this.world != null && this.isPause == false && this.world.isDirty == true) {
                this.debug.draws = 0;
                this.drawFps++;
                var start = window.performance.now();
                if (this.clearBeforeDraw)
                    this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
                this.__drawContainer(this.world, this.context, true);
                this.world.isDirty = false;
                this.debug.drawTime = window.performance.now() - start;
            }
            if (this.isShowDebugPanel)
                this.debugPanel.draw(this.context);
        }, __drawContainer: function (container, ctx, cacheAble) {
            for (var i = 0, len = container.children.length; i < len; i++) {
                var o = container.children[i];
                if (o.visiable == false)
                    continue;
                this.debug.draws++;
                ctx.save();
                if (o.opacity != 1)
                    ctx.globalAlpha *= o.opacity;
                if (o.scaleX != 1 || o.scaleY != 1 || o.rotate != 0) {
                    ctx.translate(o.left + o.transformX, o.top + o.transformY);
                    if (o.scaleX != 1 || o.scaleY != 1)
                        ctx.scale(o.scaleX, o.scaleY);
                    if (o.rotate != 0)
                        ctx.rotate(o.rotate);
                    ctx.translate(-o.transformX, -o.transformY);
                } else {
                    ctx.translate(o.left, o.top);
                }
                if (cacheAble == true && o.isContentCacheable && o.width > 0 && o.height > 0) {
                    if (o.cacheImage == null) {
                        if (o instanceof g.Container) {
                            o.cacheImage = this.toImage(function () {
                            }, o.width, o.height, o.cacheMargin);
                            this.__drawContainer(o, o.cacheImage.getContext('2d'), false);
                        } else {
                            o.cacheImage = this.toImage(o.draw.bind(o), o.width, o.height, o.cacheMargin);
                        }
                    }
                    else {
                        if (o.isDirty) {
                            if (o.width + o.cacheMargin * 2 != o.cacheImage.width || o.height + o.cacheMargin * 2 != o.cacheImage.height) {
                                o.cacheImage.width = o.width + o.cacheMargin * 2;
                                o.cacheImage.height = o.height + o.cacheMargin * 2;
                                if (o.cacheMargin > 0) {
                                    o.cacheImage.getContext('2d').translate(o.cacheMargin, o.cacheMargin);
                                }
                            } else {
                                o.cacheImage.getContext('2d').clearRect(0, 0, o.cacheImage.width, o.cacheImage.height);
                            }
                            if (o instanceof g.Container) {
                                this.__drawContainer(o, o.cacheImage.getContext('2d'), false);
                            } else {
                                o.draw(o.cacheImage.getContext('2d'));
                            }
                        }
                    }
                    try {
                        ctx.drawImage(o.cacheImage, -o.cacheMargin, -o.cacheMargin);
                    } catch (e) {
                        if (!o.isDisplayError) {
                            o.isDisplayError = true;
                            console.log(o);
                        }
                    }
                } else {
                    if (o instanceof g.Container) {
                        this.__drawContainer(o, ctx, true);
                    } else {
                        o.draw(ctx);
                    }
                }
                o.isDirty = false;
                o.isMoved = false;
                if (o.showBorder) {
                    ctx.save();
                    ctx.strokeStyle = '#f00';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(0, 0, o.width, o.height);
                    ctx.restore();
                }
                ctx.restore();
            }
        }, toImage: function (drawFunc, width, height, cacheMargin) {
            var c = document.createElement('canvas');
            var ctx = c.getContext('2d');
            cacheMargin = cacheMargin || 0;
            c.width = width + cacheMargin * 2;
            c.height = height + cacheMargin * 2;
            if (cacheMargin > 0)
                ctx.translate(cacheMargin, cacheMargin);
            drawFunc(ctx);
            return c;
        }, pause: function () {
            this.isPause = true;
        }, resume: function () {
            this.isPause = false;
        }
    });
    (function () {
        g.easing = function (percent, from, to, method) {
            percent = percent > 1 ? 1 : (percent < 0 ? 0 : percent);
            return method(percent) * (to - from) + from;
        };
        g.easing.Quadratic = {
            In: function (k) {
                return k * k;
            }, Out: function (k) {
                return k * (2 - k);
            }, InOut: function (k) {
                if ((k *= 2) < 1)
                    return 0.5 * k * k;
                return -0.5 * (--k * (k - 2) - 1);
            }
        };
        g.easing.Linear = {
            In: function (k) {
                return k;
            }, Out: function (k) {
                return k;
            }
        };
        g.easing.Cubic = {
            In: function (k) {
                return k * k * k;
            }, Out: function (k) {
                return --k * k * k + 1;
            }, InOut: function (k) {
                if ((k *= 2) < 1)
                    return 0.5 * k * k * k;
                return 0.5 * ((k -= 2) * k * k + 2);
            }
        };
        g.easing.Bounce = {
            In: function (k) {
                return 1 - easing.Bounce.Out(1 - k);
            }, Out: function (k) {
                if (k < (1 / 2.75)) {
                    return 7.5625 * k * k;
                } else if (k < (2 / 2.75)) {
                    return 7.5625 * (k -= (1.5 / 2.75)) * k + 0.75;
                } else if (k < (2.5 / 2.75)) {
                    return 7.5625 * (k -= (2.25 / 2.75)) * k + 0.9375;
                } else {
                    return 7.5625 * (k -= (2.625 / 2.75)) * k + 0.984375;
                }
            }, InOut: function (k) {
                if (k < 0.5)
                    return easing.Bounce.In(k * 2) * 0.5;
                return easing.Bounce.Out(k * 2 - 1) * 0.5 + 0.5;
            }
        };
        g.easing.Elastic = {
            In: function (k) {
                var s, a = 0.1, p = 0.4;
                if (k === 0) return 0;
                if (k === 1) return 1;
                if (!a || a < 1) {
                    a = 1;
                    s = p / 4;
                }
                else s = p * Math.asin(1 / a) / (2 * Math.PI);
                return -(a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
            }, Out: function (k) {
                var s, a = 0.1, p = 0.4;
                if (k === 0) return 0;
                if (k === 1) return 1;
                if (!a || a < 1) {
                    a = 1;
                    s = p / 4;
                }
                else s = p * Math.asin(1 / a) / (2 * Math.PI);
                return (a * Math.pow(2, -10 * k) * Math.sin((k - s) * (2 * Math.PI) / p) + 1);
            }, InOut: function (k) {
                var s, a = 0.1, p = 0.4;
                if (k === 0) return 0;
                if (k === 1) return 1;
                if (!a || a < 1) {
                    a = 1;
                    s = p / 4;
                }
                else s = p * Math.asin(1 / a) / (2 * Math.PI);
                if ((k *= 2) < 1) return -0.5 * (a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
                return a * Math.pow(2, -10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p) * 0.5 + 1;
            }
        };
    })();
    g.ComplexBitmapFont = g.Font.extend({
        init: function (settings) {
            this._super(g.Font, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.fontSize = settings.fontSize;
            this.size = this.fontSize;
            this.chars = settings.chars || '';
            this.numbers = this.chars.length;
            this.numbersPerRow = settings.numbersPerRow || this.numbers;
            this.charsWidth = settings.charsWidth || this.fontSize.x;
            if (!isNaN(this.charsWidth)) {
                var temp = this.charsWidth;
                this.charsWidth = [];
                for (var i = 0, len = this.numbers; i < len; i++) {
                    this.charsWidth.push(temp);
                }
            }
            this.margin = settings.margin || 0;
            this.padding = settings.padding || 0;
            this._maps = {};
            var sx = 0;
            var lineCount = 0;
            var lines = 0;
            for (var i = 0, len = this.numbers; i < len; i++) {
                var c = this.chars.charAt(i);
                lineCount++;
                if (lineCount > this.numbersPerRow) {
                    lineCount = 1;
                    sx = 0;
                    lines++;
                }
                sx += this.margin;
                this._maps[c] = {sx: sx + this.sx, sy: this.fontSize.y * lines + this.sy, width: this.charsWidth[i]};
                sx += this.charsWidth[i];
            }
            this.textBaseline = 'top';
            this.isDraw = false;
        }, measureText: function (ctx, text) {
            var width = 0;
            for (var i = 0, len = text.length; i < len; i++) {
                width += this._maps[text.charAt(i)].width;
            }
            return {width: width, height: this.fontSize.y};
        }, draw: function (ctx, text, x, y, textAlign) {
            text = text + "";
            var width = 0, height = this.size.y;
            for (var i = 0, len = text.length; i < len; i++) {
                width += this._maps[text.charAt(i)].width;
            }
            if (textAlign == 'right')
                x -= width; else if (textAlign == 'center')
                x -= ~~(width * 0.5);
            if (this.textBaseline == 'middle')
                y -= ~~(height * 0.5); else if (this.textBaseline == 'top')
                y = y; else
                y -= height;
            if (this.padding == 0) {
                for (var i = 0, len = text.length; i < len; i++) {
                    var c = text.charAt(i);
                    ctx.drawImage(this.image, this._maps[c].sx, this._maps[c].sy, this._maps[c].width, height, x, y, this._maps[c].width, height);
                    x += this._maps[c].width;
                }
            } else {
                for (var i = 0, len = text.length; i < len; i++) {
                    var c = text.charAt(i);
                    ctx.drawImage(this.image, this._maps[c].sx - this.padding, this._maps[c].sy, this._maps[c].width + this.padding + this.padding, height, x - this.padding, y, this._maps[c].width + this.padding + this.padding, height);
                    x += this._maps[c].width;
                }
            }
        }
    });
    g.LightRotate = g.Sprite.extend({
        init: function (settings) {
            this.lightWidth = settings.lightWidth || settings.image.width;
            this.lightLength = settings.lightLength || settings.image.height;
            settings.width = this.lightLength * 2;
            settings.height = this.lightLength * 2;
            this._super(g.Sprite, 'init', [settings]);
            this.lightNumber = settings.lightNumber;
            this.antiClock = settings.antiClock === undefined ? false : settings.antiClock;
            this.duration = settings.duration === undefined ? Infinity : settings.duration;
            this.phase = settings.phase || 0;
            this.rotate = this.phase;
            this.clock = 0;
            this.isContentCacheable = true;
        }, update: function (dt) {
            if (this.duration != Infinity) {
                this.clock += dt;
                this.rotate = this.phase + (this.clock / this.duration) * Math.PI * 2 * (this.antiClock == true ? 1 : -1);
                this.isMoved = true;
            }
        }, draw: function (ctx) {
            ctx.translate(~~(this.width / 2), ~~(this.height / 2));
            for (var i = 0; i < this.lightNumber; i++) {
                ctx.rotate(Math.PI * 2 / this.lightNumber);
                ctx.drawImage(this.image, this.sx, this.sy, this.lightWidth, this.lightLength, ~~(-this.lightWidth / 2), -this.lightLength, this.lightWidth, this.lightLength);
            }
        }
    });
    g.StreamContainer = g.Container.extend({
        init: function (settings) {
            settings.width = 0;
            settings.height = 0;
            this._super(g.Container, 'init', [settings]);
            this.textAlign = settings.textAlign || 'left';
        }, appendChild: function () {
            this._super(g.Container, 'appendChild', arguments);
            var orignWidth = this.width;
            for (var i = 0, len = arguments.length; i < len; i++) {
                arguments[i].left = this.width + (arguments[i].marginLeft || 0);
                this.width += arguments[i].width + (arguments[i].marginLeft || 0);
                this.height = arguments[i].height + arguments[i].top > this.height ? arguments[i].height + arguments[i].top : this.height
            }
            if (this.textAlign == 'center') {
                this.left -= ~~((this.width - orignWidth) / 2);
            } else if (this.textAlign == 'right') {
                this.left -= this.width - orignWidth;
            }
            return this;
        }
    });
    g.TextRender = g.Renderable.extend({
        init: function (settings) {
            this.font = settings.font;
            this._text = settings.text || '';
            this.textAlign = settings.textAlign || 'left';
            settings.height = this.font.size.y;
            this._super(g.Renderable, 'init', [settings]);
            this.calSize();
            Object.defineProperties(this, {
                text: {
                    get: function () {
                        return this._text;
                    }, set: function (s) {
                        this._text = s;
                        this.isDirty = true;
                        this.calSize();
                    }
                }
            });
            this.isContentCacheable = true;
            this.cacheMargin = this.font.size.x || 0;
        }, calSize: function () {
            var oldWidth = this.width;
            this.width = this.font.measureText(g.views[0].context, this._text).width;
            if (this.width != oldWidth && this.textAlign != 'left') {
                if (this.textAlign == 'center') {
                    this.left -= ~~((this.width - oldWidth) / 2);
                } else if (this.textAlign == 'right') {
                    this.left -= this.width - oldWidth;
                }
                this.isMoved = true;
            }
        }, draw: function (ctx) {
            this.font.draw(ctx, this.text, 0, 0, 'left');
        }
    });
    g.Background = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.color = settings.color;
        }, draw: function (ctx) {
            ctx.fillStyle = this.color;
            ctx.fillRect(0, 0, this.width, this.height);
        }
    });
    g.FloatContainer = g.Container.extend({
        init: function (settings) {
            this._super(g.Container, 'init', [settings]);
            this.clock = 0;
            this.orignTop = this.top;
            this.targetTop = this.top - this.height * 2;
        }, update: function (dt) {
            this.clock += dt;
            this.top = g.easing(this.clock / 1200, this.orignTop, this.targetTop, g.easing.Linear.Out);
            if (this.clock > 600) {
                this.opacity = g.easing((this.clock - 600) / 600, 1, 0, g.easing.Quadratic.Out);
            }
            if (this.clock > 1200) {
                this.remove.defer(this);
            }
            this.isMoved = true;
        }
    });
    g.FloatText = g.TextRender.extend({
        init: function (settings) {
            this._super(g.TextRender, 'init', [settings]);
            this.clock = 0;
            this.orignTop = this.top;
            this.targetTop = this.top - (settings.offset || this.font.size.y * 2);
            this.duration = settings.duration || 1200;
            this.halfDuraion = this.duration / 2;
        }, update: function (dt) {
            this.clock += dt;
            this.top = g.easing(this.clock / this.duration, this.orignTop, this.targetTop, g.easing.Linear.Out);
            if (this.clock > this.halfDuraion)
                this.opacity = g.easing((this.clock - this.halfDuraion) / this.halfDuraion, 1, 0, g.easing.Quadratic.Out);
            if (this.clock > this.duration)
                this.remove.defer(this);
            this.isMoved = true;
        }
    });
    g.ShadowFont = g.Font.extend({
        init: function (settings) {
            this._super(g.Font, 'init', [settings]);
            this.padding = this.shadowWidth || 0;
            this.shadowWidth = settings.shadowWidth;
            this.shadowColor = settings.shadowColor;
            this.shadows = [[this.shadowWidth, 0, 0, this.shadowColor], [0, this.shadowWidth, 0, this.shadowColor], [-this.shadowWidth, 0, 0, this.shadowColor], [0, -this.shadowWidth, 0, this.shadowColor], [this.shadowWidth, 0, this.shadowWidth, this.shadowColor], [0, this.shadowWidth, this.shadowWidth, this.shadowColor], [-this.shadowWidth, 0, this.shadowWidth, this.shadowColor], [0, -this.shadowWidth, this.shadowWidth, this.shadowColor]];
        }, draw: function (ctx, text, x, y, textAlign) {
            ctx.font = this.font;
            ctx.fillStyle = this.color;
            ctx.textAlign = textAlign == undefined ? 'left' : textAlign;
            ctx.textBaseline = this.textBaseline;
            var strings = ('' + text).split("\n");
            for (var i = 0; i < strings.length; i++) {
                for (var j in this.shadows) {
                    ctx.shadowOffsetX = this.shadows[j][0];
                    ctx.shadowOffsetY = this.shadows[j][1];
                    ctx.shadowBlur = this.shadows[j][2];
                    ctx.shadowColor = this.shadows[j][3];
                    ctx.fillText(strings[i], ~~x, ~~(y + this.size.y * this.lineHeight / 2));
                }
                y += this.size.y * this.lineHeight;
            }
        }
    });
    g.ImageRender = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings])
            this.isLoad = false;
            var self = this;
            var images = g.loadImage({'one': settings.src}, function () {
                self.isLoad = true;
                self.isDirty = true;
            });
            this.image = images['one'];
        }, draw: function (ctx) {
            if (!this.isLoad)
                return
            ctx.drawImage(this.image, 0, 0, this.width, this.height);
        }
    });
    g.ParticleBlow = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.sw = settings.sw || 0;
            this.sh = settings.sh || 0;
            this.x0 = settings.x0 || ~~(this.width / 2);
            this.y0 = settings.y0 || ~~(this.height / 2);
            this.xRange = settings.xRange || 0;
            this.vxRange = settings.vxRange || 0;
            this.v0 = settings.v0 || 0.9;
            this.divergeAngle = settings.divergeAngle || Math.PI / 6;
            this.vxMax = Math.sin(settings.divergeAngle) * this.v0;
            this.damp = settings.damp || 0.002;
            this.numbers = settings.numbers || 0;
            this.diffTime = settings.diffTime || 10;
            this.accelerate = settings.accelerate || 0;
            this.scaleMax = settings.scaleMax || 1.2;
            this.scaleMin = settings.scaleMin || 0.8;
            this.objs = [];
            for (var i = 0; i < this.numbers; i++) {
                var temp = {
                    t0: i * this.diffTime,
                    lifeTime: Math.rand(400, 600),
                    vx: Math.rand(0, this.vxMax),
                    vxd: Math.random() > 0.5 ? 1 : -1,
                    vyd: -1,
                    y0: -Math.random() * 40,
                    dx: 0,
                    dy: 0,
                    isDisplay: false,
                    scale: Math.rand(this.scaleMin, this.scaleMax),
                    opacity: 1
                }
                temp.vx *= temp.vxd;
                temp.x0 = Math.random() * this.xRange / 2 * temp.vxd, temp.vy = Math.sqrt((this.v0 - temp.vx) * (this.v0 + temp.vx)) * temp.vyd;
                this.objs.push(temp);
            }
            ;this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            if (this.objs.length > 0) {
                this.isDirty = true;
            }
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i], t1 = this.clock - temp.t0;
                temp.isDisplay = t1 >= 0;
                if (t1 < 0)
                    continue;
                temp.dx = t1 * temp.vx;
                temp.dy = temp.vy * t1 + 0.5 * this.accelerate * t1 * t1;
                if (temp.lifeTime < t1) {
                    if ((t1 - temp.lifeTime) > 400) {
                        this.objs.splice(i, 1);
                        i--;
                        len--;
                    } else {
                        temp.opacity = g.easing((t1 - temp.lifeTime) / 400, 1, 0, g.easing.Quadratic.Out);
                    }
                }
                if (len <= 0) {
                    this.remove.defer(this);
                }
            }
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            for (var i = 0, len = this.objs.length; i < len; i++) {
                if (this.objs[i].isDisplay == false)
                    continue;
                if (this.objs[i].opacity != 1) {
                    ctx.save();
                    ctx.globalAlpha *= this.objs[i].opacity;
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].dx + this.objs[i].x0, this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                    ctx.restore();
                } else {
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].dx + this.objs[i].x0, this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                }
            }
        }
    });
    g.ParticleErupt = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.sw = settings.sw || this.image.width;
            this.sh = settings.sh || this.image.height;
            this.x0 = settings.x0 || ~~(this.width / 2);
            this.y0 = settings.y0 || ~~(this.height / 2);
            this.scaleMin = settings.scaleMin || 0.8;
            this.scaleMax = settings.scaleMax || 1.2;
            this.speedUp = settings.speedUp || 1;
            this.xRange = settings.xRange || 0;
            this.v0 = settings.v0 !== undefined ? settings.v0 : 0.9;
            this.vxMax = settings.divergeAngle ? Math.sin(settings.divergeAngle) : 0.4;
            this.accelerate = settings.accelerate || 1.2;
            this.numbers = settings.numbers || 0;
            this.diffTime = settings.diffTime || 10;
            this.objs = [];
            this.frames = settings.frames || 1;
            this.minPeriod = settings.minPeriod || 80;
            this.maxPeriod = settings.maxPeriod || 100;
            for (var i = 0; i < this.numbers; i++) {
                var temp = {
                    t0: i * this.diffTime,
                    vx: Math.rand(0, this.v0 * 0.4),
                    vxd: Math.random() > 0.5 ? 1 : -1,
                    vyd: -1,
                    sx: 0,
                    sy: 0,
                    isDisplay: false,
                    scale: Math.rand(this.scaleMin, this.scaleMax),
                    frame0: ~~Math.rand(0, this.frames + 0.99),
                    frame: 0,
                    period: Math.rand(this.minPeriod, this.maxPeriod)
                }
                temp.vx *= temp.vxd;
                temp.x0 = Math.random() * this.xRange / 2 * temp.vxd, temp.vy = Math.sqrt((this.v0 - temp.vx) * (this.v0 + temp.vx)) * temp.vyd;
                this.objs.push(temp);
            }
            ;this.clock = 0;
        }, update: function (dt) {
            this.clock += dt * this.speedUp;
            var len = this.objs.length;
            if (len > 0)
                this.isDirty = true;
            for (var i = 0; i < len; i++) {
                var temp = this.objs[i], t1 = this.clock - temp.t0;
                temp.isDisplay = t1 >= 0;
                if (t1 < 0)
                    continue;
                temp.frame = (~~(temp.frame0 + t1 / temp.period)) % this.frames;
                temp.sx = temp.vx * t1 + temp.x0;
                temp.sy = temp.vy * t1 + 0.5 * this.accelerate * t1 * t1;
                if (temp.sy > this.height) {
                    this.objs.splice(i, 1);
                    i--;
                    len--;
                }
                if (len <= 0) {
                    this.remove.defer(this);
                }
            }
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            for (var i = 0, len = this.objs.length; i < len; i++) {
                if (this.objs[i].isDisplay == false)
                    continue;
                ctx.drawImage(this.image, this.sx + this.objs[i].frame * this.sw, this.sy, this.sw, this.sh, ~~this.objs[i].sx, ~~this.objs[i].sy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
    g.ParticleFlyInto = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.sw = settings.sw || 0;
            this.sh = settings.sh || 0;
            this.x0 = settings.x0 || ~~(this.width / 2);
            this.y0 = settings.y0 || ~~(this.height / 2);
            this.targetX = settings.targetX - this.x0;
            this.targetY = settings.targetY - this.y0;
            this.numbers = settings.numbers || 0;
            this.diffTime = settings.diffTime || 150;
            this.objs = [];
            for (var i = 0; i < this.numbers; i++) {
                var temp = {
                    delay: i * this.diffTime,
                    x1: (Math.random() - 0.5) * 40 + 30,
                    y0: -Math.random() * 20,
                    dx: 0,
                    dy: 0,
                    isDisplay: true,
                    scale: Math.rand(0.8, 1.2),
                    scale: 1,
                    opacity: 1
                };
                temp.vx = temp.x1 / 300;
                temp.x2 = -temp.vx * 600;
                temp.y2 = -(temp.y0 + 20);
                this.objs.push(temp);
            }
            ;this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            if (this.objs.length > 0) {
                this.isDirty = true;
            }
            if (this.clock <= 200) {
                for (var i = 0; i < this.objs.length; i++) {
                    var temp = this.objs[i];
                    temp.dx = -temp.vx * this.clock;
                    temp.dy = g.easing(this.clock / 300, -temp.y0, -temp.y0 - 70, g.easing.Quadratic.Out);
                }
            }
            if (this.clock > 200 && this.clock < 600) {
                for (var i = 0; i < this.objs.length; i++) {
                    var temp = this.objs[i];
                    temp.dx = -temp.vx * this.clock;
                    temp.dy = g.easing((this.clock - 300) / 300, -temp.y0 - 70, temp.y2, g.easing.Bounce.Out) + temp.y0;
                }
            }
            if (this.clock > 800) {
                for (var i = 0; i < this.objs.length; i++) {
                    var temp = this.objs[i], t1 = this.clock - 800;
                    temp.dx = g.easing(t1 / (400 + temp.delay), temp.x2, this.targetX, g.easing.Linear.In);
                    temp.dy = g.easing(t1 / (400 + temp.delay), temp.y2, this.targetY, g.easing.Linear.In);
                }
            }
            if (this.clock > 1200 + this.diffTime * this.numbers) {
                this.remove.defer(this);
            }
        }, draw: function (ctx) {
            ctx.translate(this.x0, this.y0);
            for (var i = 0, len = this.objs.length; i < len; i++) {
                if (this.objs[i].isDisplay == false)
                    continue;
                if (this.objs[i].opacity != 1) {
                    ctx.save();
                    ctx.globalAlpha *= this.objs[i].opacity;
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, ~~this.objs[i].dx, ~~this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                    ctx.restore();
                } else {
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, ~~this.objs[i].dx, ~~this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                }
            }
        }
    });
    g.CountDown = g.TextRender.extend({
        init: function (settings) {
            this._super(g.TextRender, 'init', [settings]);
            this.text = parseInt(this.text);
            this.text += 1;
            this.clock = 1000;
            this.callback = settings.callback;
        }, update: function (dt) {
            this.clock += dt;
            if (this.clock > 1000) {
                this.clock -= 1000;
                if (this.text <= 1) {
                    typeof this.callback == 'function' ? this.callback() : '';
                    this.remove.defer(this);
                } else {
                    this.text -= 1;
                }
            }
        }
    });
    g.CountDownWithEffect = g.TextRender.extend({
        init: function (settings) {
            settings.text = parseInt(settings.text);
            settings.text += 1;
            this._super(g.TextRender, 'init', [settings]);
            this.opacity = 0;
            this.clock = 1000;
            this.callback = settings.callback;
        }, update: function (dt) {
            this.clock += dt;
            if (this.clock > 1000) {
                this.clock -= 1000;
                if (this.text <= 1) {
                    typeof this.callback == 'function' ? this.callback() : '';
                    this.remove.defer(this);
                } else {
                    this.pushClip(function (t) {
                        this.text -= 1;
                        this.opacity = 1;
                        this.isMoved = true;
                        return true;
                    }, 0, -1);
                    this.pushClip(function (t) {
                        this.scale(g.easing(t / 200, 0.6, 1.5, g.easing.Quadratic.In));
                        this.isMoved = true;
                    }, 0, 200);
                    this.pushClip(function (t) {
                        this.scale(g.easing(t / 50, 1.5, 1, g.easing.Quadratic.In));
                        this.isMoved = true;
                    }, 200, 50);
                    this.pushClip(function (t) {
                        this.opacity = 0;
                        this.isMoved = true;
                        return true;
                    }, 900);
                }
            }
        }
    });
    g.ScoreText = g.TextRender.extend({
        init: function (settings) {
            settings.text = '';
            this._super(g.TextRender, 'init', [settings]);
            this.followObj = settings.followObj;
            this.followIndex = settings.followIndex;
            this.text = this.followObj[this.followIndex];
        }, update: function (dt) {
            if (this.followObj[this.followIndex] != this.text) {
                this.text = this.followObj[this.followIndex];
            }
        }
    });
    g.TransitionScoreText = g.ScoreText.extend({
        init: function (settings) {
            settings.text = '';
            this._super(g.ScoreText, 'init', [settings]);
            this.duration = settings.duration || 300;
            this.targetText = this.text;
            this.fromText = this.text;
            this.clock = 0;
        }, update: function (dt) {
            if (this.followObj[this.followIndex] != this.targetText) {
                this.clock = 0;
                this.targetText = this.followObj[this.followIndex];
                this.fromText = this.text;
            }
            if (this.targetText != this.text) {
                this.clock += dt;
                this.text = ~~g.easing(this.clock / this.duration, this.fromText, this.targetText, g.easing.Linear.In);
                return true;
            }
        }
    });
    ;
})();
;
/* 18j9h2.js */


//数字特效
function num_animation() {
    $(document).ready(function () {
        var animate = new Animate();
        var $expgap = $('#exp');
        animate.push(function (tick, progress) {
            $expgap.width(parseInt($expgap.data('number') * progress));
        }, 0, 1500);
        var numbers = [$('#exp_num')];
        $.each(numbers, function (index, element) {
            var number = element.data('number');
            animate.push(function (tick, progress) {
                element.html(parseInt(number * progress));
            }, 0, 1500);
        });
        animate.start();
    });
}


/*


$(document).ready(function () {
    var messages = [];
    var isModuleLoading = false;
    var new_messages = 0;
    var exps = 0;
    var lastExpGetTime = 0;
    var lastUpdateTime = 0;

    function updateMessage() {
        $.ajax({
            url: "ajax/get_data1.php", type: "POST", data: {}, dataType: "JSON", success: function (res) {
                messages = res.data.message.messages;
                new_messages = res.data.message.unreads;
                exps = res.data.exp.exps;
                loadMessageModule();
                fixNewMessageDisplay();
            }
        });
    }

   // updateMessage();
    setInterval(function () {
        lastUpdateTime += 5000;
        if ((lastExpGetTime == 0 && lastUpdateTime > 60000) || (exps <= 0 && lastExpGetTime != 0 && (new Date().getTime() - lastExpGetTime) > 300000)) {
            lastUpdateTime = 0;
            updateMessage();
        }
    }, 5000);

    function loadMessageModule() {
        var effects = [];
        for (var i in messages) {
            try {
                if (messages[i].type == 2)
                    effects.push(messages[i].ext.actions[0].effect);
            } catch (e) {
            }
        }
        isModuleLoading = true;
        message.load(effects, function () {
            isModuleLoading = false;
        });
    }

    function fixNewMessageDisplay() {
        if (new_messages > 0) {
            $('#my_news').addClass('message_new').html(new_messages);
            popAnimate($('#my_news'));
        } else {
            $('#my_news').removeClass('message_new').html('');
        }
    }

    $('#my_news').bind('click', function () {
        if (isModuleLoading)
            return;
        if (messages.length <= 0)
            location.href = 'm.php'; else {
            var m = messages.shift();
            if (m.type == 2) {
                new_messages--;
                message.run(m.ext.actions[0]['effect'], m.ext.actions[0]['data']);
                fixNewMessageDisplay();
                $.get('ajax/view_message.php?id=' + m.id + '&index=0');
            }
        }
    });

    function popAnimate($e) {
        if (!$e.hasClass('message_new')) {
            return false;
        }
        if ($e.hasClass('poping')) {
            return true;
        }
        $e.addClass('poping');
        var animate = new Animate(60);
        var duration = 750;
        var interval = 4000;
        animate.push(function (tick) {
            var t = (tick * 60) % interval;
            if (t <= duration) {
                var do_percent = t / duration;
                if (t <= duration * 0.25) {
                    var scale = 1 + (1.4 - 1) * do_percent;
                } else {
                    var scale = 1 + (1.4 - 1) * (1 - do_percent);
                }
                scale = scale.toFixed(2);
                $e.css('-webkit-transform', 'scale(' + scale + ',' + scale + ')').css('transform', 'scale(' + scale + ',' + scale + ')');
                if (do_percent == 1) {
                    $e.removeClass('poping');
                }
            }
        }, 0, 10000000, 1);
        animate.start();
    }
});




*/


$(document).ready(function () {
    var mob = "18710333329";

    ajaxDoPlayHistory(mob);

});


/**
 * 处理播放历史记录
 * @param mob
 */

function ajaxDoPlayHistory(mob) {
    $.ajax({

        //提交数据的类型 POST GET
        type: "POST",

        //提交的网址
        url: "./RESTApi/doPlayHistory.php",

        //提交的数据
        data: {do: "getPlayHistoryList", mob: mob},

        //返回数据的格式
        datatype: "json",//"xml", "html", "script", "json", "jsonp", "text".

        //在请求之前调用的函数
        beforeSend: function (XMLHttpRequest) {
            //todo
        },

        //成功返回之后调用的函数
        success: function (data) {

            //todo
            var jsondata = $.parseJSON(data);
            var playdata = jsondata.data;
            console.log(jsondata);

            var temp = "";
            $.each(playdata, function (key, val) {

                console.log(val.currentTime + "||" + val.durationTime);

                // var percent = Percentage(val.currentTime,val.durationTime);
                var percent = ((val.currentTime / val.durationTime) * 100).toFixed(2) + '%';


                temp += "                    <div class=\"records_course clearfix\">\n" +
                    "                        <div class=\"records_course_name ellipsis\" style=\"\">数学</div>\n" +
                    "                        <div class=\"course_content\" style=\"display:inline-block\">\n" +
                    "                            <div class=\"clearfix\" style=\"float: right;\">\n" +
                    "                                <div class=\"category_name ellipsis\">" + val.title + "</div>\n" +
                    "                                <div class=\"to_learn\" data-stage_id=\"15865\"\n" +
                    "                                     onclick=\"window.location.href='videpage/index.php?from=playhistory&currentTime=" + val.currentTime + "&vtitle=" + val.title + "&id=" + val.vid + "';\">\n" +
                    "                                    开始学习\n" +
                    "                                </div>\n" +
                    "                            </div>\n" +
                    "                            <div class=\"course_prosess_div\">\n" +
                    "                                <div class=\"course_prosess\">\n" +
                    "                                    <div style=\"width:" + percent + "\"></div>\n" +
                    "                                </div>\n" +
                    "                                <span>" + percent + "</span>\n" +
                    "                            </div>\n" +
                    "                        </div>\n" +
                    "                        <div class=\"course_content\" style=\"display:none\">\n" +
                    "                            <div class=\"passed_icon\"></div>\n" +
                    "                            <div class=\"passed_tip\">已完成该学科下的全部知识点</div>\n" +
                    "                        </div>\n" +
                    "                    </div>";

            });

            $(".last_records_course_items").append(temp);


        },

        //调用执行后调用的函数
        complete: function (XMLHttpRequest, textStatus) {
            //todo
        },

        //调用出错执行的函数
        error: function () {
            //todo
        }
    });

}


;
/* jDuuT.js */
var message = new (function () {
    var modules = {};
    var loaded = [];
    this.run = function (module, ext) {
        if (hasModule(module))
            return use(module, ext); else
            return false;
    };
    this.load = function (moduleNames, callback) {
        var loads = [];
        for (var i in moduleNames) {
            var temp = moduleNames[i].toLowerCase();
            if ($.inArray(temp, loaded) < 0) {
                loads.push(temp);
                loaded.push(temp);
            }
        }
        if (loads.length > 0) {
            $.getScript('v2/message/js.php?f=' + loads.join('-')).done(function () {
                typeof callback == 'function' && callback();
            });
        } else {
            typeof callback == 'function' && callback();
        }
    };
    this.register = function (module, obj) {
        modules[module] = obj;
    };

    function hasModule(module) {
        return modules[module] != undefined;
    }

    function use(module, param) {
        if (modules[module] == undefined) {
            console.error('module: %s not exist', module);
            return false;
        }
        modules[module].run(param);
        return true;
    }
})();


/**
 *
 * @param num
 * @param total
 * @returns {string}
 * @constructor
 */


function Percentage(num, total) {
    return (Math.round(num / total * 10000) / 100.00 + "%");// 小数点后两位百分比

}