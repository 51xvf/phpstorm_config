;
/* SFI1f.js */
(function () {
    window.crButtonInit = function () {
        $('.cr_button').each(function () {
            var e = $(this);
            if (e.data('is_inited') != true) {
                var wrap = $('<div class="' + e.attr('class') + '" style="' + e.attr('style') + '">' + e.html() + '</div>');
                e.wrap(wrap);
                e.addClass('cr_button_over');
                wrap = e.parent();
                wrap.append('<span class="cr_button_cover"></span>');
                wrap.bind('mousedown touchstart', function () {
                    wrap.addClass('cb_down');
                }).bind('mouseup mouseout touchend', function () {
                    wrap.removeClass('cb_down');
                });
                e.data('is_inited', true);
                wrap.data('is_inited', true);
                e.data('show', function () {
                    e.show();
                    wrap.show();
                });
                e.data('hide', function () {
                    e.hide();
                    wrap.hide();
                });
                e.data('disable', function () {
                    wrap.addClass('cb_disable');
                    wrap.show();
                });
                e.data('enable', function () {
                    wrap.removeClass('cb_disable');
                    wrap.show();
                });
                e.data('noplay', function () {
                    wrap.hide();
                });
            }
        });
    };
    $(document).ready(function () {
        $(document).bind('touchstart', function (event) {
        }).bind('touchend', function (event) {
        });
    });
})();
;
/* 6BWrt.js */
(function () {
    try {
        Object.defineProperty({}, 'props', {
            value: function () {
            }
        })
    }
    catch (e) {
        window.g = {};
        (function () {
            g.easing = function (percent, from, to, method) {
                percent = percent > 1 ? 1 : (percent < 0 ? 0 : percent);
                return method(percent) * (to - from) + from;
            };
            g.easing.Quadratic = {
                In: function (k) {
                    return k * k;
                }, Out: function (k) {
                    return k * (2 - k);
                }, InOut: function (k) {
                    if ((k *= 2) < 1)
                        return 0.5 * k * k;
                    return -0.5 * (--k * (k - 2) - 1);
                }
            };
            g.easing.Linear = {
                In: function (k) {
                    return k;
                }, Out: function (k) {
                    return k;
                }
            };
            g.easing.Cubic = {
                In: function (k) {
                    return k * k * k;
                }, Out: function (k) {
                    return --k * k * k + 1;
                }, InOut: function (k) {
                    if ((k *= 2) < 1)
                        return 0.5 * k * k * k;
                    return 0.5 * ((k -= 2) * k * k + 2);
                }
            };
            g.easing.Bounce = {
                In: function (k) {
                    return 1 - easing.Bounce.Out(1 - k);
                }, Out: function (k) {
                    if (k < (1 / 2.75)) {
                        return 7.5625 * k * k;
                    } else if (k < (2 / 2.75)) {
                        return 7.5625 * (k -= (1.5 / 2.75)) * k + 0.75;
                    } else if (k < (2.5 / 2.75)) {
                        return 7.5625 * (k -= (2.25 / 2.75)) * k + 0.9375;
                    } else {
                        return 7.5625 * (k -= (2.625 / 2.75)) * k + 0.984375;
                    }
                }, InOut: function (k) {
                    if (k < 0.5)
                        return easing.Bounce.In(k * 2) * 0.5;
                    return easing.Bounce.Out(k * 2 - 1) * 0.5 + 0.5;
                }
            };
            g.easing.Elastic = {
                In: function (k) {
                    var s, a = 0.1, p = 0.4;
                    if (k === 0) return 0;
                    if (k === 1) return 1;
                    if (!a || a < 1) {
                        a = 1;
                        s = p / 4;
                    }
                    else s = p * Math.asin(1 / a) / (2 * Math.PI);
                    return -(a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
                }, Out: function (k) {
                    var s, a = 0.1, p = 0.4;
                    if (k === 0) return 0;
                    if (k === 1) return 1;
                    if (!a || a < 1) {
                        a = 1;
                        s = p / 4;
                    }
                    else s = p * Math.asin(1 / a) / (2 * Math.PI);
                    return (a * Math.pow(2, -10 * k) * Math.sin((k - s) * (2 * Math.PI) / p) + 1);
                }, InOut: function (k) {
                    var s, a = 0.1, p = 0.4;
                    if (k === 0) return 0;
                    if (k === 1) return 1;
                    if (!a || a < 1) {
                        a = 1;
                        s = p / 4;
                    }
                    else s = p * Math.asin(1 / a) / (2 * Math.PI);
                    if ((k *= 2) < 1) return -0.5 * (a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
                    return a * Math.pow(2, -10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p) * 0.5 + 1;
                }
            };
        })();
        (function () {
            g.m = new function () {
                var objects = {};

                function get(e) {
                    if (objects[e] == null)
                        objects[e] = [];
                    return objects[e];
                }

                this.listen = function (e, callback) {
                    if (e == null)
                        get("*").push({callback: callback}); else if (typeof(e) == "array") {
                        for (var i = 0; i < e.length; i++)
                            get(e[i]).push({callback: callback});
                    }
                    else {
                        get(e).push({callback: callback});
                    }
                    return this;
                }
                this.remove = function (e, callback) {
                    for (var evt in objects) {
                        if (evt == e || e == undefined) {
                            for (var i = 0; i < objects[evt].length; i++) {
                                if (objects[evt][i].callback == callback) {
                                    objects[evt].splice(i, 1);
                                    break;
                                }
                            }
                        }
                    }
                    return this;
                }
                this.send = function (e, args) {
                    var i, j;
                    var controls = get(e);
                    for (var i = 0; i < controls.length; i++) {
                        if (controls[i].callback(args) == true)
                            return this;
                    }
                    controls = get("*");
                    for (var i = 0; i < controls.length; i++) {
                        if (controls[i].callback(args) == true)
                            break;
                    }
                    return this;
                }
            };
        })();
        return;
    }
    Object.getPrototypeOf = Object.getPrototypeOf || function (obj) {
        return obj.__proto__;
    };
    Object.setPrototypeOf = Object.setPrototypeOf || function (obj, prototype) {
        obj.__proto__ = prototype;
        return obj;
    };
    if (!Object.defineProperty) {
        Object.defineProperty = function (obj, prop, desc) {
            if (obj.__defineGetter__) {
                if (desc.get) {
                    obj.__defineGetter__(prop, desc.get);
                }
                if (desc.set) {
                    obj.__defineSetter__(prop, desc.set);
                }
            } else {
                throw new TypeError("Object.defineProperty not supported");
            }
        };
    }
    if (typeof Object.create !== "function") {
        Object.create = function (o) {
            var Fn = function () {
            };
            Fn.prototype = o;
            return new Fn();
        };
    }
    if (!Function.prototype.bind) {
        var Empty = function () {
        };
        Function.prototype.bind = function bind(that) {
            var target = this;
            if (typeof target !== "function") {
                throw new TypeError("Function.prototype.bind called on incompatible " + target);
            }
            var args = Array.prototype.slice.call(arguments, 1);
            var bound = function () {
                if (this instanceof bound) {
                    var result = target.apply(this, args.concat(Array.prototype.slice.call(arguments)));
                    if (Object(result) === result) {
                        return result;
                    }
                    return this;
                } else {
                    return target.apply(that, args.concat(Array.prototype.slice.call(arguments)));
                }
            };
            if (target.prototype) {
                Empty.prototype = target.prototype;
                bound.prototype = new Empty();
                Empty.prototype = null;
            }
            return bound;
        };
    }
    (function () {
        Object.defineProperty(Object.prototype, "extend", {
            "value": function () {
                var methods = {};
                var mixins = Array.prototype.slice.call(arguments, 0);

                function Class() {
                    this.init.apply(this, arguments);
                    return this;
                }

                Class.prototype = Object.create(this.prototype);
                mixins.forEach(function (mixin) {
                    apply_methods(Class, methods, mixin.__methods__ || mixin);
                });
                if (!("init" in Class.prototype)) {
                    throw new TypeError("extend: Class is missing a constructor named `init`");
                }
                Object.defineProperty(Class.prototype, "_super", {"value": _super});
                Object.defineProperty(Class, "__methods__", {"value": methods});
                return Class;
            }
        });

        function apply_methods(Class, methods, descriptor) {
            Object.keys(descriptor).forEach(function (method) {
                methods[method] = descriptor[method];
                if (typeof(descriptor[method]) !== "function") {
                    throw new TypeError("extend: Method `" + method + "` is not a function");
                }
                Object.defineProperty(Class.prototype, method, {"configurable": true, "value": descriptor[method]});
            });
        }

        function _super(superClass, method, args) {
            return superClass.prototype[method].apply(this, args);
        }
    })();
    Math.rand = function (min, max) {
        return Math.random() * (max - min) + min;
    };
    Number.prototype.clamp = function (low, high) {
        return this < low ? low : this > high ? high : +this;
    };
    window.requestAnimationFrame = (function () {
        return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || function (callback) {
            return window.setTimeout(callback, 1000 / 60);
        };
    })();
    window.cancelAnimationFrame = (function () {
        return window.cancelAnimationFrame || window.webkitCancelAnimationFrame || window.mozCancelAnimationFrame || window.oCancelAnimationFrame || function (id) {
            window.clearTimeout(id);
        };
    })();
    window.performance = window.performance || {};
    window.performance.now = (function () {
        if (window.performance && window.performance.now)
            return window.performance.now.bind(window.performance); else if (Date.now)
            return Date.now.bind(Date); else
            return function () {
                return (new Date()).getTime();
            }
    })();
    Function.prototype.defer = function () {
        return setTimeout(this.bind.apply(this, arguments), 0.01);
    };
    window.g = window.g || {
        world: null, pool: null, views: [], isInit: false, init: function () {
            if (this.isInit)
                return true;
            this.clock = 0;
            this.error = null;
            var self = this;
            var lastTime = ~~window.performance.now();

            function loop() {
                try {
                    var now = ~~window.performance.now();
                    var dt = now - lastTime;
                    lastTime = now;
                    self.update(dt);
                } catch (e) {
                    if (this.error == null) {
                        this.error = e;
                        console.error(e.stack);
                    }
                }
                window.requestAnimationFrame(loop);
            }

            loop();
            this.isInit = true;
        }, initView: function (mixValue, width, height, initEvent) {
            g.view = new g.TheView(mixValue, width, height);
            this.views.push(g.view);
            g.world = g.view.world;
            if (initEvent !== false) {
                g.event.init(g.view.canvas);
            }
            return g.view;
        }, addView: function (mixValue, width, height) {
            var view = new g.TheView(mixValue, width, height);
            this.views.push(view);
            return view;
        }, update: function (dt) {
            this.clock += dt;
            g.timer.update(dt);
            for (var i = 0, len = this.views.length; i < len; i++) {
                this.views[i].update(dt);
                this.views[i].draw();
            }
        }
    };
    g.timer = new (function () {
        var timerId = 0;
        var timers = [];
        var clock = 0;
        this.update = function (dt) {
            for (var i = timers.length - 1; i >= 0; i--) {
                if (timers[i].cleared) {
                    timers.splice(i, 1);
                }
            }
            clock += dt;
            for (var i = timers.length - 1; i >= 0; i--) {
                timers[i].clock += dt;
                if (timers[i].clock >= timers[i].interval) {
                    if (timers[i].isTimeout === false) {
                        timers[i].time += timers[i].clock;
                        timers[i].callback(timers[i].clock, timers[i].time);
                        timers[i].clock -= timers[i].interval;
                    } else {
                        timers[i].callback(timers[i].clock);
                        timers[i].cleared = true;
                    }
                } else if (timers[i].interval == undefined && timers[i].isTimeout === false) {
                    timers[i].time += dt;
                    timers[i].callback(dt, timers[i].time);
                }
            }
        };
        this.setTimeout = function (callback, delay) {
            timers.unshift({
                clock: 0,
                time: 0,
                interval: delay,
                callback: callback,
                timerId: ++timerId,
                isTimeout: true,
                cleared: false
            });
            return timerId;
        };
        this.setInterval = function (callback, duration) {
            timers.unshift({
                clock: 0,
                time: 0,
                nextCallClock: duration,
                interval: duration,
                callback: callback,
                timerId: ++timerId,
                isTimeout: false,
                cleared: false
            });
            return timerId;
        };
        this.clearTimer = function (timerId) {
            for (var i = 0, len = timers.length; i < len; i++) {
                if (timers[i].timerId == timerId) {
                    timers[i].cleared = true;
                    break;
                }
            }
        };
    })();
    g.init();
    g.Font = Object.extend({
        init: function (settings) {
            this.fontWeight = settings.fontWeight || '';
            this.fontStyle = settings.fontStyle || '';
            this.fontSize = parseInt(settings.fontSize, 10);
            this.fontFamily = settings.fontFamily || 'Arial';
            this.color = settings.color || '#000';
            this.lineHeight = settings.lineHeight || 1.0;
            this.textBaseline = settings.textBaseline || 'middle';
            this.size = {x: this.fontSize, y: this.fontSize};
            if (typeof this.fontSize === 'number') {
                this.fontSize += 'px';
            }
            this.font = [this.fontWeight, this.fontStyle, this.fontSize, this.fontFamily].join(' ');
        }, copy: function (settings) {
            var set = {};
            var props = ['fontWeight', 'fontStyle', 'fontSize', 'color', 'fontFamily'];
            for (var i in props) {
                set[props[i]] = settings[props[i]] === undefined ? this[props] : settings[props[i]];
            }
            return new g.Font(settings);
        }, measureText: function (ctx, text) {
            ctx.save();
            ctx.font = this.font;
            ctx.fillStyle = this.color;
            var size = {width: ctx.measureText(text).width, height: this.size * this.lineHeight}
            ctx.restore();
            return size;
        }, draw: function (ctx, text, x, y, textAlign) {
            ctx.font = this.font;
            ctx.fillStyle = this.color;
            ctx.textAlign = textAlign == undefined ? 'left' : textAlign;
            ctx.textBaseline = this.textBaseline;
            var strings = ('' + text).split("\n");
            for (var i = 0; i < strings.length; i++) {
                ctx.fillText(strings[i], ~~x, ~~(y + this.size.y * this.lineHeight / 2));
                y += this.size.y * this.lineHeight;
            }
        }
    });
    g.BitmapFont = g.Font.extend({
        init: function (settings) {
            this._super(g.Font, 'init', [settings]);
            var scale = settings.scale || 1;
            this.fontSize = settings.fontSize;
            this.firstChar = settings.firstChar || 0x20;
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.loadFontMetrics(settings.image, settings.fontSize, settings.charCount);
            if (scale != 1) {
                this.size.x = ~~(this.size.x * scale);
                this.size.y = ~~(this.size.y * scale);
            }
            this.textBaseline = 'top';
        }, loadFontMetrics: function (image, size, charCount) {
            this.fontSize.x = size.x || size;
            this.fontSize.y = size.y || this.font.height;
            this.size.x = this.fontSize.x;
            this.size.y = this.fontSize.y;
            this.height = this.size.y;
            this.charCount = charCount || ~~(image.width / this.fontSize.x);
        }, measureText: function (ctx, text) {
            var strings = ('' + text).split("\n");
            this.height = this.width = 0;
            for (var i = 0; i < strings.length; i++) {
                this.width = (strings[i].length * this.size.x) > this.width ? (strings[i].length * this.size.x) : this.width;
                this.height += this.size.y * this.lineHeight;
            }
            return {width: this.width, height: this.height};
        }, draw: function (ctx, text, x, y, textAlign) {
            var strings = ("" + text).split("\n");
            var lX = x;
            var height = this.size.y * this.lineHeight;
            for (var i = 0; i < strings.length; i++) {
                x = lX;
                var string = strings[i];
                var width = string.length * this.size.x;
                if (textAlign == 'right')
                    x -= width; else if (textAlign == 'center')
                    x -= width * 0.5;
                switch (this.textBaseline) {
                    case"middle":
                        y -= height * 0.5;
                        break;
                    case"ideographic":
                    case"alphabetic":
                    case"bottom":
                        y -= height;
                        break;
                    default:
                        break;
                }
                for (var c = 0, len = string.length; c < len; c++) {
                    var idx = string.charCodeAt(c) - this.firstChar;
                    if (idx >= 0) {
                        ctx.drawImage(this.image, this.sx + this.fontSize.x * (idx % this.charCount), this.sy + this.fontSize.y * ~~(idx / this.charCodeAtunt), this.fontSize.x, this.fontSize.y, ~~x, ~~y, this.size.x, this.size.y);
                    }
                    x += this.size.x;
                }
                y += height;
            }
        }
    });
    (function () {
        var cache = {};
        var ctx = null, usingWebAudio = true, noAudio = false;
        try {
            if (typeof AudioContext !== 'undefined') {
                ctx = new AudioContext();
            } else if (typeof webkitAudioContext !== 'undefined') {
                ctx = new webkitAudioContext();
            } else {
                usingWebAudio = false;
            }
        } catch (e) {
            usingWebAudio = false;
        }
        if (!usingWebAudio) {
            if (typeof Audio !== 'undefined') {
                try {
                    new Audio();
                } catch (e) {
                    noAudio = true;
                }
            } else {
                noAudio = true;
            }
        }
        if (usingWebAudio) {
            var masterGain = (typeof ctx.createGain === 'undefined') ? ctx.createGainNode() : ctx.createGain();
            masterGain.gain.value = 1;
            masterGain.connect(ctx.destination);
        }
        var HowlerGlobal = function (codecs) {
            this._volume = 1;
            this._muted = false;
            this.usingWebAudio = usingWebAudio;
            this.ctx = ctx;
            this.noAudio = noAudio;
            this._howls = [];
            this._codecs = codecs;
            this.iOSAutoEnable = true;
        };
        HowlerGlobal.prototype = {
            volume: function (vol) {
                var self = this;
                vol = parseFloat(vol);
                if (vol >= 0 && vol <= 1) {
                    self._volume = vol;
                    if (usingWebAudio) {
                        masterGain.gain.value = vol;
                    }
                    for (var key in self._howls) {
                        if (self._howls.hasOwnProperty(key) && self._howls[key]._webAudio === false) {
                            for (var i = 0; i < self._howls[key]._audioNode.length; i++) {
                                self._howls[key]._audioNode[i].volume = self._howls[key]._volume * self._volume;
                            }
                        }
                    }
                    return self;
                }
                return (usingWebAudio) ? masterGain.gain.value : self._volume;
            }, mute: function () {
                this._setMuted(true);
                return this;
            }, unmute: function () {
                this._setMuted(false);
                return this;
            }, _setMuted: function (muted) {
                var self = this;
                self._muted = muted;
                if (usingWebAudio) {
                    masterGain.gain.value = muted ? 0 : self._volume;
                }
                for (var key in self._howls) {
                    if (self._howls.hasOwnProperty(key) && self._howls[key]._webAudio === false) {
                        for (var i = 0; i < self._howls[key]._audioNode.length; i++) {
                            self._howls[key]._audioNode[i].muted = muted;
                        }
                    }
                }
            }, codecs: function (ext) {
                return this._codecs[ext];
            }, _enableiOSAudio: function () {
                var self = this;
                if (ctx && (self._iOSEnabled || !/iPhone|iPad|iPod/i.test(navigator.userAgent))) {
                    return;
                }
                self._iOSEnabled = false;
                var unlock = function () {
                    var buffer = ctx.createBuffer(1, 1, 22050);
                    var source = ctx.createBufferSource();
                    source.buffer = buffer;
                    source.connect(ctx.destination);
                    if (typeof source.start === 'undefined') {
                        source.noteOn(0);
                    } else {
                        source.start(0);
                    }
                    setTimeout(function () {
                        if ((source.playbackState === source.PLAYING_STATE || source.playbackState === source.FINISHED_STATE)) {
                            self._iOSEnabled = true;
                            self.iOSAutoEnable = false;
                            window.removeEventListener('touchstart', unlock, false);
                        }
                    }, 0);
                };
                window.addEventListener('touchstart', unlock, false);
                return self;
            }
        };
        var audioTest = null;
        var codecs = {};
        if (!noAudio) {
            audioTest = new Audio();
            codecs = {
                mp3: !!audioTest.canPlayType('audio/mpeg;').replace(/^no$/, ''),
                opus: !!audioTest.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/, ''),
                ogg: !!audioTest.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ''),
                wav: !!audioTest.canPlayType('audio/wav; codecs="1"').replace(/^no$/, ''),
                aac: !!audioTest.canPlayType('audio/aac;').replace(/^no$/, ''),
                m4a: !!(audioTest.canPlayType('audio/x-m4a;') || audioTest.canPlayType('audio/m4a;') || audioTest.canPlayType('audio/aac;')).replace(/^no$/, ''),
                mp4: !!(audioTest.canPlayType('audio/x-mp4;') || audioTest.canPlayType('audio/mp4;') || audioTest.canPlayType('audio/aac;')).replace(/^no$/, ''),
                weba: !!audioTest.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, '')
            };
        }
        var Howler = new HowlerGlobal(codecs);
        var Howl = function (o) {
            var self = this;
            self._autoplay = o.autoplay || false;
            self._buffer = o.buffer || false;
            self._duration = o.duration || 0;
            self._format = o.format || null;
            self._loop = o.loop || false;
            self._loaded = false;
            self._sprite = o.sprite || {};
            self._src = o.src || '';
            self._pos3d = o.pos3d || [0, 0, -0.5];
            self._volume = o.volume !== undefined ? o.volume : 1;
            self._urls = o.urls || [];
            self._rate = o.rate || 1;
            self._model = o.model || null;
            self._onload = [o.onload || function () {
            }];
            self._onloaderror = [o.onloaderror || function () {
            }];
            self._onend = [o.onend || function () {
            }];
            self._onpause = [o.onpause || function () {
            }];
            self._onplay = [o.onplay || function () {
            }];
            self._onendTimer = [];
            self._webAudio = usingWebAudio && !self._buffer;
            self._audioNode = [];
            if (self._webAudio) {
                self._setupAudioNode();
            }
            if (typeof ctx !== 'undefined' && ctx && Howler.iOSAutoEnable) {
                Howler._enableiOSAudio();
            }
            Howler._howls.push(self);
            self.load();
        };
        Howl.prototype = {
            load: function () {
                var self = this, url = null;
                if (noAudio) {
                    self.on('loaderror');
                    return;
                }
                for (var i = 0; i < self._urls.length; i++) {
                    var ext, urlItem;
                    if (self._format) {
                        ext = self._format;
                    } else {
                        urlItem = self._urls[i];
                        ext = /^data:audio\/([^;,]+);/i.exec(urlItem);
                        if (!ext) {
                            ext = /\.([^.]+)$/.exec(urlItem.split('?', 1)[0]);
                        }
                        if (ext) {
                            ext = ext[1].toLowerCase();
                        } else {
                            self.on('loaderror');
                            return;
                        }
                    }
                    if (codecs[ext]) {
                        url = self._urls[i];
                        break;
                    }
                }
                if (!url) {
                    self.on('loaderror');
                    return;
                }
                self._src = url;
                if (self._webAudio) {
                    loadBuffer(self, url);
                } else {
                    var newNode = new Audio();
                    newNode.addEventListener('error', function () {
                        if (newNode.error && newNode.error.code === 4) {
                            HowlerGlobal.noAudio = true;
                        }
                        self.on('loaderror', {type: newNode.error ? newNode.error.code : 0});
                    }, false);
                    self._audioNode.push(newNode);
                    newNode.src = url;
                    newNode._pos = 0;
                    newNode.preload = 'auto';
                    newNode.volume = (Howler._muted) ? 0 : self._volume * Howler.volume();
                    var listener = function () {
                        self._duration = Math.ceil(newNode.duration * 10) / 10;
                        if (Object.getOwnPropertyNames(self._sprite).length === 0) {
                            self._sprite = {_default: [0, self._duration * 1000]};
                        }
                        if (!self._loaded) {
                            self._loaded = true;
                            self.on('load');
                        }
                        if (self._autoplay) {
                            self.play();
                        }
                        newNode.removeEventListener('canplaythrough', listener, false);
                    };
                    newNode.addEventListener('canplaythrough', listener, false);
                    newNode.load();
                }
                return self;
            }, urls: function (urls) {
                var self = this;
                if (urls) {
                    self.stop();
                    self._urls = (typeof urls === 'string') ? [urls] : urls;
                    self._loaded = false;
                    self.load();
                    return self;
                } else {
                    return self._urls;
                }
            }, play: function (sprite, callback) {
                var self = this;
                if (typeof sprite === 'function') {
                    callback = sprite;
                }
                if (!sprite || typeof sprite === 'function') {
                    sprite = '_default';
                }
                if (!self._loaded) {
                    self.on('load', function () {
                        self.play(sprite, callback);
                    });
                    return self;
                }
                if (!self._sprite[sprite]) {
                    if (typeof callback === 'function') callback();
                    return self;
                }
                self._inactiveNode(function (node) {
                    node._sprite = sprite;
                    var pos = (node._pos > 0) ? node._pos : self._sprite[sprite][0] / 1000;
                    var duration = 0;
                    if (self._webAudio) {
                        duration = self._sprite[sprite][1] / 1000 - node._pos;
                        if (node._pos > 0) {
                            pos = self._sprite[sprite][0] / 1000 + pos;
                        }
                    } else {
                        duration = self._sprite[sprite][1] / 1000 - (pos - self._sprite[sprite][0] / 1000);
                    }
                    var loop = !!(self._loop || self._sprite[sprite][2]);
                    var soundId = (typeof callback === 'string') ? callback : Math.round(Date.now() * Math.random()) + '',
                        timerId;
                    (function () {
                        var data = {id: soundId, sprite: sprite, loop: loop};
                        timerId = setTimeout(function () {
                            if (!self._webAudio && loop) {
                                self.stop(data.id).play(sprite, data.id);
                            }
                            if (self._webAudio && !loop) {
                                self._nodeById(data.id).paused = true;
                                self._nodeById(data.id)._pos = 0;
                                self._clearEndTimer(data.id);
                            }
                            if (!self._webAudio && !loop) {
                                self.stop(data.id);
                            }
                            self.on('end', soundId);
                        }, duration * 1000);
                        self._onendTimer.push({timer: timerId, id: data.id});
                    })();
                    if (self._webAudio) {
                        var loopStart = self._sprite[sprite][0] / 1000, loopEnd = self._sprite[sprite][1] / 1000;
                        node.id = soundId;
                        node.paused = false;
                        refreshBuffer(self, [loop, loopStart, loopEnd], soundId);
                        self._playStart = ctx.currentTime;
                        node.gain.value = self._volume;
                        if (typeof node.bufferSource.start === 'undefined') {
                            node.bufferSource.noteGrainOn(0, pos, duration);
                        } else {
                            node.bufferSource.start(0, pos, duration);
                        }
                    } else {
                        if (node.readyState === 4 || !node.readyState && navigator.isCocoonJS) {
                            node.readyState = 4;
                            node.id = soundId;
                            node.currentTime = pos;
                            node.muted = Howler._muted || node.muted;
                            node.volume = self._volume * Howler.volume();
                            setTimeout(function () {
                                node.play();
                            }, 0);
                        } else {
                            self._clearEndTimer(soundId);
                            (function () {
                                var sound = self, playSprite = sprite, fn = callback, newNode = node;
                                var listener = function () {
                                    sound.play(playSprite, fn);
                                    newNode.removeEventListener('canplaythrough', listener, false);
                                };
                                newNode.addEventListener('canplaythrough', listener, false);
                            })();
                            return self;
                        }
                    }
                    self.on('play');
                    if (typeof callback === 'function') callback(soundId);
                    return self;
                });
                return self;
            }, pause: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.pause(id);
                    });
                    return self;
                }
                self._clearEndTimer(id);
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    activeNode._pos = self.pos(null, id);
                    if (self._webAudio) {
                        if (!activeNode.bufferSource || activeNode.paused) {
                            return self;
                        }
                        activeNode.paused = true;
                        if (typeof activeNode.bufferSource.stop === 'undefined') {
                            activeNode.bufferSource.noteOff(0);
                        } else {
                            activeNode.bufferSource.stop(0);
                        }
                    } else {
                        activeNode.pause();
                    }
                }
                self.on('pause');
                return self;
            }, stop: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.stop(id);
                    });
                    return self;
                }
                self._clearEndTimer(id);
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    activeNode._pos = 0;
                    if (self._webAudio) {
                        if (!activeNode.bufferSource || activeNode.paused) {
                            return self;
                        }
                        activeNode.paused = true;
                        if (typeof activeNode.bufferSource.stop === 'undefined') {
                            activeNode.bufferSource.noteOff(0);
                        } else {
                            activeNode.bufferSource.stop(0);
                        }
                    } else if (!isNaN(activeNode.duration)) {
                        activeNode.pause();
                        activeNode.currentTime = 0;
                    }
                }
                return self;
            }, mute: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.mute(id);
                    });
                    return self;
                }
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    if (self._webAudio) {
                        activeNode.gain.value = 0;
                    } else {
                        activeNode.muted = true;
                    }
                }
                return self;
            }, unmute: function (id) {
                var self = this;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.unmute(id);
                    });
                    return self;
                }
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    if (self._webAudio) {
                        activeNode.gain.value = self._volume;
                    } else {
                        activeNode.muted = false;
                    }
                }
                return self;
            }, volume: function (vol, id) {
                var self = this;
                vol = parseFloat(vol);
                if (vol >= 0 && vol <= 1) {
                    self._volume = vol;
                    if (!self._loaded) {
                        self.on('play', function () {
                            self.volume(vol, id);
                        });
                        return self;
                    }
                    var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                    if (activeNode) {
                        if (self._webAudio) {
                            activeNode.gain.value = vol;
                        } else {
                            activeNode.volume = vol * Howler.volume();
                        }
                    }
                    return self;
                } else {
                    return self._volume;
                }
            }, loop: function (loop) {
                var self = this;
                if (typeof loop === 'boolean') {
                    self._loop = loop;
                    return self;
                } else {
                    return self._loop;
                }
            }, sprite: function (sprite) {
                var self = this;
                if (typeof sprite === 'object') {
                    self._sprite = sprite;
                    return self;
                } else {
                    return self._sprite;
                }
            }, pos: function (pos, id) {
                var self = this;
                if (!self._loaded) {
                    self.on('load', function () {
                        self.pos(pos);
                    });
                    return typeof pos === 'number' ? self : self._pos || 0;
                }
                pos = parseFloat(pos);
                var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                if (activeNode) {
                    if (pos >= 0) {
                        self.pause(id);
                        activeNode._pos = pos;
                        self.play(activeNode._sprite, id);
                        return self;
                    } else {
                        return self._webAudio ? activeNode._pos + (ctx.currentTime - self._playStart) : activeNode.currentTime;
                    }
                } else if (pos >= 0) {
                    return self;
                } else {
                    for (var i = 0; i < self._audioNode.length; i++) {
                        if (self._audioNode[i].paused && self._audioNode[i].readyState === 4) {
                            return (self._webAudio) ? self._audioNode[i]._pos : self._audioNode[i].currentTime;
                        }
                    }
                }
            }, pos3d: function (x, y, z, id) {
                var self = this;
                y = (typeof y === 'undefined' || !y) ? 0 : y;
                z = (typeof z === 'undefined' || !z) ? -0.5 : z;
                if (!self._loaded) {
                    self.on('play', function () {
                        self.pos3d(x, y, z, id);
                    });
                    return self;
                }
                if (x >= 0 || x < 0) {
                    if (self._webAudio) {
                        var activeNode = (id) ? self._nodeById(id) : self._activeNode();
                        if (activeNode) {
                            self._pos3d = [x, y, z];
                            activeNode.panner.setPosition(x, y, z);
                            activeNode.panner.panningModel = self._model || 'HRTF';
                        }
                    }
                } else {
                    return self._pos3d;
                }
                return self;
            }, fade: function (from, to, len, callback, id) {
                var self = this, diff = Math.abs(from - to), dir = from > to ? 'down' : 'up', steps = diff / 0.01,
                    stepTime = len / steps;
                if (!self._loaded) {
                    self.on('load', function () {
                        self.fade(from, to, len, callback, id);
                    });
                    return self;
                }
                self.volume(from, id);
                for (var i = 1; i <= steps; i++) {
                    (function () {
                        var change = self._volume + (dir === 'up' ? 0.01 : -0.01) * i,
                            vol = Math.round(1000 * change) / 1000, toVol = to;
                        setTimeout(function () {
                            self.volume(vol, id);
                            if (vol === toVol) {
                                if (callback) callback();
                            }
                        }, stepTime * i);
                    })();
                }
            }, fadeIn: function (to, len, callback) {
                return this.volume(0).play().fade(0, to, len, callback);
            }, fadeOut: function (to, len, callback, id) {
                var self = this;
                return self.fade(self._volume, to, len, function () {
                    if (callback) callback();
                    self.pause(id);
                    self.on('end');
                }, id);
            }, _nodeById: function (id) {
                var self = this, node = self._audioNode[0];
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (self._audioNode[i].id === id) {
                        node = self._audioNode[i];
                        break;
                    }
                }
                return node;
            }, _activeNode: function () {
                var self = this, node = null;
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (!self._audioNode[i].paused) {
                        node = self._audioNode[i];
                        break;
                    }
                }
                self._drainPool();
                return node;
            }, _inactiveNode: function (callback) {
                var self = this, node = null;
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (self._audioNode[i].paused && self._audioNode[i].readyState === 4) {
                        callback(self._audioNode[i]);
                        node = true;
                        break;
                    }
                }
                self._drainPool();
                if (node) {
                    return;
                }
                var newNode;
                if (self._webAudio) {
                    newNode = self._setupAudioNode();
                    callback(newNode);
                } else {
                    self.load();
                    newNode = self._audioNode[self._audioNode.length - 1];
                    var listenerEvent = navigator.isCocoonJS ? 'canplaythrough' : 'loadedmetadata';
                    var listener = function () {
                        newNode.removeEventListener(listenerEvent, listener, false);
                        callback(newNode);
                    };
                    newNode.addEventListener(listenerEvent, listener, false);
                }
            }, _drainPool: function () {
                var self = this, inactive = 0, i;
                for (i = 0; i < self._audioNode.length; i++) {
                    if (self._audioNode[i].paused) {
                        inactive++;
                    }
                }
                for (i = self._audioNode.length - 1; i >= 0; i--) {
                    if (inactive <= 5) {
                        break;
                    }
                    if (self._audioNode[i].paused) {
                        if (self._webAudio) {
                            self._audioNode[i].disconnect(0);
                        }
                        inactive--;
                        self._audioNode.splice(i, 1);
                    }
                }
            }, _clearEndTimer: function (soundId) {
                var self = this, index = 0;
                for (var i = 0; i < self._onendTimer.length; i++) {
                    if (self._onendTimer[i].id === soundId) {
                        index = i;
                        break;
                    }
                }
                var timer = self._onendTimer[index];
                if (timer) {
                    clearTimeout(timer.timer);
                    self._onendTimer.splice(index, 1);
                }
            }, _setupAudioNode: function () {
                var self = this, node = self._audioNode, index = self._audioNode.length;
                node[index] = (typeof ctx.createGain === 'undefined') ? ctx.createGainNode() : ctx.createGain();
                node[index].gain.value = self._volume;
                node[index].paused = true;
                node[index]._pos = 0;
                node[index].readyState = 4;
                node[index].connect(masterGain);
                node[index].panner = ctx.createPanner();
                node[index].panner.panningModel = self._model || 'equalpower';
                node[index].panner.setPosition(self._pos3d[0], self._pos3d[1], self._pos3d[2]);
                node[index].panner.connect(node[index]);
                return node[index];
            }, on: function (event, fn) {
                var self = this, events = self['_on' + event];
                if (typeof fn === 'function') {
                    events.push(fn);
                } else {
                    for (var i = 0; i < events.length; i++) {
                        if (fn) {
                            events[i].call(self, fn);
                        } else {
                            events[i].call(self);
                        }
                    }
                }
                return self;
            }, off: function (event, fn) {
                var self = this, events = self['_on' + event], fnString = fn ? fn.toString() : null;
                if (fnString) {
                    for (var i = 0; i < events.length; i++) {
                        if (fnString === events[i].toString()) {
                            events.splice(i, 1);
                            break;
                        }
                    }
                } else {
                    self['_on' + event] = [];
                }
                return self;
            }, unload: function () {
                var self = this;
                var nodes = self._audioNode;
                for (var i = 0; i < self._audioNode.length; i++) {
                    if (!nodes[i].paused) {
                        self.stop(nodes[i].id);
                        self.on('end', nodes[i].id);
                    }
                    if (!self._webAudio) {
                        nodes[i].src = '';
                    } else {
                        nodes[i].disconnect(0);
                    }
                }
                for (i = 0; i < self._onendTimer.length; i++) {
                    clearTimeout(self._onendTimer[i].timer);
                }
                var index = Howler._howls.indexOf(self);
                if (index !== null && index >= 0) {
                    Howler._howls.splice(index, 1);
                }
                delete cache[self._src];
                self = null;
            }
        };
        if (usingWebAudio) {
            var loadBuffer = function (obj, url) {
                if (url in cache) {
                    obj._duration = cache[url].duration;
                    loadSound(obj);
                    return;
                }
                if (/^data:[^;]+;base64,/.test(url)) {
                    var data = atob(url.split(',')[1]);
                    var dataView = new Uint8Array(data.length);
                    for (var i = 0; i < data.length; ++i) {
                        dataView[i] = data.charCodeAt(i);
                    }
                    decodeAudioData(dataView.buffer, obj, url);
                } else {
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', url, true);
                    xhr.responseType = 'arraybuffer';
                    xhr.onload = function () {
                        decodeAudioData(xhr.response, obj, url);
                    };
                    xhr.onerror = function () {
                        if (obj._webAudio) {
                            obj._buffer = true;
                            obj._webAudio = false;
                            obj._audioNode = [];
                            delete obj._gainNode;
                            delete cache[url];
                            obj.load();
                        }
                    };
                    try {
                        xhr.send();
                    } catch (e) {
                        xhr.onerror();
                    }
                }
            };
            var decodeAudioData = function (arraybuffer, obj, url) {
                ctx.decodeAudioData(arraybuffer, function (buffer) {
                    if (buffer) {
                        cache[url] = buffer;
                        loadSound(obj, buffer);
                    }
                }, function (err) {
                    obj.on('loaderror');
                });
            };
            var loadSound = function (obj, buffer) {
                obj._duration = (buffer) ? buffer.duration : obj._duration;
                if (Object.getOwnPropertyNames(obj._sprite).length === 0) {
                    obj._sprite = {_default: [0, obj._duration * 1000]};
                }
                if (!obj._loaded) {
                    obj._loaded = true;
                    obj.on('load');
                }
                if (obj._autoplay) {
                    obj.play();
                }
            };
            var refreshBuffer = function (obj, loop, id) {
                var node = obj._nodeById(id);
                node.bufferSource = ctx.createBufferSource();
                node.bufferSource.buffer = cache[obj._src];
                node.bufferSource.connect(node.panner);
                node.bufferSource.loop = loop[0];
                if (loop[0]) {
                    node.bufferSource.loopStart = loop[1];
                    node.bufferSource.loopEnd = loop[1] + loop[2];
                }
                node.bufferSource.playbackRate.value = obj._rate;
            };
        }
        if (typeof define === 'function' && define.amd) {
            define(function () {
                return {Howler: Howler, Howl: Howl};
            });
        }
        if (typeof exports !== 'undefined') {
            exports.Howler = Howler;
            exports.Howl = Howl;
        }
        if (typeof window !== 'undefined') {
            window.Howler = Howler;
            window.Howl = Howl;
        }
    })();
    (function () {
        var _audioSources = {};
        var _audioInstances = {};

        function initAudio(initInfo) {
            var howl = new Howl(initInfo);
            howl.play = function (sprite, callback) {
                if (howl._loop) {
                    return Howl.prototype.play.call(howl, sprite, callback);
                } else {
                    if (howl._loaded) {
                        return Howl.prototype.play.call(howl, sprite, callback);
                    } else {
                        return Howl.prototype.play.call(howl, sprite, callback);
                    }
                }
            };
            return howl;
        }

        g.audio = new function () {
            this.prepare = function (audios) {
                for (var p in audios) {
                    if (audios[p].preload == true) {
                        _audioInstances[p] = initAudio(audios[p]);
                    }
                    _audioSources[p] = audios[p];
                }
            };
            this.get = function (key) {
                if (_audioInstances[key] == undefined) {
                    if (_audioSources[key] != undefined)
                        _audioInstances[key] = initAudio(_audioSources[key]); else {
                        console.error('audio %s not exisist.', key);
                        return null;
                    }
                }
                return _audioInstances[key];
            };
        };
    })();
    g.Renderable = Object.extend({
        init: function (settings) {
            this.left = settings.left || 0;
            this.top = settings.top || 0;
            this.width = settings.width || 0;
            this.height = settings.height || 0;
            this.transformX = ~~(this.width / 2);
            this.transformY = ~~(this.height / 2);
            this.opacity = 1;
            this.rotate = 0;
            this.scaleX = 1;
            this.scaleY = 1;
            this.zIndex = 0;
            this.showBorder = false;
            this.visiable = true;
            this.isDirty = true;
            this.isMoved = true;
            this.isContentCacheable = false;
            this.cacheMargin = 0;
            this.cacheImage = null;
            this._id = null;
            this.parentNode = null;
            this._clips = null;
            Object.defineProperties(this, {
                centerX: {
                    get: function () {
                        return ~~(this.left + this.width / 2);
                    }, set: function (x) {
                        this.left = ~~(x - this.width / 2);
                    }
                }, centerY: {
                    get: function () {
                        return ~~(this.top + this.height / 2);
                    }, set: function (y) {
                        this.top = ~~(y - this.height / 2);
                    }
                }, id: {
                    get: function () {
                        return this._id;
                    }, set: function (newId) {
                        this._id = newId;
                    }
                }
            });
            this.setProperty(this.getSettings(settings, ['opacity', 'rotate', 'opacity', 'scaleX', 'scaleY', 'zIndex', 'showBorder', 'visiable', 'id', 'centerX', 'centerY', 'marginLeft', 'isContentCacheable', 'transformX', 'transformY']));
        }, scale: function (scaleX, scaleY) {
            this.scaleX = scaleX;
            this.scaleY = scaleY == undefined ? scaleX : scaleY;
            return this;
        }, getSettings: function (set, keys) {
            if (!keys) {
                return {};
            }
            var childSet = {};
            for (var i = 1, len = keys.length; i < len; i++) {
                if (set[keys[i]] !== undefined) {
                    childSet[keys[i]] = set[keys[i]];
                }
            }
            return childSet;
        }, setProperty: function (property, value) {
            if (typeof property == 'object') {
                for (var i in property) {
                    if (typeof property[i] == 'function')
                        this[i] = property[i].bind(this); else
                        this[i] = property[i];
                }
            } else {
                if (typeof value == 'function')
                    this[property] = value.bind(this); else
                    this[property] = value;
            }
            return this;
        }, isPointInPath: function (x, y) {
            var rect = this.getBoundingClientRect();
            return x >= rect.left && y >= rect.top && x <= rect.left + rect.width && y <= rect.top + rect.height;
        }, getBoundingClientRect: function () {
            if (this.parentNode != null) {
                var parentRect = this.parentNode.getBoundingClientRect();
                return {
                    top: this.top + parentRect.top,
                    left: this.left + parentRect.left,
                    width: this.width,
                    height: this.height
                };
            } else {
                return {top: this.top, left: this.left, width: this.width, height: this.height};
            }
        }, isVisiable: function () {
            return this.visiable;
        }, remove: function () {
            if (this.parentNode)
                this.parentNode.removeChild(this);
            return this;
        }, pushClip: function (callback, delay, duration) {
            if (this._clips == null) {
                this._clips = [];
            }
            this._clips.push({cleared: false, clock: -delay, callback: callback.bind(this), duration: duration || -1});
            return this;
        }, _clipsUpdate: function (dt) {
            for (var i = 0, len = this._clips.length; i < len; i++) {
                this._clips[i].clock += dt;
                if (this._clips[i].clock > 0) {
                    if (this._clips[i].callback(this._clips[i].clock) == true || this._clips[i].clock >= this._clips[i].duration) {
                        this._clips[i].cleared = true;
                    }
                }
            }
            for (var i = this._clips.length - 1; i >= 0; i--) {
                if (this._clips[i].cleared) {
                    this._clips.splice(i, 1);
                    if (this._clips.length == 0) {
                        this._clips = null;
                        break;
                    }
                }
            }
        }, appendTo: function (world) {
            world.appendChild(this);
            return this;
        }, update: function (dt) {
        }, draw: function (ctx) {
        }, destory: function () {
            if (this.cacheImage != null) {
                this.cacheImage.remove && this.cacheImage.remove();
            }
        }
    });
    g.Container = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.children = [];
        }, removeAllChild: function () {
            for (var j = this.children.length - 1; j >= 0; j--) {
                if (this.children[j].destory)
                    this.children[j].destory();
            }
            this.children = [];
            this.isDirty = true;
            return this;
        }, appendChild: function () {
            for (var i = 0; i < arguments.length; i++) {
                var isInsert = false;
                for (var j = this.children.length - 1; j >= 0; j--) {
                    if (this.children[j].zIndex <= arguments[i].zIndex) {
                        this.children.splice(j + 1, 0, arguments[i]);
                        isInsert = true;
                        break;
                    }
                }
                if (isInsert == false) {
                    this.children.unshift(arguments[i]);
                }
                arguments[i].parentNode = this;
            }
            this.isDirty = true;
            return this;
        }, removeChild: function (o) {
            for (var i = 0; i < this.children.length; i++) {
                if (this.children[i] == o) {
                    this.children.splice(i, 1);
                    if (o.destory)
                        o.destory();
                    break;
                }
            }
            this.isDirty = true;
            return this;
        }
    });
    g.Sprite = g.Renderable.extend({
        init: function (settings) {
            this.image = settings.image;
            settings.width = settings.width == undefined ? this.image.width : settings.width;
            settings.height = settings.height == undefined ? this.image.height : settings.height;
            this._super(g.Renderable, 'init', [settings]);
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
        }, draw: function (ctx) {
            ctx.drawImage(this.image, this.sx, this.sy, this.width, this.height, 0, 0, this.width, this.height);
        }
    });
    g.AnimateSheet = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.speed = settings.speed;
            this.frames = settings.frames;
            this.lineFrames = settings.lineFrames;
            this._currentAnimate = 'default';
            this._currentAnimateIndex = 0;
            this._currentFrame = -1;
            this._playTimes = Infinity;
            this._timeEndCallback = null;
            this.isStart = false;
            this.animates = {};
            this.clock = 0;
            this._maps = [];
            for (var i = 0; i < this.frames; i++) {
                this._maps[i] = {
                    sx: (i % this.lineFrames) * this.width + this.sx,
                    sy: (~~(i / this.lineFrames)) * this.height + this.sy
                };
            }
            this.addAnimate('default', [-1]);
            this.setCurrentAnimate('default');
        }, update: function (dt) {
            if (!this.isStart) {
                return;
            }
            this.clock += dt;
            if (this.clock > this.animates[this._currentAnimate].speed && this.animates[this._currentAnimate].frames.length > 1) {
                this.clock -= this.animates[this._currentAnimate].speed;
                this._currentAnimateIndex++;
                if (this._currentAnimateIndex > this.animates[this._currentAnimate].frames.length - 1) {
                    this._currentAnimateIndex = 0;
                    this._playTimes -= 1;
                    if (this._playTimes <= 0) {
                        this.isStart = false;
                        typeof this._timeEndCallback == 'function' && this._timeEndCallback.call(this);
                    }
                }
                this._currentFrame = this.animates[this._currentAnimate].frames[this._currentAnimateIndex];
                this.isDirty = true;
            }
        }, addAnimate: function (name, index, speed) {
            if (index.length == 0) {
                index = [-1];
            }
            this.animates[name] = {name: name, frames: index, speed: speed || this.speed};
            return this;
        }, setCurrentAnimate: function (name, times, callback) {
            this.clock = 0;
            this._currentAnimate = name;
            this._currentAnimateIndex = 0;
            this._currentFrame = this.animates[name].frames[0];
            this._playTimes = times || Infinity;
            this._timeEndCallback = callback || null;
            this.isStart = true;
            return this;
        }, getCurrentAnimate: function () {
            return this._currentAnimate;
        }, setCurrentAnimateIndex: function (index) {
            this._currentAnimateIndex = index;
            if (this._currentAnimateIndex > this.animates[this._currentAnimate].frames.length - 1) {
                this._currentAnimateIndex = 0;
            }
        }, draw: function (ctx) {
            if (this._currentFrame >= 0 && this.isStart) {
                ctx.drawImage(this.image, this._maps[this._currentFrame].sx, this._maps[this._currentFrame].sy, this.width, this.height, 0, 0, this.width, this.height);
            }
        }
    });
    (function () {
        g.animate = new g.Renderable({});
        g.animate.push = g.animate.pushClip;
        g.timer.setInterval(function (dt, clock) {
            if (g.animate._clips != null) {
                g.animate._clipsUpdate(dt);
            }
        });
    })();
    g.Debug = g.Renderable.extend({
        init: function (settings) {
            settings = settings || {};
            this._super(g.Renderable, 'init', [{zIndex: 100000, top: 0, left: 0, width: 160, height: 42}]);
            this.font = new g.Font({fontFamily: 'microsoft yahei', fontSize: 12, color: '#FFF'});
            this.view = settings.view || g.view;
        }, draw: function (ctx) {
            ctx.save();
            if (this.top != 0 || this.left != 0)
                ctx.translate(this.top, this.left);
            ctx.fillStyle = 'rgba(0, 0, 0)';
            ctx.fillRect(0, 0, this.width, this.height);
            this.font.draw(ctx, 'udt: ' + this.view.debug.updateTime.toFixed(2) + 'ms', 0, 0, 'left');
            this.font.draw(ctx, 'draw: ' + this.view.debug.drawTime.toFixed(2) + 'ms', 0, 14, 'left');
            this.font.draw(ctx, 'objs: ' + this.view.debug.objs, 0, 28, 'left');
            this.font.draw(ctx, 'draws: ' + this.view.debug.draws, 90, 28, 'left');
            this.font.draw(ctx, 'ufps: ' + this.view.debug.updateFps, 90, 0, 'left');
            this.font.draw(ctx, 'dfps: ' + this.view.debug.drawFps, 90, 14, 'left');
            ctx.restore();
        }
    });
    (function () {
        var events = [];
        var tempMouseDown = [];
        var mousedownElements = [];
        var mouseoverElements = [];
        g.event = {
            init: function (canvas) {
                function mouseDown(x, y, event) {
                    var myEvent = {clientX: x, clientY: y};
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mousedown || events[i].click) && events[i].target.isVisiable()) {
                            if (events[i].target.isPointInPath(x, y)) {
                                if (events[i].mousedown)
                                    for (var j = 0, len1 = events[i].mousedown.length; j < len1; j++)
                                        events[i].mousedown[j](myEvent);
                                if (events[i].click) {
                                    tempMouseDown.push(events[i]);
                                    events[i].isMouseDown = true;
                                }
                            }
                        }
                    }
                }

                function mouseUp(x, y, event) {
                    var myEvent = {clientX: x, clientY: y};
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mouseup || events[i].click) && events[i].target.isVisiable()) {
                            if (events[i].target.isPointInPath(x, y)) {
                                if (events[i].mouseup)
                                    for (var j = 0, len1 = events[i].mouseup.length; j < len1; j++)
                                        events[i].mouseup[j](myEvent);
                                if (events[i].click && events[i].isMouseDown == true)
                                    for (var j = 0, len1 = events[i].click.length; j < len1; j++)
                                        events[i].click[j](myEvent);
                            }
                        }
                    }
                    for (var i = 0, len = tempMouseDown.length; i < len; i++) {
                        tempMouseDown[i].isMouseDown = undefined;
                    }
                    tempMouseDown = [];
                }

                function mouseMove(x, y, event) {
                    var myEvent = {clientX: x, clientY: y};
                    var overCalls = [];
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mousemove || events[i].mouseover || events[i].mouseout) && events[i].target.isVisiable()) {
                            if (events[i].target.isPointInPath(x, y)) {
                                if (events[i].mousemove)
                                    for (var j = 0, len1 = events[i].mousemove.length; j < len1; j++)
                                        events[i].mousemove[j](myEvent);
                                if (events[i].mouseover && events[i].isMouseOver != true) {
                                    for (var j = 0, len1 = events[i].mouseover.length; j < len1; j++)
                                        overCalls.push(events[i].mouseover[j])
                                }
                                events[i].isMouseOver = true;
                            } else if (events[i].isMouseOver) {
                                events[i].isMouseOver = undefined;
                                if (events[i].mouseout)
                                    for (var j = 0, len1 = events[i].mouseout.length; j < len1; j++)
                                        events[i].mouseout[j](myEvent);
                            }
                        }
                    }
                    for (var i = 0, len = overCalls.length; i < len; i++) {
                        overCalls[i]();
                    }
                }

                function mouseOut() {
                    var myEvent = {};
                    for (var i = 0, len = tempMouseDown.length; i < len; i++) {
                        tempMouseDown[i].isMouseDown = undefined;
                    }
                    for (var i = 0, len = events.length; i < len; i++) {
                        if ((events[i].mouseover || events[i].mouseout) && events[i].isMouseOver == true) {
                            if (events[i].target.isVisiable()) {
                                for (var j = 0, len1 = events[i].mouseout.length; j < len1; j++)
                                    events[i].mouseout[j]();
                                events[i].isMouseOver = undefined;
                            }
                        }
                    }
                }

                canvas.addEventListener('mousemove', function (event) {
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.clientX - left0;
                    var y = event.clientY - top0;
                    mouseMove(x, y, event);
                });
                canvas.addEventListener('mousedown', function (event) {
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.clientX - left0;
                    var y = event.clientY - top0;
                    mouseDown(x, y, event);
                });
                canvas.addEventListener('mouseup', function (event) {
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.clientX - left0;
                    var y = event.clientY - top0;
                    mouseUp(x, y, event);
                });
                canvas.addEventListener('mouseout', function (event) {
                    mouseOut();
                });
                canvas.addEventListener('touchmove', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.changedTouches[0].clientX - left0;
                    var y = event.changedTouches[0].clientY - top0;
                    mouseMove(x, y, event);
                });
                canvas.addEventListener('touchstart', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.changedTouches[0].clientX - left0;
                    var y = event.changedTouches[0].clientY - top0;
                    mouseDown(x, y, event);
                });
                canvas.addEventListener('touchend', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    var top0 = this.getBoundingClientRect().top;
                    var left0 = this.getBoundingClientRect().left;
                    var x = event.changedTouches[0].clientX - left0;
                    var y = event.changedTouches[0].clientY - top0;
                    mouseUp(x, y, event);
                });
            }, bind: function (target, type, handle) {
                var t = null;
                for (var i = 0, len = events.length; i < len; i++) {
                    if (events[i].target == target)
                        t = events[i];
                }
                if (t == null) {
                    t = {target: target, handles: 0}
                    events.push(t);
                }
                if (t[type] == undefined)
                    t[type] = [];
                t[type].push(handle);
                t.handles += 1;
                t = null;
                return this;
            }, unbind: function (target, type, handle) {
                for (var i = 0, len = events.length; i < len; i++) {
                    if (events[i].target == target) {
                        if (handle == undefined) {
                            events.splice(i, 1);
                            return;
                        } else {
                            for (var j = 0, len1 = events[i][type].length; j < len; j++) {
                                if (events[i][type][j] == handle) {
                                    events[i][type].splice(j, 1);
                                    events[i].handles -= 1;
                                    j--;
                                    len1--;
                                    if (events[i].handles == 0) {
                                        events.splice(i, 1);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }, call: function (target, type) {
                for (var i = 0, len = events.length; i < len; i++) {
                    if (events[i].target == target) {
                        for (var j = 0, lenj = events[i][type].length; i < lenj; j++) {
                            events[i][type][j]();
                        }
                    }
                }
            }
        };
    })();
    g.loadImage = function (resources, callback) {
        var reses = resources;
        if (typeof resources == 'string') {
            reses = {'default': resources};
        }
        var loading_count = 0;
        var images = {};
        for (i in reses) {
            loading_count++;
            var src = reses[i];
            images[i] = new Image();
            images[i].src = src;
            images[i].onload = function () {
                loading_count--;
                this.isLoad = true;
                if (loading_count == 0) {
                    typeof callback == 'function' ? callback(images) : '';
                }
            }
        }
        if (typeof resources == 'string') {
            return images['default'];
        } else {
            return images;
        }
    };
    g.divideImage = function (resources, callback) {
        var res = {};
        for (var i in resources) {
            res[i] = g.TheView.prototype.toImage(function (ctx) {
                ctx.drawImage(resources[i][0], resources[i][1], resources[i][2], resources[i][3], resources[i][4], 0, 0, resources[i][3], resources[i][4]);
            }, resources[i][3], resources[i][4]);
        }
        return res;
    };
    (function () {
        g.m = new function () {
            var objects = {};

            function get(e) {
                if (objects[e] == null)
                    objects[e] = [];
                return objects[e];
            }

            this.listen = function (e, callback) {
                if (e == null)
                    get("*").push({callback: callback}); else if (typeof(e) == "array") {
                    for (var i = 0; i < e.length; i++)
                        get(e[i]).push({callback: callback});
                }
                else {
                    get(e).push({callback: callback});
                }
                return this;
            }
            this.remove = function (e, callback) {
                for (var evt in objects) {
                    if (evt == e || e == undefined) {
                        for (var i = 0; i < objects[evt].length; i++) {
                            if (objects[evt][i].callback == callback) {
                                objects[evt].splice(i, 1);
                                break;
                            }
                        }
                    }
                }
                return this;
            }
            this.send = function (e, args) {
                var i, j;
                var controls = get(e);
                for (var i = 0; i < controls.length; i++) {
                    if (controls[i].callback(args) == true)
                        return this;
                }
                controls = get("*");
                for (var i = 0; i < controls.length; i++) {
                    if (controls[i].callback(args) == true)
                        break;
                }
                return this;
            }
        };
    })();
    g.TheView = Object.extend({
        init: function (mixValue, width, height) {
            this.canvas = typeof mixValue == 'string' ? document.getElementById(mixValue) : mixValue;
            this.canvas.width = width || this.canvas.clientWidth;
            this.canvas.height = height || this.canvas.clientHeight;
            this.context = this.canvas.getContext('2d');
            this.world = new g.Container({width: this.canvas.width, height: this.canvas.height});
            this.fps = 60;
            this.fpsCountClock = 0;
            this.updateFps = 0;
            this.drawFps = 0;
            this.draws = 0;
            this.debug = {objs: 0, draws: 0, drawTime: 0, updateTime: 0, drawFps: 0, updateFps: 0};
            this.isPause = false;
            this.isDirty = false;
            this.cursors = [];
            this.isShowDebugPanel = false;
            this.clearBeforeDraw = false;
        }, showDebugPanel: function (x, y) {
            this.isShowDebugPanel = true;
            this.debugPanel = new g.Debug({top: y, left: x, view: this});
        }, setCursor: function (cursor) {
            this.canvas.style.cursor = cursor;
        }, saveCursor: function () {
            this.cursors.push(this.canvas.style.cursor);
        }, restoreCursor: function () {
            if (this.cursors.length > 0) {
                this.canvas.style.cursor = this.cursors.pop();
            }
        }, update: function (dt) {
            if (this.world != null && this.isPause == false) {
                this.updateFps++;
                this.debug.objs = 0;
                var start = window.performance.now();
                this.__updateContainer(this.world, dt);
                this.debug.updateTime = window.performance.now() - start;
            }
            this.fpsCountClock += dt;
            if (this.fpsCountClock >= 1000) {
                this.debug.updateFps = this.updateFps;
                this.debug.drawFps = this.drawFps;
                this.fpsCountClock -= 1000;
                this.updateFps = 0;
                this.drawFps = 0;
            }
        }, __updateContainer: function (container, dt) {
            for (var i = 0, len = container.children.length; i < len; i++) {
                this.debug.objs++;
                container.children[i].update(dt);
                if (container.children[i]._clips != null)
                    container.children[i]._clipsUpdate(dt);
                if (container.children[i] instanceof g.Container)
                    this.__updateContainer(container.children[i], dt);
                if (container.children[i].isMoved) {
                    container.isMoved = true;
                    container.isDirty = true;
                }
                if (container.children[i].isDirty) {
                    container.isDirty = true;
                }
            }
        }, draw: function () {
            if (this.world != null && this.isPause == false && this.world.isDirty == true) {
                this.debug.draws = 0;
                this.drawFps++;
                var start = window.performance.now();
                if (this.clearBeforeDraw)
                    this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
                this.__drawContainer(this.world, this.context, true);
                this.world.isDirty = false;
                this.debug.drawTime = window.performance.now() - start;
            }
            if (this.isShowDebugPanel)
                this.debugPanel.draw(this.context);
        }, __drawContainer: function (container, ctx, cacheAble) {
            for (var i = 0, len = container.children.length; i < len; i++) {
                var o = container.children[i];
                if (o.visiable == false)
                    continue;
                this.debug.draws++;
                ctx.save();
                if (o.opacity != 1)
                    ctx.globalAlpha *= o.opacity;
                if (o.scaleX != 1 || o.scaleY != 1 || o.rotate != 0) {
                    ctx.translate(o.left + o.transformX, o.top + o.transformY);
                    if (o.scaleX != 1 || o.scaleY != 1)
                        ctx.scale(o.scaleX, o.scaleY);
                    if (o.rotate != 0)
                        ctx.rotate(o.rotate);
                    ctx.translate(-o.transformX, -o.transformY);
                } else {
                    ctx.translate(o.left, o.top);
                }
                if (cacheAble == true && o.isContentCacheable && o.width > 0 && o.height > 0) {
                    if (o.cacheImage == null) {
                        if (o instanceof g.Container) {
                            o.cacheImage = this.toImage(function () {
                            }, o.width, o.height, o.cacheMargin);
                            this.__drawContainer(o, o.cacheImage.getContext('2d'), false);
                        } else {
                            o.cacheImage = this.toImage(o.draw.bind(o), o.width, o.height, o.cacheMargin);
                        }
                    }
                    else {
                        if (o.isDirty) {
                            if (o.width + o.cacheMargin * 2 != o.cacheImage.width || o.height + o.cacheMargin * 2 != o.cacheImage.height) {
                                o.cacheImage.width = o.width + o.cacheMargin * 2;
                                o.cacheImage.height = o.height + o.cacheMargin * 2;
                                if (o.cacheMargin > 0) {
                                    o.cacheImage.getContext('2d').translate(o.cacheMargin, o.cacheMargin);
                                }
                            } else {
                                o.cacheImage.getContext('2d').clearRect(0, 0, o.cacheImage.width, o.cacheImage.height);
                            }
                            if (o instanceof g.Container) {
                                this.__drawContainer(o, o.cacheImage.getContext('2d'), false);
                            } else {
                                o.draw(o.cacheImage.getContext('2d'));
                            }
                        }
                    }
                    try {
                        ctx.drawImage(o.cacheImage, -o.cacheMargin, -o.cacheMargin);
                    } catch (e) {
                        if (!o.isDisplayError) {
                            o.isDisplayError = true;
                            console.log(o);
                        }
                    }
                } else {
                    if (o instanceof g.Container) {
                        this.__drawContainer(o, ctx, true);
                    } else {
                        o.draw(ctx);
                    }
                }
                o.isDirty = false;
                o.isMoved = false;
                if (o.showBorder) {
                    ctx.save();
                    ctx.strokeStyle = '#f00';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(0, 0, o.width, o.height);
                    ctx.restore();
                }
                ctx.restore();
            }
        }, toImage: function (drawFunc, width, height, cacheMargin) {
            var c = document.createElement('canvas');
            var ctx = c.getContext('2d');
            cacheMargin = cacheMargin || 0;
            c.width = width + cacheMargin * 2;
            c.height = height + cacheMargin * 2;
            if (cacheMargin > 0)
                ctx.translate(cacheMargin, cacheMargin);
            drawFunc(ctx);
            return c;
        }, pause: function () {
            this.isPause = true;
        }, resume: function () {
            this.isPause = false;
        }
    });
    (function () {
        g.easing = function (percent, from, to, method) {
            percent = percent > 1 ? 1 : (percent < 0 ? 0 : percent);
            return method(percent) * (to - from) + from;
        };
        g.easing.Quadratic = {
            In: function (k) {
                return k * k;
            }, Out: function (k) {
                return k * (2 - k);
            }, InOut: function (k) {
                if ((k *= 2) < 1)
                    return 0.5 * k * k;
                return -0.5 * (--k * (k - 2) - 1);
            }
        };
        g.easing.Linear = {
            In: function (k) {
                return k;
            }, Out: function (k) {
                return k;
            }
        };
        g.easing.Cubic = {
            In: function (k) {
                return k * k * k;
            }, Out: function (k) {
                return --k * k * k + 1;
            }, InOut: function (k) {
                if ((k *= 2) < 1)
                    return 0.5 * k * k * k;
                return 0.5 * ((k -= 2) * k * k + 2);
            }
        };
        g.easing.Bounce = {
            In: function (k) {
                return 1 - easing.Bounce.Out(1 - k);
            }, Out: function (k) {
                if (k < (1 / 2.75)) {
                    return 7.5625 * k * k;
                } else if (k < (2 / 2.75)) {
                    return 7.5625 * (k -= (1.5 / 2.75)) * k + 0.75;
                } else if (k < (2.5 / 2.75)) {
                    return 7.5625 * (k -= (2.25 / 2.75)) * k + 0.9375;
                } else {
                    return 7.5625 * (k -= (2.625 / 2.75)) * k + 0.984375;
                }
            }, InOut: function (k) {
                if (k < 0.5)
                    return easing.Bounce.In(k * 2) * 0.5;
                return easing.Bounce.Out(k * 2 - 1) * 0.5 + 0.5;
            }
        };
        g.easing.Elastic = {
            In: function (k) {
                var s, a = 0.1, p = 0.4;
                if (k === 0) return 0;
                if (k === 1) return 1;
                if (!a || a < 1) {
                    a = 1;
                    s = p / 4;
                }
                else s = p * Math.asin(1 / a) / (2 * Math.PI);
                return -(a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
            }, Out: function (k) {
                var s, a = 0.1, p = 0.4;
                if (k === 0) return 0;
                if (k === 1) return 1;
                if (!a || a < 1) {
                    a = 1;
                    s = p / 4;
                }
                else s = p * Math.asin(1 / a) / (2 * Math.PI);
                return (a * Math.pow(2, -10 * k) * Math.sin((k - s) * (2 * Math.PI) / p) + 1);
            }, InOut: function (k) {
                var s, a = 0.1, p = 0.4;
                if (k === 0) return 0;
                if (k === 1) return 1;
                if (!a || a < 1) {
                    a = 1;
                    s = p / 4;
                }
                else s = p * Math.asin(1 / a) / (2 * Math.PI);
                if ((k *= 2) < 1) return -0.5 * (a * Math.pow(2, 10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p));
                return a * Math.pow(2, -10 * (k -= 1)) * Math.sin((k - s) * (2 * Math.PI) / p) * 0.5 + 1;
            }
        };
    })();
    g.ComplexBitmapFont = g.Font.extend({
        init: function (settings) {
            this._super(g.Font, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.fontSize = settings.fontSize;
            this.size = this.fontSize;
            this.chars = settings.chars || '';
            this.numbers = this.chars.length;
            this.numbersPerRow = settings.numbersPerRow || this.numbers;
            this.charsWidth = settings.charsWidth || this.fontSize.x;
            if (!isNaN(this.charsWidth)) {
                var temp = this.charsWidth;
                this.charsWidth = [];
                for (var i = 0, len = this.numbers; i < len; i++) {
                    this.charsWidth.push(temp);
                }
            }
            this.margin = settings.margin || 0;
            this.padding = settings.padding || 0;
            this._maps = {};
            var sx = 0;
            var lineCount = 0;
            var lines = 0;
            for (var i = 0, len = this.numbers; i < len; i++) {
                var c = this.chars.charAt(i);
                lineCount++;
                if (lineCount > this.numbersPerRow) {
                    lineCount = 1;
                    sx = 0;
                    lines++;
                }
                sx += this.margin;
                this._maps[c] = {sx: sx + this.sx, sy: this.fontSize.y * lines + this.sy, width: this.charsWidth[i]};
                sx += this.charsWidth[i];
            }
            this.textBaseline = 'top';
            this.isDraw = false;
        }, measureText: function (ctx, text) {
            var width = 0;
            for (var i = 0, len = text.length; i < len; i++) {
                width += this._maps[text.charAt(i)].width;
            }
            return {width: width, height: this.fontSize.y};
        }, draw: function (ctx, text, x, y, textAlign) {
            text = text + "";
            var width = 0, height = this.size.y;
            for (var i = 0, len = text.length; i < len; i++) {
                width += this._maps[text.charAt(i)].width;
            }
            if (textAlign == 'right')
                x -= width; else if (textAlign == 'center')
                x -= ~~(width * 0.5);
            if (this.textBaseline == 'middle')
                y -= ~~(height * 0.5); else if (this.textBaseline == 'top')
                y = y; else
                y -= height;
            if (this.padding == 0) {
                for (var i = 0, len = text.length; i < len; i++) {
                    var c = text.charAt(i);
                    ctx.drawImage(this.image, this._maps[c].sx, this._maps[c].sy, this._maps[c].width, height, x, y, this._maps[c].width, height);
                    x += this._maps[c].width;
                }
            } else {
                for (var i = 0, len = text.length; i < len; i++) {
                    var c = text.charAt(i);
                    ctx.drawImage(this.image, this._maps[c].sx - this.padding, this._maps[c].sy, this._maps[c].width + this.padding + this.padding, height, x - this.padding, y, this._maps[c].width + this.padding + this.padding, height);
                    x += this._maps[c].width;
                }
            }
        }
    });
    g.LightRotate = g.Sprite.extend({
        init: function (settings) {
            this.lightWidth = settings.lightWidth || settings.image.width;
            this.lightLength = settings.lightLength || settings.image.height;
            settings.width = this.lightLength * 2;
            settings.height = this.lightLength * 2;
            this._super(g.Sprite, 'init', [settings]);
            this.lightNumber = settings.lightNumber;
            this.antiClock = settings.antiClock === undefined ? false : settings.antiClock;
            this.duration = settings.duration === undefined ? Infinity : settings.duration;
            this.phase = settings.phase || 0;
            this.rotate = this.phase;
            this.clock = 0;
            this.isContentCacheable = true;
        }, update: function (dt) {
            if (this.duration != Infinity) {
                this.clock += dt;
                this.rotate = this.phase + (this.clock / this.duration) * Math.PI * 2 * (this.antiClock == true ? 1 : -1);
                this.isMoved = true;
            }
        }, draw: function (ctx) {
            ctx.translate(~~(this.width / 2), ~~(this.height / 2));
            for (var i = 0; i < this.lightNumber; i++) {
                ctx.rotate(Math.PI * 2 / this.lightNumber);
                ctx.drawImage(this.image, this.sx, this.sy, this.lightWidth, this.lightLength, ~~(-this.lightWidth / 2), -this.lightLength, this.lightWidth, this.lightLength);
            }
        }
    });
    g.StreamContainer = g.Container.extend({
        init: function (settings) {
            settings.width = 0;
            settings.height = 0;
            this._super(g.Container, 'init', [settings]);
            this.textAlign = settings.textAlign || 'left';
        }, appendChild: function () {
            this._super(g.Container, 'appendChild', arguments);
            var orignWidth = this.width;
            for (var i = 0, len = arguments.length; i < len; i++) {
                arguments[i].left = this.width + (arguments[i].marginLeft || 0);
                this.width += arguments[i].width + (arguments[i].marginLeft || 0);
                this.height = arguments[i].height + arguments[i].top > this.height ? arguments[i].height + arguments[i].top : this.height
            }
            if (this.textAlign == 'center') {
                this.left -= ~~((this.width - orignWidth) / 2);
            } else if (this.textAlign == 'right') {
                this.left -= this.width - orignWidth;
            }
            return this;
        }
    });
    g.TextRender = g.Renderable.extend({
        init: function (settings) {
            this.font = settings.font;
            this._text = settings.text || '';
            this.textAlign = settings.textAlign || 'left';
            settings.height = this.font.size.y;
            this._super(g.Renderable, 'init', [settings]);
            this.calSize();
            Object.defineProperties(this, {
                text: {
                    get: function () {
                        return this._text;
                    }, set: function (s) {
                        this._text = s;
                        this.isDirty = true;
                        this.calSize();
                    }
                }
            });
            this.isContentCacheable = true;
            this.cacheMargin = this.font.size.x || 0;
        }, calSize: function () {
            var oldWidth = this.width;
            this.width = this.font.measureText(g.views[0].context, this._text).width;
            if (this.width != oldWidth && this.textAlign != 'left') {
                if (this.textAlign == 'center') {
                    this.left -= ~~((this.width - oldWidth) / 2);
                } else if (this.textAlign == 'right') {
                    this.left -= this.width - oldWidth;
                }
                this.isMoved = true;
            }
        }, draw: function (ctx) {
            this.font.draw(ctx, this.text, 0, 0, 'left');
        }
    });
    g.Background = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.color = settings.color;
        }, draw: function (ctx) {
            ctx.fillStyle = this.color;
            ctx.fillRect(0, 0, this.width, this.height);
        }
    });
    g.FloatContainer = g.Container.extend({
        init: function (settings) {
            this._super(g.Container, 'init', [settings]);
            this.clock = 0;
            this.orignTop = this.top;
            this.targetTop = this.top - this.height * 2;
        }, update: function (dt) {
            this.clock += dt;
            this.top = g.easing(this.clock / 1200, this.orignTop, this.targetTop, g.easing.Linear.Out);
            if (this.clock > 600) {
                this.opacity = g.easing((this.clock - 600) / 600, 1, 0, g.easing.Quadratic.Out);
            }
            if (this.clock > 1200) {
                this.remove.defer(this);
            }
            this.isMoved = true;
        }
    });
    g.FloatText = g.TextRender.extend({
        init: function (settings) {
            this._super(g.TextRender, 'init', [settings]);
            this.clock = 0;
            this.orignTop = this.top;
            this.targetTop = this.top - (settings.offset || this.font.size.y * 2);
            this.duration = settings.duration || 1200;
            this.halfDuraion = this.duration / 2;
        }, update: function (dt) {
            this.clock += dt;
            this.top = g.easing(this.clock / this.duration, this.orignTop, this.targetTop, g.easing.Linear.Out);
            if (this.clock > this.halfDuraion)
                this.opacity = g.easing((this.clock - this.halfDuraion) / this.halfDuraion, 1, 0, g.easing.Quadratic.Out);
            if (this.clock > this.duration)
                this.remove.defer(this);
            this.isMoved = true;
        }
    });
    g.ShadowFont = g.Font.extend({
        init: function (settings) {
            this._super(g.Font, 'init', [settings]);
            this.padding = this.shadowWidth || 0;
            this.shadowWidth = settings.shadowWidth;
            this.shadowColor = settings.shadowColor;
            this.shadows = [[this.shadowWidth, 0, 0, this.shadowColor], [0, this.shadowWidth, 0, this.shadowColor], [-this.shadowWidth, 0, 0, this.shadowColor], [0, -this.shadowWidth, 0, this.shadowColor], [this.shadowWidth, 0, this.shadowWidth, this.shadowColor], [0, this.shadowWidth, this.shadowWidth, this.shadowColor], [-this.shadowWidth, 0, this.shadowWidth, this.shadowColor], [0, -this.shadowWidth, this.shadowWidth, this.shadowColor]];
        }, draw: function (ctx, text, x, y, textAlign) {
            ctx.font = this.font;
            ctx.fillStyle = this.color;
            ctx.textAlign = textAlign == undefined ? 'left' : textAlign;
            ctx.textBaseline = this.textBaseline;
            var strings = ('' + text).split("\n");
            for (var i = 0; i < strings.length; i++) {
                for (var j in this.shadows) {
                    ctx.shadowOffsetX = this.shadows[j][0];
                    ctx.shadowOffsetY = this.shadows[j][1];
                    ctx.shadowBlur = this.shadows[j][2];
                    ctx.shadowColor = this.shadows[j][3];
                    ctx.fillText(strings[i], ~~x, ~~(y + this.size.y * this.lineHeight / 2));
                }
                y += this.size.y * this.lineHeight;
            }
        }
    });
    g.ImageRender = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings])
            this.isLoad = false;
            var self = this;
            var images = g.loadImage({'one': settings.src}, function () {
                self.isLoad = true;
                self.isDirty = true;
            });
            this.image = images['one'];
        }, draw: function (ctx) {
            if (!this.isLoad)
                return
            ctx.drawImage(this.image, 0, 0, this.width, this.height);
        }
    });
    g.ParticleBlow = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.sw = settings.sw || 0;
            this.sh = settings.sh || 0;
            this.x0 = settings.x0 || ~~(this.width / 2);
            this.y0 = settings.y0 || ~~(this.height / 2);
            this.xRange = settings.xRange || 0;
            this.vxRange = settings.vxRange || 0;
            this.v0 = settings.v0 || 0.9;
            this.divergeAngle = settings.divergeAngle || Math.PI / 6;
            this.vxMax = Math.sin(settings.divergeAngle) * this.v0;
            this.damp = settings.damp || 0.002;
            this.numbers = settings.numbers || 0;
            this.diffTime = settings.diffTime || 10;
            this.accelerate = settings.accelerate || 0;
            this.scaleMax = settings.scaleMax || 1.2;
            this.scaleMin = settings.scaleMin || 0.8;
            this.objs = [];
            for (var i = 0; i < this.numbers; i++) {
                var temp = {
                    t0: i * this.diffTime,
                    lifeTime: Math.rand(400, 600),
                    vx: Math.rand(0, this.vxMax),
                    vxd: Math.random() > 0.5 ? 1 : -1,
                    vyd: -1,
                    y0: -Math.random() * 40,
                    dx: 0,
                    dy: 0,
                    isDisplay: false,
                    scale: Math.rand(this.scaleMin, this.scaleMax),
                    opacity: 1
                }
                temp.vx *= temp.vxd;
                temp.x0 = Math.random() * this.xRange / 2 * temp.vxd, temp.vy = Math.sqrt((this.v0 - temp.vx) * (this.v0 + temp.vx)) * temp.vyd;
                this.objs.push(temp);
            }
            ;this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            if (this.objs.length > 0) {
                this.isDirty = true;
            }
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i], t1 = this.clock - temp.t0;
                temp.isDisplay = t1 >= 0;
                if (t1 < 0)
                    continue;
                temp.dx = t1 * temp.vx;
                temp.dy = temp.vy * t1 + 0.5 * this.accelerate * t1 * t1;
                if (temp.lifeTime < t1) {
                    if ((t1 - temp.lifeTime) > 400) {
                        this.objs.splice(i, 1);
                        i--;
                        len--;
                    } else {
                        temp.opacity = g.easing((t1 - temp.lifeTime) / 400, 1, 0, g.easing.Quadratic.Out);
                    }
                }
                if (len <= 0) {
                    this.remove.defer(this);
                }
            }
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            for (var i = 0, len = this.objs.length; i < len; i++) {
                if (this.objs[i].isDisplay == false)
                    continue;
                if (this.objs[i].opacity != 1) {
                    ctx.save();
                    ctx.globalAlpha *= this.objs[i].opacity;
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].dx + this.objs[i].x0, this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                    ctx.restore();
                } else {
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].dx + this.objs[i].x0, this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                }
            }
        }
    });
    g.ParticleErupt = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.sw = settings.sw || this.image.width;
            this.sh = settings.sh || this.image.height;
            this.x0 = settings.x0 || ~~(this.width / 2);
            this.y0 = settings.y0 || ~~(this.height / 2);
            this.scaleMin = settings.scaleMin || 0.8;
            this.scaleMax = settings.scaleMax || 1.2;
            this.speedUp = settings.speedUp || 1;
            this.xRange = settings.xRange || 0;
            this.v0 = settings.v0 !== undefined ? settings.v0 : 0.9;
            this.vxMax = settings.divergeAngle ? Math.sin(settings.divergeAngle) : 0.4;
            this.accelerate = settings.accelerate || 1.2;
            this.numbers = settings.numbers || 0;
            this.diffTime = settings.diffTime || 10;
            this.objs = [];
            this.frames = settings.frames || 1;
            this.minPeriod = settings.minPeriod || 80;
            this.maxPeriod = settings.maxPeriod || 100;
            for (var i = 0; i < this.numbers; i++) {
                var temp = {
                    t0: i * this.diffTime,
                    vx: Math.rand(0, this.v0 * 0.4),
                    vxd: Math.random() > 0.5 ? 1 : -1,
                    vyd: -1,
                    sx: 0,
                    sy: 0,
                    isDisplay: false,
                    scale: Math.rand(this.scaleMin, this.scaleMax),
                    frame0: ~~Math.rand(0, this.frames + 0.99),
                    frame: 0,
                    period: Math.rand(this.minPeriod, this.maxPeriod)
                }
                temp.vx *= temp.vxd;
                temp.x0 = Math.random() * this.xRange / 2 * temp.vxd, temp.vy = Math.sqrt((this.v0 - temp.vx) * (this.v0 + temp.vx)) * temp.vyd;
                this.objs.push(temp);
            }
            ;this.clock = 0;
        }, update: function (dt) {
            this.clock += dt * this.speedUp;
            var len = this.objs.length;
            if (len > 0)
                this.isDirty = true;
            for (var i = 0; i < len; i++) {
                var temp = this.objs[i], t1 = this.clock - temp.t0;
                temp.isDisplay = t1 >= 0;
                if (t1 < 0)
                    continue;
                temp.frame = (~~(temp.frame0 + t1 / temp.period)) % this.frames;
                temp.sx = temp.vx * t1 + temp.x0;
                temp.sy = temp.vy * t1 + 0.5 * this.accelerate * t1 * t1;
                if (temp.sy > this.height) {
                    this.objs.splice(i, 1);
                    i--;
                    len--;
                }
                if (len <= 0) {
                    this.remove.defer(this);
                }
            }
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            for (var i = 0, len = this.objs.length; i < len; i++) {
                if (this.objs[i].isDisplay == false)
                    continue;
                ctx.drawImage(this.image, this.sx + this.objs[i].frame * this.sw, this.sy, this.sw, this.sh, ~~this.objs[i].sx, ~~this.objs[i].sy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
    g.ParticleFlyInto = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.image = settings.image;
            this.sx = settings.sx || 0;
            this.sy = settings.sy || 0;
            this.sw = settings.sw || 0;
            this.sh = settings.sh || 0;
            this.x0 = settings.x0 || ~~(this.width / 2);
            this.y0 = settings.y0 || ~~(this.height / 2);
            this.targetX = settings.targetX - this.x0;
            this.targetY = settings.targetY - this.y0;
            this.numbers = settings.numbers || 0;
            this.diffTime = settings.diffTime || 150;
            this.objs = [];
            for (var i = 0; i < this.numbers; i++) {
                var temp = {
                    delay: i * this.diffTime,
                    x1: (Math.random() - 0.5) * 40 + 30,
                    y0: -Math.random() * 20,
                    dx: 0,
                    dy: 0,
                    isDisplay: true,
                    scale: Math.rand(0.8, 1.2),
                    scale: 1,
                    opacity: 1
                };
                temp.vx = temp.x1 / 300;
                temp.x2 = -temp.vx * 600;
                temp.y2 = -(temp.y0 + 20);
                this.objs.push(temp);
            }
            ;this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            if (this.objs.length > 0) {
                this.isDirty = true;
            }
            if (this.clock <= 200) {
                for (var i = 0; i < this.objs.length; i++) {
                    var temp = this.objs[i];
                    temp.dx = -temp.vx * this.clock;
                    temp.dy = g.easing(this.clock / 300, -temp.y0, -temp.y0 - 70, g.easing.Quadratic.Out);
                }
            }
            if (this.clock > 200 && this.clock < 600) {
                for (var i = 0; i < this.objs.length; i++) {
                    var temp = this.objs[i];
                    temp.dx = -temp.vx * this.clock;
                    temp.dy = g.easing((this.clock - 300) / 300, -temp.y0 - 70, temp.y2, g.easing.Bounce.Out) + temp.y0;
                }
            }
            if (this.clock > 800) {
                for (var i = 0; i < this.objs.length; i++) {
                    var temp = this.objs[i], t1 = this.clock - 800;
                    temp.dx = g.easing(t1 / (400 + temp.delay), temp.x2, this.targetX, g.easing.Linear.In);
                    temp.dy = g.easing(t1 / (400 + temp.delay), temp.y2, this.targetY, g.easing.Linear.In);
                }
            }
            if (this.clock > 1200 + this.diffTime * this.numbers) {
                this.remove.defer(this);
            }
        }, draw: function (ctx) {
            ctx.translate(this.x0, this.y0);
            for (var i = 0, len = this.objs.length; i < len; i++) {
                if (this.objs[i].isDisplay == false)
                    continue;
                if (this.objs[i].opacity != 1) {
                    ctx.save();
                    ctx.globalAlpha *= this.objs[i].opacity;
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, ~~this.objs[i].dx, ~~this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                    ctx.restore();
                } else {
                    ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, ~~this.objs[i].dx, ~~this.objs[i].dy, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
                }
            }
        }
    });
    g.CountDown = g.TextRender.extend({
        init: function (settings) {
            this._super(g.TextRender, 'init', [settings]);
            this.text = parseInt(this.text);
            this.text += 1;
            this.clock = 1000;
            this.callback = settings.callback;
        }, update: function (dt) {
            this.clock += dt;
            if (this.clock > 1000) {
                this.clock -= 1000;
                if (this.text <= 1) {
                    typeof this.callback == 'function' ? this.callback() : '';
                    this.remove.defer(this);
                } else {
                    this.text -= 1;
                }
            }
        }
    });
    g.CountDownWithEffect = g.TextRender.extend({
        init: function (settings) {
            settings.text = parseInt(settings.text);
            settings.text += 1;
            this._super(g.TextRender, 'init', [settings]);
            this.opacity = 0;
            this.clock = 1000;
            this.callback = settings.callback;
        }, update: function (dt) {
            this.clock += dt;
            if (this.clock > 1000) {
                this.clock -= 1000;
                if (this.text <= 1) {
                    typeof this.callback == 'function' ? this.callback() : '';
                    this.remove.defer(this);
                } else {
                    this.pushClip(function (t) {
                        this.text -= 1;
                        this.opacity = 1;
                        this.isMoved = true;
                        return true;
                    }, 0, -1);
                    this.pushClip(function (t) {
                        this.scale(g.easing(t / 200, 0.6, 1.5, g.easing.Quadratic.In));
                        this.isMoved = true;
                    }, 0, 200);
                    this.pushClip(function (t) {
                        this.scale(g.easing(t / 50, 1.5, 1, g.easing.Quadratic.In));
                        this.isMoved = true;
                    }, 200, 50);
                    this.pushClip(function (t) {
                        this.opacity = 0;
                        this.isMoved = true;
                        return true;
                    }, 900);
                }
            }
        }
    });
    g.ScoreText = g.TextRender.extend({
        init: function (settings) {
            settings.text = '';
            this._super(g.TextRender, 'init', [settings]);
            this.followObj = settings.followObj;
            this.followIndex = settings.followIndex;
            this.text = this.followObj[this.followIndex];
        }, update: function (dt) {
            if (this.followObj[this.followIndex] != this.text) {
                this.text = this.followObj[this.followIndex];
            }
        }
    });
    g.TransitionScoreText = g.ScoreText.extend({
        init: function (settings) {
            settings.text = '';
            this._super(g.ScoreText, 'init', [settings]);
            this.duration = settings.duration || 300;
            this.targetText = this.text;
            this.fromText = this.text;
            this.clock = 0;
        }, update: function (dt) {
            if (this.followObj[this.followIndex] != this.targetText) {
                this.clock = 0;
                this.targetText = this.followObj[this.followIndex];
                this.fromText = this.text;
            }
            if (this.targetText != this.text) {
                this.clock += dt;
                this.text = ~~g.easing(this.clock / this.duration, this.fromText, this.targetText, g.easing.Linear.In);
                return true;
            }
        }
    });
    ;
})();
;
/* 19xijJ.js */
(function () {
    var tuyaApi = {};
    window.showTuya = function () {
        if (!document.createElement('canvas').getContext) {
            return;
        }
        var element = document.getElementById('__tuya');
        if (element == null) {
            tuyaApi = createTuya();
        }
        tuyaApi.active();
        document.getElementById('__tuya').style.display = 'block';
    };
    window.clearTuya = function () {
        if (tuyaApi.clear) {
            tuyaApi.clear();
        }
    };

    function createTuya() {
        var html = ['<style>', '.tuya_btn {margin:10px 15px;cursor:pointer;width:35px;height:35px;}', '.tuya_btn_redo{background:url(http://www.91xiaoyu.com/images/tuya.png) -7px -55px no-repeat;}', '.tuya_btn_redo:active{background-position: -103px -55px;}', '.tuya_btn_redo.tuya_btn_press{background:url(http://www.91xiaoyu.com/images/tuya.png) -55px -55px no-repeat;}', '.tuya_btn_redo.tuya_btn_press:active{background-position: -103px -55px;}', '.tuya_btn_redo.tuya_btn_disable{background:url(http://www.91xiaoyu.com/images/tuya.png) -7px -103px no-repeat;}', '.tuya_btn_redo.tuya_btn_disable:active{background-position: -103px -55px;}', '.tuya_btn_clear{background:url(http://www.91xiaoyu.com/images/tuya.png) -7px -150px no-repeat;}', '.tuya_btn_clear:active{background-position: -103px -150px;}', '.tuya_btn_clear.tuya_btn_press{background:url(http://www.91xiaoyu.com/images/tuya.png) -55px -150px no-repeat;}', '.tuya_btn_clear.tuya_btn_press:active{background-position: -103px -150px;}', '.tuya_btn_close{background:url(http://www.91xiaoyu.com/images/tuya.png) -7px -6px no-repeat;}', '.tuya_btn_close:active{background-position: -103px -6px;}', '.tuya_btn_close.tuya_btn_press{background:url(http://www.91xiaoyu.com/images/tuya.png) -55px -6px no-repeat;}', '.tuya_btn_close.tuya_btn_press:active{background-position: -103px -6px;}', '</style>', '<div id="__tuya" style="z-index:10001;-webkit-touch-callout: none;-webkit-user-select: none;-khtml-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;position:fixed;top:0;left:0;bottom:0;right:0;background:rgba(0,0,0,0.4);" class="no_text_select">', '<canvas id="__tuya_canvas" style="position:absolute;top:0px;left:0;right:0;bottom:0;"></canvas>', '<div class="clearfix" style="position:absolute;background:rgba(0,0,0,0.9);height:55px;width:260px;bottom:0;left:50%;margin-left:-130px;border-radius: 7px 7px 0 0;">', '<div class="tuya_btn tuya_btn_redo tuya_btn_back" style="float:left;-webkit-transform: scale(-1, 1);transform:scale(-1,1);"></div>', '<div class="tuya_btn tuya_btn_redo tuya_btn_forward" style="float:left;"></div>', '<div class="tuya_btn tuya_btn_clear" style="float:left;"></div>', '<div class="tuya_btn tuya_btn_close" style="float:right;"></div>', '</div>', '</div>'].join('');
        $('body').append(html);
        var element = document.getElementById('__tuya');
        var canvas = document.getElementById('__tuya_canvas');
        canvas.width = element.clientWidth;
        canvas.height = element.clientHeight;
        var api = createPaint('__tuya_canvas');
        api.setWidth(5);
        api.setStyle("#f42727");
        var is_pressed = false;
        $(element).find('.tuya_btn').bind('touchstart', function () {
            is_pressed = true;
            $(this).addClass('tuya_btn_press');
        });
        $(document).bind('click', function () {
            if (is_pressed) {
                $(element).find('.tuya_btn').removeClass('tuya_btn_press');
                is_pressed = false;
            }
        });
        $(element).find('.tuya_btn_close').bind('click touchstart', function () {
            element.style.display = 'none';
            api.pause();
            api.clear();
        });
        $(element).find('.tuya_btn_back').bind('click touchstart', function () {
            api.back();
            resetBtn();
        });
        $(element).find('.tuya_btn_forward').bind('click touchstart', function () {
            api.forward();
            resetBtn();
        });
        $(element).find('.tuya_btn_clear').bind('click touchstart', function () {
            api.clear();
            resetBtn();
        });
        resetBtn();
        api.onUpdate(resetBtn);
        var lastCanBack = undefined;
        var lastCanForward = undefined;

        function resetBtn() {
            if (lastCanBack != api.canBack()) {
                lastCanBack = api.canBack();
                if (lastCanBack)
                    $(element).find('.tuya_btn_back').removeClass('tuya_btn_disable'); else
                    $(element).find('.tuya_btn_back').addClass('tuya_btn_disable');
            }
            if (lastCanForward != api.canForward()) {
                lastCanForward = api.canForward();
                if (lastCanForward)
                    $(element).find('.tuya_btn_forward').removeClass('tuya_btn_disable'); else
                    $(element).find('.tuya_btn_forward').addClass('tuya_btn_disable');
            }
        }

        var is_touch = 'ontouchstart' in window;
        var direct = document.body.clientWidth > document.body.clientHeight ? 'horizontal' : 'vertical';
        window.addEventListener('resize', function () {
            var new_direct = document.body.clientWidth > document.body.clientHeight ? 'horizontal' : 'vertical';
            if (is_touch && direct != new_direct) {
                api.verticalTurn();
            } else if (canvas.width < element.clientWidth || canvas.height < element.clientHeight) {
                canvas.width = element.clientWidth;
                canvas.height = element.clientHeight;
                api.redraw();
            }
        });
        return api;
    }
})();

function createPaint(canvasId) {
    try {
        var canvas = document.getElementById(canvasId);
        var context = canvas.getContext('2d');
    } catch (e) {
        return;
    }
    var history = [];
    var historyPos = 0;
    context.strokeStyle = "#000";
    context.lineWidth = 1;
    context.lineCap = 'round';
    context.lineJoin = 'round';
    var color = context.strokeStyle;
    var lineWidth = context.lineWidth;

    function addHistory(path) {
        if (history.length == historyPos) {
            history.push(path);
        } else {
            history.splice(historyPos);
            history.push(path);
        }
        historyPos++;
    }

    function historyCanForward() {
        return history.length > historyPos;
    }

    function historyForward() {
        if (history.length > historyPos) {
            historyPos++;
            historyRedraw();
        }
    }

    function historyCanBack() {
        return historyPos > 0;
    }

    function historyBack() {
        if (historyPos > 0) {
            historyPos--;
            historyRedraw();
        }
    }

    function historyRedraw() {
        context.clearRect(0, 0, canvas.width, canvas.height);
        var start_pos = 0;
        for (var i = historyPos - 1; i >= 0; i--) {
            if (history[i].type == "clear") {
                start_pos = i + 1;
                break;
            }
        }
        for (var i = start_pos; i < historyPos; i++) {
            if (history[i].type != "points") {
                continue;
            }
            context.save();
            context.beginPath();
            context.strokeStyle = history[i].color;
            context.lineWidth = history[i].lineWidth;
            context.moveTo(history[i].points[0].x, history[i].points[0].y);
            for (var j = 1, len = history[i].points.length; j < len; j++) {
                context.lineTo(history[i].points[j].x, history[i].points[j].y);
                context.stroke();
            }
            context.closePath();
            context.restore();
        }
    }

    function _clear() {
        addHistory({'type': "clear"});
        historyRedraw();
    }

    var isStartPaint = false;
    var isLastOut = false;
    var lastMovePoint = {x: 0, y: 0};
    var paths = {type: "points", color: context.strokeStyle, lineWidth: context.lineWidth, points: []};

    function _mousedown(x, y) {
        isStartPaint = true;
        isLastOut = false;
        paths.type = 'points';
        paths.color = context.strokeStyle;
        paths.lineWidth = context.lineWidth;
        paths.points = [];
        paths.points.push({x: x, y: y});
        context.beginPath();
        context.moveTo(x, y);
    }

    function _mousemove(x, y) {
        if (isStartPaint == false) {
            return;
        }
        if (x > canvas.width || x < 0 || y > canvas.hegiht || y < 0) {
            if (isLastOut == false) {
                moveTo(x, y);
            }
            isLastOut = true;
        } else {
            if (isLastOut == true) {
                moveTo(lastMovePoint.x, lastMovePoint.y);
            }
            moveTo(x, y);
            isLastOut = false;
        }
        lastMovePoint = {x: x, y: y};
    }

    function moveTo(x, y) {
        paths.points.push({x: x, y: y});
        context.lineTo(x, y);
        context.stroke();
    }

    function _mouseup() {
        if (isStartPaint == true) {
            isStartPaint = false;
            if (paths.points.length == 1) {
                moveTo(paths.points[0].x + 0.1, paths.points[0].y);
            }
            addHistory(paths);
            paths = {};
            _update();
        }
        return false;
    }

    var update_callback = [];

    function _update() {
        for (var i = 0, len = update_callback.length; i < len; i++) {
            update_callback[i]();
        }
    }

    var isPaused = false;
    var api = {};
    api.pause = function () {
        _mouseup();
        isPaused = true;
    };
    api.active = function () {
        isPaused = false;
    };
    api.clear = function () {
        _mouseup();
        _clear();
    };
    api.setStyle = function (style) {
        context.strokeStyle = style;
        color = style;
    };
    api.setWidth = function (width) {
        context.lineWidth = width;
        lineWidth = width;
    };
    api.back = function () {
        historyBack();
    };
    api.forward = function () {
        historyForward();
    };
    api.canBack = function () {
        return historyCanBack();
    };
    api.canForward = function () {
        return historyCanForward();
    };
    api.onUpdate = function (callback) {
        update_callback.push(callback);
    };
    api.redraw = function () {
        context.strokeStyle = color;
        context.lineWidth = lineWidth;
        context.lineCap = 'round';
        context.lineJoin = 'round';
        historyRedraw();
    };
    api.verticalTurn = function () {
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.scale(-1, 1);
        context.rotate(Math.PI / 2);
        historyRedraw();
    };
    document.addEventListener('mousemove', function (event) {
        if (isPaused == true)
            return true;
        var top0 = canvas.getBoundingClientRect().top;
        var left0 = canvas.getBoundingClientRect().left;
        var x = event.clientX - left0;
        var y = event.clientY - top0;
        _mousemove(x, y);
    });
    document.addEventListener('touchmove', function (event) {
        if (isPaused == true)
            return true;
        event.preventDefault();
        var top0 = canvas.getBoundingClientRect().top;
        var left0 = canvas.getBoundingClientRect().left;
        var x = event.changedTouches[0].clientX - left0;
        var y = event.changedTouches[0].clientY - top0;
        _mousemove(x, y);
    });
    document.addEventListener('mouseup', function () {
        if (isPaused == true)
            return true;
        _mouseup();
    });
    document.addEventListener('touchend', function () {
        if (isPaused == true)
            return true;
        _mouseup();
    });
    [['mousedown', _mousedown], ['mousemove', _mousemove], ['mouseup', _mouseup]].forEach(function (v) {
        canvas.addEventListener(v[0], function (event) {
            if (isPaused == true)
                return;
            event.preventDefault();
            var top0 = this.getBoundingClientRect().top;
            var left0 = this.getBoundingClientRect().left;
            var x = event.clientX - left0;
            var y = event.clientY - top0;
            v[1](x, y);
        });
    });
    [['touchstart', _mousedown], ['touchmove', _mousemove], ['touchend', _mouseup]].forEach(function (v) {
        canvas.addEventListener(v[0], function (event) {
            if (isPaused == true)
                return;
            event.preventDefault();
            var top0 = this.getBoundingClientRect().top;
            var left0 = this.getBoundingClientRect().left;
            var x = event.changedTouches[0].clientX - left0;
            var y = event.changedTouches[0].clientY - top0;
            v[1](x, y);
        });
    });
    return api;
}
;
/* eQkXM.js */
(function () {
    var game = {};
    window.playDoneAnimate = function (wrapper, stars, coins, exps, gems, is_passed, accuracy, duration, answer, task) {
        if (!g.Renderable)
            return;
        game.play(wrapper, stars, coins, exps, gems, is_passed, accuracy, duration, answer, task);
    };
    if (!g.Renderable)
        return;
    $(window).bind('load', function () {
        g.loadImage({
            done: 'http://www.91xiaoyu.com/images/done.png',
            light_right: 'http://www.91xiaoyu.com/images/done_light_right.png',
            light_wrong: 'http://www.91xiaoyu.com/images/done_light_wrong.png',
            star_light: 'http://www.91xiaoyu.com/images/star_light.png',
            star_flash: 'http://www.91xiaoyu.com/images/star_flash.png'
        });
        g.audio.prepare({
            coin: {urls: ['v2/sound/throwcoin.mp3'], preload: true},
            star_1: {urls: ['v2/sound/star_1.mp3'], preload: true},
            star_2: {urls: ['v2/sound/star_2.mp3'], preload: true},
            star_3: {urls: ['v2/sound/star_3.mp3'], preload: true},
            star_get: {urls: ['v2/sound/star_get.mp3'], preload: true},
            stage_success: {urls: ['v2/sound/stage_success.mp3'], preload: true},
            stage_fail: {urls: ['v2/sound/stage_fail.mp3'], preload: true}
        });
    });
    game.data = {coins: 0, gems: 0, exps: 0, stars: 0};
    game.gets = {coins: 0, gems: 0, exps: 0, stars: 0, isRight: 0};
    game.isInit = false;
    game.init = function (wrapper, callback) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', 'done_animate_canvas');
        wrapper.appendChild(canvas);
        var wHeight = window.innerHeight > document.body.scrollHeight ? window.innerHeight : document.body.scrollHeight;
        g.initView('done_animate_canvas', window.innerWidth, wHeight > 670 ? wHeight : 670, false);
        g.view.clearBeforeDraw = true;
        g.loadImage({
            done: 'http://www.91xiaoyu.com/images/done.png',
            light_right: 'http://www.91xiaoyu.com/images/done_light_right.png',
            light_wrong: 'http://www.91xiaoyu.com/images/done_light_wrong.png',
            star_light: 'http://www.91xiaoyu.com/images/star_light.png',
            star_flash: 'http://www.91xiaoyu.com/images/star_flash.png'
        }, function (images) {
            game.images = g.divideImage({
                right: [images.done, 0, 0, 628, 185],
                wrong: [images.done, 0, 240, 628, 180],
                gold1: [images.done, 0, 460, 150, 140],
                gold2: [images.done, 150, 460, 150, 140],
                gold3: [images.done, 300, 460, 150, 140],
                coin: [images.done, 160, 920, 38, 38],
                exp: [images.done, 320, 760, 38, 38],
                gem: [images.done, 0, 920, 28, 38],
                dark_1: [images.done, 0, 600, 100, 99],
                dark_2: [images.done, 160, 600, 120, 115],
                dark_3: [images.done, 320, 600, 100, 100],
                star_1: [images.done, 480, 600, 100, 99],
                star_2: [images.done, 0, 760, 120, 115],
                star_3: [images.done, 160, 760, 100, 100],
                light_right: [images.light_right, 0, 0, 510, 510],
                light_wrong: [images.light_wrong, 0, 0, 510, 510],
                task_right: [images.done, 320, 920, 20, 20],
                task_wrong: [images.done, 480, 920, 20, 20],
                ext_bg: [images.done, 455, 440, 170, 140],
                ext_text: [images.done, 480, 760, 59, 34],
                star_light: [images.star_light, 0, 0, 140 * 5, 140],
                star_erupt1: [images.done, 0, 1000, 150, 150],
                star_erupt2: [images.done, 150, 1000, 150, 150],
                star_erupt3: [images.done, 300, 1000, 150, 150],
                star_erupt4: [images.done, 450, 1000, 150, 150],
                dot_erupt: [images.done, 590, 950, 50, 50],
                star_flash: [images.star_flash, 0, 0, 42 * 10, 43],
                star1_pass: [images.done, 0, 420, 120, 40],
                star2_pass: [images.done, 120, 420, 120, 40],
                star3_pass: [images.done, 240, 420, 120, 40]
            });
            delete images;
            g.audio.prepare({
                coin: {urls: ['v2/sound/throwcoin.mp3'], preload: true},
                star_1: {urls: ['v2/sound/star_1.mp3'], preload: true},
                star_2: {urls: ['v2/sound/star_2.mp3'], preload: true},
                star_3: {urls: ['v2/sound/star_3.mp3'], preload: true},
                star_get: {urls: ['v2/sound/star_get.mp3'], preload: true},
                stage_success: {urls: ['v2/sound/stage_success.mp3'], preload: true},
                stage_fail: {urls: ['v2/sound/stage_fail.mp3'], preload: true}
            });
            game.isInit = true;
            game.fonts = {
                text: new g.Font({fontFamily: 'Microsoft Yahei', fontSize: 16, color: '#fff'}),
                bigtext: new g.Font({fontFamily: 'Microsoft Yahei', fontSize: 18, color: '#fff'}),
                smalltext: new g.Font({fontFamily: 'Microsoft Yahei', fontSize: 14, color: '#fff'}),
                bluetext: new g.Font({fontFamily: 'Microsoft Yahei', fontSize: 16, color: '#1abceb'}),
                greentext: new g.Font({fontFamily: 'Microsoft Yahei', fontSize: 16, color: '#5bce71'}),
                whiletext: new g.ShadowFont({
                    fontFamily: 'Microsoft Yahei',
                    fontSize: 22,
                    color: '#fff',
                    shadowWidth: 1,
                    shadowColor: '#b36300'
                })
            };
            typeof callback == 'function' ? callback() : '';
        });
    };
    game.play = function (wrapper, stars, coins, exps, gems, is_passed, accuracy, duration, answer, task) {
        if (game.isInit == false) {
            game.init(wrapper, function () {
                game.play(wrapper, stars, coins, exps, gems, is_passed, accuracy, duration, answer, task);
            });
            return;
        }
        game.gets = {
            stars: stars,
            coins: coins,
            exps: exps,
            gems: gems,
            isPassed: is_passed == 1,
            accuracy: accuracy,
            duration: duration,
            answer: answer,
            task: task
        };
        game.data = {stars: 0, coins: 0, exps: 0, gems: 0};
        g.view.resume();
        g.world.removeAllChild();
        var wHeight = window.innerHeight > document.body.scrollHeight ? window.innerHeight : document.body.scrollHeight;
        var sTop = wHeight <= 650 + $(window).scrollTop() ? wHeight - 650 : $(window).scrollTop();
        g.world.appendChild(new game.MainScreen({top: sTop}));
    };
    game.stop = function () {
        g.view.pause();
    };
    game.MainScreen = g.Container.extend({
        init: function (settings) {
            settings.width = g.world.width;
            settings.height = g.world.height;
            this._super(g.Container, 'init', [settings]);
            this.pushClip(this.start.bind(this), 10);
        }, start: function () {
            var coinTime = 50 * 1.2 + 1100;
            var wHeight = window.innerHeight > document.body.scrollHeight ? window.innerHeight : document.body.scrollHeight;
            var sTop = wHeight <= 650 + $(window).scrollTop() ? wHeight - 650 : $(window).scrollTop();
            this.appendChild(new g.Background({
                color: 'rgba(0, 0, 0, 0.7)',
                width: this.width,
                height: this.height,
                zIndex: -2,
                top: -sTop
            }));
            if (game.gets.isPassed) {
                this.pushClip(function () {
                    new game.DotErupt({
                        image: game.images.dot_erupt,
                        top: 150,
                        centerX: ~~(this.width / 2) - 10,
                        zIndex: -1,
                        opacity: 0.6
                    }).appendTo(this);
                    game.starParticle(this);
                }, game.gets.stars * 700 + 100);
                game.StarFlash(this, 100, ~~(g.world.width / 2) - 100, 2500);
                game.StarFlash(this, 200, ~~(g.world.width / 2) + 100, 3500);
                game.StarFlash(this, 300, ~~(g.world.width / 2) - 150, 6000);
                game.StarFlash(this, 230, ~~(g.world.width / 2) + 150, 4500);
                game.StarFlash(this, 150, ~~(g.world.width / 2) - 200, 5000);
                game.StarFlash(this, 180, ~~(g.world.width / 2) + 200, 3000);
                game.StarFlash(this, 50, ~~(g.world.width / 2) + 50, 6500);
                this.appendChild(new game.Light({
                    image: game.images.light_right,
                    top: -80,
                    centerX: ~~(g.world.width / 2) - 10,
                    zIndex: 0
                }));
                this.appendChild(new g.Sprite({
                    image: game.images.right,
                    top: 150,
                    centerX: ~~(g.world.width / 2) - 10
                }));
                g.audio.get('stage_success').play();
            } else {
                this.appendChild(new game.Light({
                    image: game.images.light_wrong,
                    top: -80,
                    centerX: ~~(g.world.width / 2) - 10,
                    zIndex: 0
                }));
                this.appendChild(new g.Sprite({
                    image: game.images.wrong,
                    top: 150,
                    centerX: ~~(g.world.width / 2) - 10
                }));
                g.audio.get('stage_fail').play();
            }
            this.appendChild(new game.StarContainer(), new game.Board({duration: coinTime}), new game.ExtContainer());
            if (game.gets.coins > 0) {
                this.pushClip(function () {
                    this.appendChild(new game.CoinErupt({height: this.height, width: this.width, type: 1}));
                }, game.gets.stars * 700 + 300);
                this.pushClip(function () {
                    this.appendChild(new game.CoinErupt({height: this.height, width: this.width, type: 2}));
                }, game.gets.stars * 700 + 200);
                this.pushClip(function () {
                    this.appendChild(new game.CoinErupt({height: this.height, width: this.width, type: 3}));
                }, game.gets.stars * 700 + 100);
            }
            this.pushClip(function () {
                game.data.coins += game.gets.coins;
                game.data.exps += game.gets.exps;
                game.data.gems += game.gets.gems;
                if (typeof my_card_add_counts == 'function') {
                    my_card_add_counts(game.gets.exps, game.gets.coins, game.gets.gems, game.gets.stars, 0, coinTime).start();
                }
            }, game.gets.stars * 700 + 200);
        }
    });
    game.StarContainer = g.Container.extend({
        init: function () {
            var settings = {width: 350, height: 130, top: 30, centerX: ~~(g.world.width / 2) - 10};
            this._super(g.Container, 'init', [settings]);
            this.appendChild(new g.Sprite({
                image: game.images.dark_1,
                top: 2,
                centerX: ~~(this.width / 2) - 120,
                centerY: ~~(this.height / 2) + 15
            }));
            this.appendChild(new g.Sprite({image: game.images.dark_2, top: 2, centerX: ~~(this.width / 2)}));
            this.appendChild(new g.Sprite({
                image: game.images.dark_3,
                top: 2,
                centerX: ~~(this.width / 2) + 120,
                centerY: ~~(this.height / 2) + 15
            }));
            this.start();
        }, start: function () {
            var stars = game.gets.stars;
            if (stars >= 1) {
                this.pushClip(function () {
                    this.appendChild(new game.Star({
                        image: game.images.star_1,
                        top: 2,
                        centerX: ~~(this.width / 2) - 120,
                        centerY: ~~(this.height / 2) + 15
                    }, 'star_1'));
                }, 0);
                this.pushClip(function () {
                    new game.StarLight({top: 10, left: -10, scaleX: 1.6, scaleY: 1.6, opacity: 0.5}).appendTo(this);
                    new game.StarErupt({top: -35, left: -55}).appendTo(this);
                }, 100);
            }
            if (stars >= 2) {
                this.pushClip(function () {
                    this.appendChild(new game.Star({
                        image: game.images.star_2,
                        top: 2,
                        centerX: ~~(this.width / 2)
                    }, 'star_2'));
                }, 700);
                this.pushClip(function () {
                    new game.StarLight({top: -5, left: 110, scaleX: 1.6, scaleY: 1.6, opacity: 0.5}).appendTo(this);
                    new game.StarErupt({top: -45, left: 65}).appendTo(this);
                }, 800);
            }
            if (stars >= 3) {
                this.pushClip(function () {
                    this.appendChild(new game.Star({
                        image: game.images.star_3,
                        top: 2,
                        centerX: ~~(this.width / 2) + 120,
                        centerY: ~~(this.height / 2) + 15
                    }, 'star_3'));
                }, 1400);
                this.pushClip(function () {
                    new game.StarLight({top: 10, left: 220, scaleX: 1.6, scaleY: 1.6, opacity: 0.5}).appendTo(this);
                    new game.StarErupt({top: -35, left: 185}).appendTo(this);
                }, 1500);
            }
        }
    });
    game.Star = g.Sprite.extend({
        init: function (settings, audio) {
            this._super(g.Sprite, 'init', [settings]);
            this.orignTop = this.top;
            this.pushClip(function (clock) {
                var p = g.easing(clock / 400, 0, 1, function (k) {
                    return k * k;
                });
                p = p > 1 ? 1 : p;
                this.isDirty = true;
                this.scaleX = ((0 - 1.8) * (1 - p) + 1.8);
                this.scaleY = ((0 - 1.8) * (1 - p) + 1.8);
            }, 0, 400);
            this.pushClip(function (clock) {
                var p = g.easing(clock / 800, 0, 1, g.easing.Bounce.Out);
                p = p > 1 ? 1 : p;
                this.isDirty = true;
                this.scaleX = ((1.8 - 1) * (1 - p) + 1);
                this.scaleY = ((1.8 - 1) * (1 - p) + 1);
            }, 400, 800);
            this.pushClip(function () {
                g.audio.get(audio).play();
            }, 400);
        }
    });
    game.StarLight = g.AnimateSheet.extend({
        init: function (settings) {
            settings.image = game.images.star_light;
            settings.width = 140;
            settings.height = 140;
            settings.frames = 5;
            settings.lineFrames = 5;
            settings.speed = 130;
            this._super(g.AnimateSheet, 'init', [settings]);
            this.addAnimate('main', [0, 1, 2, 3, 4]);
            this.setCurrentAnimate('main', 1);
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, 2000);
        }
    });
    game.StarFlash = function (thiz, mTop, mCenterX, mDt) {
        var isAdd = false;
        thiz.pushClip(function (clock) {
            if (!isAdd) {
                new game.StarFlashLoop({top: mTop, centerX: mCenterX, zIndex: 15}).appendTo(this);
                isAdd = true;
            }
            if (clock >= mDt) {
                game.StarFlash(this, mTop, mCenterX, mDt);
            }
        }, 0, mDt);
    };
    game.StarFlashLoop = g.AnimateSheet.extend({
        init: function (settings) {
            settings.image = game.images.star_flash;
            settings.width = 42;
            settings.height = 43;
            settings.frames = 10;
            settings.lineFrames = 10;
            settings.speed = 130;
            this._super(g.AnimateSheet, 'init', [settings]);
            this.addAnimate('main', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
            this.setCurrentAnimate('main', 1);
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, 2000);
        }
    });
    game.Light = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.duration = 30000;
            this.antiClock = settings.antiClock === undefined ? false : settings.antiClock;
            this.phase = settings.phase || 0;
            this.rotate = this.phase;
            this.clock = 0;
            this.isContentCacheable = true;
        }, update: function (dt) {
            if (this.duration != Infinity) {
                this.clock += dt;
                this.rotate = this.phase + (this.clock / this.duration) * Math.PI * 2 * (this.antiClock == true ? 1 : -1);
                this.isMoved = true;
            }
        }
    });
    game.CoinErupt = g.ParticleErupt.extend({
        init: function (st) {
            var img = game.images.gold1;
            if (st.type == 1) {
                img = game.images.gold1;
            } else if (st.type == 2) {
                img = game.images.gold2;
            } else if (st.type == 3) {
                img = game.images.gold3;
            }
            var settings = {
                image: img,
                sw: this.width,
                sh: this.height,
                x0: ~~(st.width / 2) + 50,
                y0: 180,
                scaleMax: 0.4,
                scaleMin: 0.2,
                numbers: 50,
                zIndex: 10,
                divergeAngle: Math.PI * 90 / 180,
                v0: 1.2,
                xRange: 50,
                accelerate: 0.002,
                width: st.width,
                height: st.height
            };
            this._super(g.ParticleErupt, 'init', [settings]);
            var playId = null;
            this.pushClip(function () {
                g.audio.get('coin').play(null, function (id) {
                    playId = id;
                });
            }, 0);
        }
    });
    game.StarErupt = g.Sprite.extend({
        init: function (settings) {
            settings.image = game.images.star_erupt1;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 142;
            this.y0 = 142;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            for (var i = 0; i < 20; i++) {
                var temp = {scale: Math.rand(0.1, 0.3), x: 0, y: 0, image: game.images.star_erupt1};
                temp.r = Math.rand(0, 150);
                temp.angle = Math.rand(0, 360);
                temp.x0 = temp.r * Math.cos(temp.angle);
                temp.y0 = temp.r * Math.sin(temp.angle);
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 700, 40, temp.x0, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 700, 40, temp.y0, g.easing.Quadratic.Out);
                if (this.clock > 300) {
                    temp.opacity = g.easing((this.clock - 300) / 500, 1, 0, g.easing.Quadratic.Out);
                }
                if (i % 4 == 0)
                    temp.image = game.images.star_erupt1
                else if (i % 4 == 1)
                    temp.image = game.images.star_erupt2
                else if (i % 4 == 2)
                    temp.image = game.images.star_erupt3
                else if (i % 4 == 3)
                    temp.image = game.images.star_erupt4
            }
            if (this.clock > 1250) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.objs[i].image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
    game.DotErupt = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 52;
            this.y0 = 49;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            for (var i = 0; i < 300; i++) {
                var temp = {scale: Math.rand(0.1, 0.5), x: 0, y: 0};
                temp.r = Math.rand(0, 700);
                temp.angle = Math.rand(0, 360);
                temp.x0 = temp.r * Math.cos(temp.angle);
                temp.y0 = temp.r * Math.sin(temp.angle);
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 3600, 0, temp.x0, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 3600, 0, temp.y0, g.easing.Quadratic.Out);
                if (this.clock > 1200) {
                    temp.opacity = g.easing((this.clock - 1200) / 2200, 1, 0, g.easing.Quadratic.Out);
                }
            }
            if (this.clock > 3650) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
    game.starParticle = function (thiz) {
        var isAdd = false;
        thiz.pushClip(function (clock) {
            if (!isAdd) {
                new game.StarEruptLoop({top: 100, centerX: ~~(this.width / 2) - 40, zIndex: -1}).appendTo(this);
                isAdd = true;
            }
            if (clock >= 3500) {
                game.starParticle(this);
            }
        }, 0, 3500);
    };
    game.StarEruptLoop = g.Sprite.extend({
        init: function (settings) {
            settings.image = game.images.star_erupt1;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 142;
            this.y0 = 142;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            for (var i = 0; i < 30; i++) {
                var temp = {scale: Math.rand(0.1, 0.5), x: 0, y: 0, image: game.images.star_erupt1};
                temp.r = Math.rand(0, 500);
                temp.angle = Math.rand(0, 360);
                temp.x0 = temp.r * Math.cos(temp.angle);
                temp.y0 = temp.r * Math.sin(temp.angle);
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 3000, 0, temp.x0, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 3000, 0, temp.y0, g.easing.Quadratic.Out);
                temp.opacity = g.easing(this.clock / 3000, 1, 0, g.easing.Quadratic.Out);
                if (i % 4 == 0)
                    temp.image = game.images.star_erupt1
                else if (i % 4 == 1)
                    temp.image = game.images.star_erupt2
                else if (i % 4 == 2)
                    temp.image = game.images.star_erupt3
                else if (i % 4 == 3)
                    temp.image = game.images.star_erupt4
            }
            if (this.clock > 3050) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.objs[i].image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
    game.Board = g.Container.extend({
        init: function (st) {
            this._super(g.Container, 'init', [{
                top: 280,
                height: 400,
                centerX: ~~(g.world.width / 2) - 10,
                width: 670
            }]);
            this.appendChild(new g.Container({
                width: this.width,
                height: 95,
                isContentCacheable: true
            }).appendChild(new g.TextRender({
                top: 20,
                centerX: ~~(this.width / 2) - 115,
                text: '正确率：',
                font: game.fonts.text
            }), new g.TextRender({
                top: 20,
                centerX: ~~(this.width / 2) - 45,
                text: game.gets.accuracy + '%',
                font: game.fonts.greentext
            }), new g.TextRender({
                top: 20,
                centerX: ~~(this.width / 2) + 5,
                text: '用时：',
                font: game.fonts.text
            }), new g.TextRender({
                top: 20,
                centerX: ~~(this.width / 2) + 65,
                text: game.gets.duration,
                font: game.fonts.bluetext
            }), new g.Sprite({
                centerX: ~~(this.width / 2) - 123 + 19,
                top: 45,
                image: game.images.coin
            }), new g.TextRender({
                top: 58,
                centerX: ~~(this.width / 2) - 78,
                text: '+',
                font: game.fonts.text
            }), new g.Sprite({
                centerX: ~~(this.width / 2) + 19,
                top: 45,
                image: game.images.exp
            }), new g.TextRender({
                top: 58,
                centerX: ~~(this.width / 2) + 43,
                text: '+',
                font: game.fonts.text
            }), new game.WhiteLine({top: 94, centerX: ~~(this.width / 2)})));
            this.appendChild(new g.TransitionScoreText({
                followObj: game.data,
                followIndex: 'coins',
                duration: st.duration,
                font: game.fonts.text,
                centerX: ~~(this.width / 2) - 64,
                top: 58
            }).setProperty('isContentCacheable', false), new g.TransitionScoreText({
                followObj: game.data,
                followIndex: 'exps',
                duration: st.duration,
                font: game.fonts.text,
                centerX: ~~(this.width / 2) + 55,
                top: 58
            }).setProperty('isContentCacheable', false));
            this.appendChild(new g.Container({
                top: 95,
                width: this.width,
                height: 80,
                isContentCacheable: true
            }).appendChild(new g.TextRender({
                top: 10,
                centerX: ~~(this.width / 2) - 35,
                text: '闯关成绩',
                font: game.fonts.bigtext
            }), new game.AnswerContainer({
                top: 40,
                width: this.width,
                height: 26,
                centerX: ~~(this.width / 2)
            }), new game.WhiteLine({top: 79, centerX: ~~(this.width / 2)})));
            if (game.gets.task.length > 0) {
                this.appendChild(new g.Container({
                    top: 175,
                    width: this.width,
                    height: 130,
                    isContentCacheable: true
                }).appendChild(new g.TextRender({
                    top: 10,
                    centerX: ~~(this.width / 2) - 35,
                    text: '额外任务',
                    font: game.fonts.bigtext
                }), new game.TaskContainer({
                    top: 40,
                    width: this.width,
                    centerX: ~~(this.width / 2)
                }), new game.WhiteLine({top: 129, centerX: ~~(this.width / 2)})));
            }
        }
    });
    game.WhiteLine = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [{
                width: 670,
                height: 1,
                centerX: settings.centerX || (~~(g.world.width / 2) + 10 - 335),
                top: settings.top || 0
            }]);
            this.gradient = g.view.context.createLinearGradient(0, 00, 670, 0);
            for (var i = 0; i <= 10; i++) {
                var p = i / 10;
                this.gradient.addColorStop(0.1 * p, 'rgba(255, 255, 255, ' + (g.easing(p, 0, 0.5, g.easing.Quadratic.In)).toFixed(2) + ')');
            }
            this.gradient.addColorStop(0.9, 'rgba(255, 255, 255, 0.5)');
            for (var i = 0; i <= 10; i++) {
                var p = i / 10;
                this.gradient.addColorStop(0.9 + 0.1 * p, 'rgba(255, 255, 255, ' + (g.easing(p, 0.5, 0, g.easing.Quadratic.In)).toFixed(2) + ')');
            }
        }, draw: function (ctx) {
            ctx.fillStyle = this.gradient;
            ctx.fillRect(0, 0, this.width, this.height);
        }
    });
    game.AnswerContainer = g.Container.extend({
        init: function (settings) {
            var item_width = 26, interval = 6;
            settings.width = item_width * game.gets.answer.length + interval * (game.gets.answer.length - 1);
            this._super(g.Container, 'init', [settings]);
            for (var j = 1; j <= game.gets.answer.length; j++) {
                this.appendChild(new game.Answer({
                    text: j,
                    bgcolor: (game.gets.answer[j - 1] == true) ? '#4fd769' : '#f98180',
                    color: '#fff',
                    left: (item_width + interval) * (j - 1),
                    width: item_width,
                    height: item_width
                }));
            }
        }
    });
    game.Answer = g.Renderable.extend({
        init: function (settings) {
            this.fillColor = settings.bgcolor || '#000';
            this.textColor = settings.color || '#fff';
            this.text = settings.text || '';
            this.width = settings.width;
            this._super(g.Renderable, 'init', [settings]);
        }, draw: function (ctx) {
            ctx.fillStyle = this.fillColor;
            ctx.beginPath();
            ctx.arc(~~(this.width / 2), ~~(this.width / 2), ~~(this.width / 2), 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = this.textColor;
            ctx.font = '14px Microsoft Yahei';
            ctx.textAlign = 'center';
            ctx.fillText(this.text, 13, 18);
        }
    });
    game.TaskContainer = g.Container.extend({
        init: function (settings) {
            var item_width = 140, interval = 20;
            settings.width = item_width * game.gets.task.length + interval * (game.gets.task.length - 1);
            this._super(g.Container, 'init', [settings]);
            for (var j = 0; j < game.gets.task.length; j++) {
                this.appendChild(new game.RoundRect({
                    left: (item_width + interval) * j,
                    width: item_width,
                    height: item_width
                }), new g.TextRender({
                    top: 13,
                    left: (item_width + interval) * j + 18,
                    text: game.gets.task[j]['name'],
                    font: game.fonts.smalltext
                }), new g.TextRender({
                    top: 45,
                    left: (item_width + interval) * j + 55,
                    text: '+' + game.gets.task[j]['award'],
                    font: game.fonts.smalltext
                }));
                if (game.gets.task[j].award_type == 'coins') {
                    this.appendChild(new g.Sprite({
                        image: game.images.coin,
                        top: 33,
                        left: (item_width + interval) * j + 15
                    }));
                } else if (game.gets.task[j].award_type == 'gems') {
                    this.appendChild(new g.Sprite({
                        image: game.images.gem,
                        top: 35,
                        left: (item_width + interval) * j + 15
                    }));
                } else {
                    this.appendChild(new g.Sprite({
                        image: game.images.exp,
                        top: 33,
                        left: (item_width + interval) * j + 15
                    }));
                }
                this.appendChild(new game.TaskStatus({
                    image: game.gets.task[j]['got'] == true ? game.images.task_right : game.images.task_wrong,
                    top: -7,
                    left: (item_width + interval) * j - 7,
                    begin_time: 300 * j
                }));
            }
        }
    });
    game.RoundRect = g.Renderable.extend({
        init: function (settings) {
            this._super(g.Renderable, 'init', [settings]);
            this.x = 0;
            this.y = 0;
            this.width = 140;
            this.height = 80;
            this.radius = 7;
            this.color = 'rgba(255,255,255,0.5)';
        }, draw: function (ctx) {
            ctx.beginPath();
            ctx.lineWidth = 1;
            ctx.strokeStyle = this.color;
            ctx.moveTo(this.x, this.y + this.radius);
            ctx.lineTo(this.x, this.y + this.height - this.radius);
            ctx.quadraticCurveTo(this.x, this.y + this.height, this.x + this.radius, this.y + this.height);
            ctx.lineTo(this.x + this.width - this.radius, this.y + this.height);
            ctx.quadraticCurveTo(this.x + this.width, this.y + this.height, this.x + this.width, this.y + this.height - this.radius);
            ctx.lineTo(this.x + this.width, this.y + this.radius);
            ctx.quadraticCurveTo(this.x + this.width, this.y, this.x + this.width - this.radius, this.y);
            ctx.lineTo(this.x + this.radius, this.y);
            ctx.quadraticCurveTo(this.x, this.y, this.x, this.y + this.radius);
            ctx.stroke();
        }
    });
    game.TaskStatus = g.Sprite.extend({
        init: function (settings) {
            settings.scaleX = 0;
            settings.scaleY = 0;
            this._super(g.Sprite, 'init', [settings]);
            this.pushClip(function (clock) {
                var p = g.easing(clock / 400, 0, 1, function (k) {
                    return k * k;
                });
                p = p > 1 ? 1 : p;
                this.isDirty = true;
                this.scaleX = ((0 - 1.4) * (1 - p) + 1.4);
                this.scaleY = ((0 - 1.4) * (1 - p) + 1.4);
            }, settings.begin_time, 400 + settings.begin_time);
            this.pushClip(function (clock) {
                var p = g.easing(clock / 600, 0, 1, g.easing.Bounce.Out);
                p = p > 1 ? 1 : p;
                this.isDirty = true;
                this.scaleX = ((1.4 - 1) * (1 - p) + 1);
                this.scaleY = ((1.4 - 1) * (1 - p) + 1);
            }, 400 + settings.begin_time, 600 + 400 + settings.begin_time);
        }
    });
    game.ExtContainer = g.Container.extend({
        init: function () {
            this._super(g.Container, 'init', [{top: 100, centerX: ~~(g.world.width / 2) - 330, scaleX: 0, scaleY: 0}]);
            var stars = game.gets.stars;
            if (game.gets.isPassed && game.gets.gems != 0) {
                this.appendChild(new g.Sprite({
                    image: game.images.ext_bg,
                    top: -50,
                    centerX: ~~(this.width / 2) - 15
                }), new g.Sprite({
                    image: (game.gets.stars == 1 ? game.images.star1_pass : (game.gets.stars == 2 ? game.images.star2_pass : game.images.star3_pass)),
                    top: -28,
                    centerX: ~~(this.width / 2) - 40,
                    rotate: -Math.PI * 22 / 180
                }), new g.Sprite({
                    image: game.images.ext_text,
                    top: 0,
                    centerX: ~~(this.width / 2) - 25
                }), new g.Sprite({
                    image: game.images.gem,
                    top: 35,
                    centerX: ~~(this.width / 2) - 40
                }), new g.TextRender({
                    top: 33,
                    centerX: ~~(this.width / 2) - 20,
                    text: '+ ',
                    font: game.fonts.whiletext,
                    rotate: -Math.PI * 22 / 180
                })).pushClip(function (clock) {
                    var p = g.easing(clock / 200, 0, 1, function (k) {
                        return k * k;
                    });
                    this.scaleX = ((0 - 1.3) * (1 - p) + 1.3);
                    this.scaleY = ((0 - 1.3) * (1 - p) + 1.3);
                }, stars * 700, 200).pushClip(function (clock) {
                    var p = g.easing(clock / 600, 0, 1, g.easing.Elastic.Out);
                    this.scaleX = ((1.3 - 1) * (1 - p) + 1);
                    this.scaleY = ((1.3 - 1) * (1 - p) + 1);
                }, stars * 700 + 200, 600);
                this.appendChild(new g.TransitionScoreText({
                    followObj: game.data,
                    followIndex: 'gems',
                    duration: 50 * 1.2 + 700,
                    font: game.fonts.whiletext,
                    centerX: ~~(this.width / 2) - 0,
                    top: 25,
                    rotate: -Math.PI * 22 / 180
                }).setProperty('isContentCacheable', false));
            }
        }
    });
})();
;
/* TlxhJ.js */
(function () {
    window.answer = {};
    window.playAnswerAudio = function (completed, correct, star_get) {
        if (!g.Renderable)
            return;
        answer.playAnswerAudio(completed, correct, star_get);
    };
    if (!g.Renderable)
        return;
    $(window).bind('load', function () {
        g.loadImage({star_get: 'http://www.91xiaoyu.com/images/done.png'});
        g.audio.prepare({
            star_get: {urls: ['v2/sound/star_get.mp3'], preload: true},
            answer_correct: {urls: ['v2/sound/answer_correct.mp3'], preload: true},
            answer_wrong: {urls: ['v2/sound/answer_wrong.mp3'], preload: true}
        });
    });
    answer.isInit = false;
    answer.init = function (callback) {
        g.loadImage({star_get: 'http://www.91xiaoyu.com/images/done.png'}, function (images) {
            answer.images = g.divideImage({});
            delete images;
            g.audio.prepare({
                star_get: {urls: ['v2/sound/star_get.mp3'], preload: true},
                answer_correct: {urls: ['v2/sound/answer_correct.mp3'], preload: true},
                answer_wrong: {urls: ['v2/sound/answer_wrong.mp3'], preload: true}
            });
            answer.isInit = true;
            answer.fonts = {text: new g.Font({fontFamily: 'Microsoft Yahei', fontSize: 16, color: '#fff'})};
            typeof callback == 'function' ? callback() : '';
        });
    };
    answer.playAnswerAudio = function (completed, correct, star_get) {
        if (answer.isInit == false) {
            answer.init(function () {
                answer.playAnswerAudio(completed, correct, star_get);
            });
            return;
        }
        if (completed == true) {
        }
        if (star_get == true) {
            g.audio.get('star_get').play();
        } else {
            if (correct == true) {
                g.audio.get('answer_correct').play();
            } else {
                g.audio.get('answer_wrong').play();
            }
        }
    };
    answer.stop = function () {
        g.view.pause();
    };
})();
;
/* 53pbs.js */
(function () {
    window.playTask = function (delay, formerTasks, tasks) {
        if (formerTasks == tasks)
            return;
        if (!g.Renderable)
            return;
        game.play(delay, formerTasks, tasks);
    };
    if (!g.Renderable)
        return;
    var imageToLoad = {achievement: 'http://www.91xiaoyu.com/images/achievement.png'};
    $(window).bind('load', function () {
        g.loadImage(imageToLoad);
    });
    var game = {
        view: null,
        world: null,
        data: {awardText: '', formerTasks: 0, tasks: 0, lastTime: 4000, delay: 0},
        play: function (delay, formerTasks, tasks) {
            game.data.formerTasks = formerTasks;
            game.data.tasks = tasks;
            game.data.awardText = "看完知识点视频";
            game.data.delay = delay;
            if (tasks) {
                if (formerTasks < 4 && tasks >= 7) {
                    game.data.lastTime = 5000;
                } else if (formerTasks >= 4 && tasks >= 7) {
                    game.data.awardText = "恭喜获得战神无双成就";
                }
            }
            if (game.view == null) {
                $('body').append('<div id="task_animate" style="pointer-events:none;position:absolute;top:0px;left:50%;margin-left:-4px;width:750px;height:500px;z-index:10000;"></div>');
                game.init(document.getElementById('task_animate'), function () {
                    game.play(delay, formerTasks, tasks);
                });
                return;
            }
            document.getElementById('task_animate').style.display = 'block';
            game.view.resume();
            game.world.removeAllChild();
            game.world.appendChild(new game.MainScreenBox({}));
        },
        stop: function () {
            document.getElementById('task_animate').style.display = 'none';
            game.view.pause();
        },
        init: function (wrapper, callback) {
            var canvas = document.createElement('canvas');
            canvas.setAttribute('id', 'task_canvas');
            wrapper.appendChild(canvas);
            game.view = g.addView('task_canvas', 750, 500);
            game.world = game.view.world;
            game.view.clearBeforeDraw = true;
            g.loadImage(imageToLoad, function (images) {
                game.images = g.divideImage({
                    round: [images.achievement, 0, 0, 194, 155],
                    task: [images.achievement, 0, 150, 194, 140],
                    brand: [images.achievement, 22, 295, 134, 45],
                    star: [images.achievement, 15, 345, 40, 40],
                    light1: [images.achievement, 20, 385, 14, 117],
                    light2: [images.achievement, 34, 385, 9, 75],
                    gem1: [images.achievement, 99, 414, 20, 20],
                    gem2: [images.achievement, 123.5, 421, 20, 20],
                    gem3: [images.achievement, 146.8, 414, 20, 20]
                });
                delete images;
                game.fonts = {
                    achFont: new g.Font({
                        fontFamily: 'microsoft yahei',
                        fontWeight: 'bold',
                        fontSize: 12,
                        color: '#fff'
                    })
                };
                typeof callback == 'function' ? callback() : '';
            });
        }
    };
    game.MainScreenBox = g.Container.extend({
        init: function () {
            var settings = {width: game.world.width, height: game.world.height};
            this._super(g.Container, 'init', [settings]);
            this.pushClip(function (t) {
                this.appendChild(new game.MainScreen({}));
            }, game.data.delay);
        }
    });
    game.MainScreen = g.Container.extend({
        init: function () {
            var settings = {width: game.world.width, height: game.world.height / 2};
            this._super(g.Container, 'init', [settings]);
            this.appendChild(new g.LightRotate({
                centerX: 375,
                centerY: 115,
                image: game.images.light1,
                lightNumber: 12,
                duration: 30000,
                antiClock: false,
                scaleX: 1,
                scaleY: 1
            }), new g.LightRotate({
                centerX: 375,
                centerY: 115,
                image: game.images.light2,
                lightNumber: 12,
                duration: 30000,
                antiClock: true,
                scaleX: 1.3,
                scaleY: 1.3
            }), new g.Sprite({image: game.images.task, centerX: 375, top: 40}));
            if (game.data.tasks) {
                if (game.data.formerTasks < 4 && game.data.tasks >= 4) {
                    this.appendChild(new game.newPot({image: game.images.gem1, centerX: 375 - 24, centerY: 110 + 18}));
                } else if (game.data.formerTasks >= 4) {
                    this.appendChild(new g.Sprite({image: game.images.gem1, centerX: 375 - 24, centerY: 110 + 18}));
                }
                if ((game.data.formerTasks % 4) < 2 && (game.data.tasks % 4) >= 2) {
                    this.appendChild(new game.newPot({image: game.images.gem2, centerX: 375 + 1, centerY: 110 + 25}));
                } else if ((game.data.formerTasks % 4) >= 2) {
                    this.appendChild(new g.Sprite({image: game.images.gem2, centerX: 375 + 1, centerY: 110 + 25}));
                }
                if ((game.data.formerTasks % 2) < 1 && (game.data.tasks % 2) >= 1) {
                    this.appendChild(new game.newPot({image: game.images.gem3, centerX: 375 + 25, centerY: 110 + 18}));
                } else if ((game.data.formerTasks % 2) >= 1) {
                    this.appendChild(new g.Sprite({image: game.images.gem3, centerX: 375 + 25, centerY: 110 + 18}));
                }
            }
            this.appendChild(new g.Sprite({image: game.images.brand, centerX: 375, top: 152}));
            var awardWord = new g.TextRender({
                font: game.fonts.achFont,
                text: game.data.awardText,
                centerX: 375,
                top: 175,
                textAlign: 'center',
                zIndex: 10
            });
            this.appendChild(awardWord);
            this.scale(0);
            this.pushClip(function (t) {
                this.appendChild(new game.Star({}));
                this.isDirty = true;
            }, 300);
            this.pushClip(function (t) {
                this.scale(g.easing(t / 300, 0, 1, g.easing.Quadratic.Out));
                this.opacity = g.easing(t / 300, 0, 1, g.easing.Quadratic.Out);
                this.isDirty = true;
            }, 0, 300);
            if (game.data.tasks) {
                if (game.data.formerTasks < 4 && game.data.tasks >= 7) {
                    this.pushClip(function (clock) {
                        var p = g.easing(clock / 150, 0, 1, function (k) {
                            return k;
                        });
                        this.isDirty = true;
                        var t = -(0.5 * p - 1) * (0.5 * p - 1) + 2;
                        this.scaleX = t;
                        this.scaleY = t;
                        awardWord.text = "恭喜获得战神无双成就";
                    }, 2000, 150);
                    this.pushClip(function (clock) {
                        var p = g.easing(clock / 400, 0, 1, g.easing.Elastic.Out);
                        this.isDirty = true;
                        this.scaleX = ((1.6 - 1) * (1 - p) + 1);
                        this.scaleY = ((1.6 - 1) * (1 - p) + 1);
                    }, 2150, 400);
                }
            }
            this.pushClip(function (t) {
                this.scale(g.easing(t / 200, 1, 0, g.easing.Quadratic.Out));
                this.isDirty = true;
            }, game.data.lastTime, 200);
            this.pushClip(function (t) {
                game.stop();
            }, 6000);
        }
    });
    game.newPot = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.scale(0);
            this.pushClip(function (clock) {
                var p = g.easing(clock / 200, 0, 1, function (k) {
                    return k * k;
                });
                p = p > 1 ? 1 : p;
                this.isDirty = true;
                this.scaleX = ((0 - 1.6) * (1 - p) + 1.6);
                this.scaleY = ((0 - 1.6) * (1 - p) + 1.6);
            }, 500, 200);
            this.pushClip(function (clock) {
                var p = g.easing(clock / 400, 0, 1, g.easing.Bounce.Out);
                this.isDirty = true;
                this.scaleX = ((1.6 - 1) * (1 - p) + 1);
                this.scaleY = ((1.6 - 1) * (1 - p) + 1);
            }, 700, 400);
        }
    });
    game.Star = g.Sprite.extend({
        init: function (settings) {
            settings.image = game.images.star;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 375;
            this.y0 = 115;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            this.zIndex = -1;
            for (var i = 0; i < 20; i++) {
                var angle = (2 * Math.PI / 360) * Math.rand(0, 360);
                var speed = Math.rand(50, 80);
                var temp = {
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed,
                    scale: Math.rand(0.6, 1),
                    x: 0,
                    y: 0
                };
                temp.x0 = temp.vx;
                temp.y0 = temp.vy;
                temp.x1 = temp.x0 + temp.vx;
                temp.y1 = temp.y0 + temp.vy;
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 800, temp.x0, temp.x1, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 800, temp.y0, temp.y1, g.easing.Quadratic.Out);
                if (this.clock > 200) {
                    temp.opacity = g.easing((this.clock - 200) / 600, 1, 0, g.easing.Quadratic.Out);
                }
            }
            if (this.clock > 1000) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
})();
;
/* KqX0O.js */
(function () {
    window.playRound = function (delay, misplace) {
        if (!g.Renderable)
            return;
        game.play(delay, misplace);
    };
    if (!g.Renderable)
        return;
    var imageToLoad = {achievement: 'http://www.91xiaoyu.com/images/achievement.png'};
    $(window).bind('load', function () {
        g.loadImage(imageToLoad);
    });
    var game = {
        view: null, world: null, data: {awardText: '', delay: 0}, play: function (delay, misplace) {
            game.data.awardText = "恭喜获得忍者无敌成就";
            if (game.view == null) {
                var top = misplace ? 200 : 0;
                $('body').append('<div id="round_animate" style="pointer-events:none;position:absolute;top:' + top + 'px;left:50%;margin-left:-4px;width:750px;height:500px;z-index:10000;"></div>');
                game.init(document.getElementById('round_animate'), function () {
                    game.play(delay);
                });
                return;
            }
            game.data.delay = delay;
            document.getElementById('round_animate').style.display = 'block';
            game.view.resume();
            game.world.removeAllChild();
            game.world.appendChild(new game.MainScreenBox({}));
        }, stop: function () {
            document.getElementById('round_animate').style.display = 'none';
            game.view.pause();
        }, init: function (wrapper, callback) {
            var canvas = document.createElement('canvas');
            canvas.setAttribute('id', 'round_canvas');
            wrapper.appendChild(canvas);
            game.view = g.addView('round_canvas', 750, 500);
            game.world = game.view.world;
            game.view.clearBeforeDraw = true;
            g.loadImage(imageToLoad, function (images) {
                game.images = g.divideImage({
                    round: [images.achievement, 0, 0, 194, 155],
                    task: [images.achievement, 0, 150, 194, 140],
                    brand: [images.achievement, 22, 295, 134, 45],
                    star: [images.achievement, 15, 345, 40, 40],
                    light1: [images.achievement, 20, 385, 14, 117],
                    light2: [images.achievement, 34, 385, 9, 75],
                    gem1: [images.achievement, 98, 353, 20, 20],
                    gem2: [images.achievement, 122, 358, 20, 20],
                    gem3: [images.achievement, 146, 353, 20, 20]
                });
                delete images;
                game.fonts = {
                    achFont: new g.Font({
                        fontFamily: 'microsoft yahei',
                        fontWeight: 'bold',
                        fontSize: 12,
                        color: '#fff'
                    })
                };
                typeof callback == 'function' ? callback() : '';
            });
        }
    };
    game.MainScreenBox = g.Container.extend({
        init: function () {
            var settings = {width: game.world.width, height: game.world.height};
            this._super(g.Container, 'init', [settings]);
            this.pushClip(function (t) {
                this.appendChild(new game.MainScreen({}));
            }, game.data.delay);
        }
    });
    game.MainScreen = g.Container.extend({
        init: function () {
            var settings = {width: game.world.width, height: game.world.height / 2};
            this._super(g.Container, 'init', [settings]);
            this.appendChild(new g.LightRotate({
                centerX: 375,
                centerY: 115,
                image: game.images.light1,
                lightNumber: 12,
                duration: 30000,
                antiClock: false,
                scaleX: 1,
                scaleY: 1
            }), new g.LightRotate({
                centerX: 375,
                centerY: 115,
                image: game.images.light2,
                lightNumber: 12,
                duration: 30000,
                antiClock: true,
                scaleX: 1.3,
                scaleY: 1.3
            }), new g.Sprite({image: game.images.round, centerX: 375, top: 40}), new g.Sprite({
                image: game.images.brand,
                centerX: 375,
                top: 152
            }), new g.TextRender({
                font: game.fonts.achFont,
                text: game.data.awardText,
                centerX: 375,
                top: 175,
                textAlign: 'center',
                zIndex: 10
            }));
            this.pushClip(function (t) {
                this.appendChild(new game.newPot({image: game.images.gem1, centerX: 375 - 24, centerY: 110 + 18}));
            }, 300);
            this.pushClip(function (t) {
                this.appendChild(new game.newPot({image: game.images.gem2, centerX: 375 + 1, centerY: 110 + 23}));
            }, 600);
            this.pushClip(function (t) {
                this.appendChild(new game.newPot({image: game.images.gem3, centerX: 375 + 25, centerY: 110 + 18}));
            }, 900);
            this.scale(0);
            this.pushClip(function (t) {
                this.appendChild(new game.Star({}));
                this.isDirty = true;
            }, 300);
            this.pushClip(function (t) {
                this.scale(g.easing(t / 300, 0, 1, g.easing.Quadratic.Out));
                this.opacity = g.easing(t / 300, 0, 1, g.easing.Quadratic.Out);
                this.isDirty = true;
            }, 0, 300);
            this.pushClip(function (t) {
                this.scale(g.easing(t / 200, 1, 0, g.easing.Quadratic.Out));
                this.isDirty = true;
            }, 4000, 200);
            this.pushClip(function (t) {
                game.stop();
            }, 6000);
        }
    });
    game.newPot = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.scale(0);
            this.pushClip(function (clock) {
                var p = g.easing(clock / 200, 0, 1, function (k) {
                    return k * k;
                });
                p = p > 1 ? 1 : p;
                this.isDirty = true;
                this.scaleX = ((0 - 1.6) * (1 - p) + 1.6);
                this.scaleY = ((0 - 1.6) * (1 - p) + 1.6);
            }, 0, 200);
            this.pushClip(function (clock) {
                var p = g.easing(clock / 400, 0, 1, g.easing.Bounce.Out);
                p = p > 1 ? 1 : p;
                this.isDirty = true;
                this.scaleX = ((1.6 - 1) * (1 - p) + 1);
                this.scaleY = ((1.6 - 1) * (1 - p) + 1);
            }, 200, 400);
        }
    });
    game.Star = g.Sprite.extend({
        init: function (settings) {
            settings.image = game.images.star;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 375;
            this.y0 = 115;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            this.zIndex = -1;
            for (var i = 0; i < 20; i++) {
                var angle = (2 * Math.PI / 360) * Math.rand(0, 360);
                var speed = Math.rand(50, 80);
                var temp = {
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed,
                    scale: Math.rand(0.6, 1),
                    x: 0,
                    y: 0
                };
                temp.x0 = temp.vx;
                temp.y0 = temp.vy;
                temp.x1 = temp.x0 + temp.vx;
                temp.y1 = temp.y0 + temp.vy;
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 800, temp.x0, temp.x1, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 800, temp.y0, temp.y1, g.easing.Quadratic.Out);
                if (this.clock > 200) {
                    temp.opacity = g.easing((this.clock - 200) / 600, 1, 0, g.easing.Quadratic.Out);
                }
            }
            if (this.clock > 1000) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
})();
;
/* 1atWpH.js */
(function () {
    window.stageTasks = function (indexs) {
        if (!g.Renderable)
            return;
        game.play(indexs);
    };
    if (!g.Renderable)
        return;
    var imageToLoad = {tasks: 'http://www.91xiaoyu.com/images/tasks.png', starLight: 'http://www.91xiaoyu.com/images/star_light.png'};
    $(window).bind('load', function () {
        g.loadImage(imageToLoad);
    });
    var game = {
        view: null, world: null, data: {indexs: []}, play: function (indexs) {
            if (game.view == null) {
                $('#knowledge_tasks').append('<div id="tasks_animate" style="pointer-events:none;position:absolute;top:-30px;left:-20px;width:100px;height:200px;z-index:1000;"></div>');
                game.init(document.getElementById('tasks_animate'), function () {
                    game.play(indexs);
                });
                return;
            }
            game.data.indexs = indexs;
            document.getElementById('tasks_animate').style.display = 'block';
            game.view.resume();
            game.world.removeAllChild();
            game.world.appendChild(new game.MainScreen({}));
        }, stop: function () {
            document.getElementById('tasks_animate').style.display = 'none';
            game.view.pause();
        }, init: function (wrapper, callback) {
            var canvas = document.createElement('canvas');
            canvas.setAttribute('id', 'tasks_canvas');
            wrapper.appendChild(canvas);
            game.view = g.addView('tasks_canvas', 100, 200);
            game.world = game.view.world;
            game.view.clearBeforeDraw = true;
            g.loadImage(imageToLoad, function (images) {
                game.images = g.divideImage({
                    starLight: [images.starLight, 0, 0, 140 * 5, 140],
                    star: [images.tasks, 13, 0, 40, 40]
                });
                delete images;
                typeof callback == 'function' ? callback() : '';
            });
        }
    };
    game.MainScreen = g.Container.extend({
        init: function () {
            var settings = {width: game.world.width, height: game.world.height,};
            this._super(g.Container, 'init', [settings]);
            this.pushClip(function () {
                for (var i = 0; i < game.data.indexs.length; i++) {
                    new game.StarLight({
                        centerX: game.world.width / 2 - 9,
                        centerY: 50 + (game.data.indexs[i] - 1) * 30,
                        scaleX: 0.4,
                        scaleY: 0.4,
                        opacity: 1
                    }).appendTo(this);
                    new game.StarErupt({
                        centerX: game.world.width / 2 - 12,
                        centerY: 42 + (game.data.indexs[i] - 1) * 15
                    }).appendTo(this);
                }
            }, 100);
            this.pushClip(function () {
                for (var i = 0; i < game.data.indexs.length; i++) {
                    $("#knowledge_task" + game.data.indexs[i] + "").show().addClass("animate_spring");
                }
            }, 200);
            this.pushClip(function () {
                game.stop();
            }, 2000);
        }
    });
    game.StarLight = g.AnimateSheet.extend({
        init: function (settings) {
            settings.image = game.images.starLight;
            settings.width = 140;
            settings.height = 140;
            settings.frames = 5;
            settings.lineFrames = 5;
            settings.speed = 130;
            this._super(g.AnimateSheet, 'init', [settings]);
            this.addAnimate('main', [0, 1, 2, 3, 4]);
            this.setCurrentAnimate('main', 1);
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, 2000);
        }
    });
    game.StarErupt = g.Sprite.extend({
        init: function (settings) {
            settings.image = game.images.star;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = settings.centerX;
            this.y0 = settings.centerY;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            this.zIndex = -1;
            for (var i = 0; i < 20; i++) {
                var angle = (2 * Math.PI / 360) * Math.rand(0, 360);
                var speed = Math.rand(10, 20);
                var temp = {
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed,
                    scale: Math.rand(0.1, 0.4),
                    x: 0,
                    y: 0
                };
                temp.x0 = temp.vx;
                temp.y0 = temp.vy;
                temp.x1 = temp.x0 + temp.vx;
                temp.y1 = temp.y0 + temp.vy;
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 700, temp.x0, temp.x1, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 700, temp.y0, temp.y1, g.easing.Quadratic.Out);
                if (this.clock > 300) {
                    temp.opacity = g.easing((this.clock - 300) / 500, 1, 0, g.easing.Quadratic.Out);
                }
                temp.image = game.images.star;
            }
            if (this.clock > 1250) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.objs[i].image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
})();
;
/* 119zkx.js */
(function () {
    var star = {};
    window.playStarErupt = function (p) {
        if (!g.Renderable)
            return;
        star.play(p);
    };
    if (!g.Renderable)
        return;
    $(window).bind('load', function () {
        g.loadImage({done: 'http://www.91xiaoyu.com/images/done.png'});
    });
    star.isInit = false;
    star.init = function (p, callback) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', 'star_erupt_canvas');
        canvas.setAttribute('style', 'position: absolute;top: -50px;left: -40px;');
        $(".kq_q_list").get(0).appendChild(canvas);
        star.view = g.initView('star_erupt_canvas', 400, 140, false);
        star.world = star.view.world;
        star.view.clearBeforeDraw = true;
        g.loadImage({done: 'http://www.91xiaoyu.com/images/done.png'}, function (images) {
            star.images = g.divideImage({star_erupt: [images.done, 595, 960, 38, 38]});
            star.isInit = true;
            delete images;
            typeof callback == 'function' ? callback() : '';
        });
    };
    star.play = function (p) {
        if (star.isInit == false) {
            star.init(p, function () {
                star.play(p);
            });
            return;
        }
        star.view.resume();
        star.world.removeAllChild();
        star.world.appendChild(new star.Container({top: 0, left: 0, p: p}));
    };
    star.Container = g.Container.extend({
        init: function (settings) {
            this._super(g.Container, 'init', [settings]);
            var top = -60;
            var left = settings.p - 70;
            this.appendChild(new star.StarErupt({top: top, left: left}));
        }
    });
    star.StarErupt = g.Sprite.extend({
        init: function (settings) {
            settings.image = star.images.star_erupt;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 100;
            this.y0 = 100;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            for (var i = 0; i < 40; i++) {
                var temp = {scale: Math.rand(0.1, 1), x: 0, y: 0, image: star.images.star_erupt};
                temp.r = Math.rand(0, 150);
                temp.angle = Math.rand(0, 360);
                temp.x0 = temp.r * Math.cos(temp.angle);
                temp.y0 = temp.r * Math.sin(temp.angle);
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 700, 40, temp.x0, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 700, 40, temp.y0, g.easing.Quadratic.Out);
                if (this.clock > 300) {
                    temp.opacity = g.easing((this.clock - 300) / 500, 1, 0, g.easing.Quadratic.Out);
                }
                temp.image = star.images.star_erupt;
            }
            if (this.clock > 1250) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.objs[i].image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
})();
;
/* zEOAB.js */
$(document).ready(function () {
    var $frame = $('#kq_frame');
    var stage_id = $frame.data('stage_id');
    var category_id = $frame.data('category_id');
    var current_no = $('#current').html() - 1;
    var $q;
    var $current;
    switchTo(current_no);
    $(".cm_magic_get_a").click(function () {
        var num = parseInt($(".cm_magic_get_n").html());
        var coins = parseInt($(".cm_coin_total_n").data("coins")) - ((num + 1) * 2500);
        if (num >= 10 || num <= 0 || coins <= 0)
            return;
        $(".cm_magic_get_n").html(num + 1);
        $(".cm_coin_total_n").html(coins);
    });
    $(".cm_magic_get_s").click(function () {
        var num = parseInt($(".cm_magic_get_n").html());
        if (num <= 1)
            return;
        $(".cm_magic_get_n").html(num - 1);
        $(".cm_coin_total_n").html(parseInt($(".cm_coin_total_n").data("coins")) - ((num - 1) * 2500));
    });
    $(".coin_magic_btn").click(function () {
        if (parseInt($(".cm_magic_get_n").html()) < 1 || parseInt($(".cm_magic_get_n").html()) > 10) {
            return;
        }
        $.ajax({
            'async': false,
            'cache': false,
            'url': 'ajax/marktime.php',
            'type': 'post',
            'dataType': 'JSON',
            'data': {'count': parseInt($(".cm_magic_get_n").html())}
        }).done(function (obj) {
            if (obj.errcode == 0) {
                $(".bg,.coin_magic").hide();
                $(".sb_magic_num").html(obj.data.count);
                $(".sb_magic").removeClass('sb_magic_0');
                $(".cm_coin_total_n").data("coins", obj.data.coins).html(obj.data.coins);
                $("#mc_coin").data('number', obj.data.coins).html(obj.data.coins);
            } else {
                $('.tips').html(obj.msg).css({
                    'top': $(window).scrollTop() - 100,
                    'opacity': 1,
                    'left': '50%',
                    'margin-left': '290px'
                }).animate({'top': $(window).scrollTop() + $(window).height() / 4}, 'fast');
                setTimeout(function () {
                    $('.tips').animate({left: -200, opacity: 0}, 'fast');
                }, 1000);
            }
        });
    });
    $(".coin_magic_close").click(function () {
        $(".cm_coin_total_n").html($(".cm_coin_total_n").data("coins"));
        $(".bg,.coin_magic").hide();
    });
    $(".sb_magic").click(function () {
        $("#eLightCanvas").remove();
        if ($(this).hasClass('sb_magic_0')) {
            var num = Math.floor(parseInt($(".cm_coin_total_n").data("coins")) / 2500);
            num = num >= 5 ? 5 : num;
            $(".cm_magic_get_n").html(num);
            $(".cm_coin_total_n").html(parseInt($(".cm_coin_total_n").data("coins")) - (num * 2500));
            $(".bg,.coin_magic").show();
        } else {
            $.ajax({
                'async': false,
                'cache': false,
                'url': 'ajax/marktime.php',
                'type': 'post',
                'dataType': 'JSON',
                'data': {'type': 'use_magic', 'stage_id': stage_id}
            }).done(function (obj) {
                if (obj.errcode == 0) {
                    if (obj.current == 0) {
                        $('.tips').html('时之刻印：拥有穿越时空的神奇魔力，做错题时就使用吧~').css({
                            'top': $(window).scrollTop() - 100,
                            'opacity': 1,
                            'left': '50%',
                            'margin-left': '-290px'
                        }).animate({'top': $(window).scrollTop() + $(window).height() / 4}, 'fast');
                        setTimeout(function () {
                            $('.tips').animate({left: -200, opacity: 0}, 'fast');
                        }, 1000);
                    } else {
                        markTimeMagic();
                        setTimeout(function () {
                            is_submitting = false;
                            $('#current').html(obj.current);
                            $(".kq_q_body").hide();
                            $(".kq_q_body:eq(" + (obj.current - 1) + ")").show();
                            switchTo(obj.current - 1);
                            var width = $('.kq_q_list').width() * (obj.data.corrects) / obj.data.answer.length;
                            $('.kq_q_list_finished').animate({width: width + 'px'});
                            $('.kq_q_star:eq(' + (obj.data.stars) + ')').removeClass('kq_q_star_yes');
                            $task1 = obj.data.after_tasks / 4;
                            if ($task1 < 1) {
                                $("#knowledge_task1").hide();
                            }
                            $task2 = (obj.data.after_tasks % 4) / 2;
                            if ($task2 < 1) {
                                $("#knowledge_task2").hide();
                            }
                            $task3 = obj.data.after_tasks % 2;
                            if ($task3 < 1) {
                                $("#knowledge_task3").hide();
                            }
                            if (parseInt($(".sb_magic_num").html()) - 1 == 0) {
                                $(".sb_magic").addClass('sb_magic_0');
                            } else {
                                $(".sb_magic_num").html(parseInt($(".sb_magic_num").html()) - 1);
                            }
                            runCheckTime(obj.time_left);
                            runErrorLeft(obj.error_left);
                        }, 2000);
                    }
                } else if (obj.errcode == 1) {
                    $(".sb_magic").addClass('sb_magic_0');
                    $(".sb_magic").click();
                }
            });
        }
    });

    function switchTo(no) {
        var $questions = $frame.find('.kq_q_body');
        $current = $questions.filter(function () {
            if ($(this).data('index') == no) {
                return true;
            }
        });
        $q = ucq($current.data('question_id'));
        $q.reset();
        $q.focus();
        $('.kq_right_btn,.kq_wrong_btn,.stage_question_explain,.stage_question_line,.stage_question_explains').hide();
        if ($current.data('qtype') == 4) {
            $('.kq_submit_btn').hide();
            $('.kq_done_btn').show();
        } else {
            $('.kq_submit_btn').show();
            $('.kq_done_btn').hide();
        }
        $(window).scrollTop(0);
    }


    //todo 修改区2017-10-07


    $(".xy_sel_box li").click(function () {


        console.log($(this).data('tag'));

        $(this).addClass('ucqo_g_selected');
        $(this).siblings().removeClass('ucqo_g_selected'); //返回兄弟姐妹节点，不分前后

        console.log($(this).hasClass("ucqo_g_selected"));


    });


    var answerAndId = [];

    $(".xy_test_btn").click(function () {

        $(".xy_sel_box .ucqo_g_selected").each(function () {
            answerAndId.push($(this).data('tag'));
        });

        if (answerAndId.length === 1) {
            layer.msg('您只答了1道题', function(){
                window.location.reload(); //todo 目前需刷新，不然会有错误
            //关闭后的操作
            });

        } else if (answerAndId.length === 3) {

            window.location.href = "./section_analysis.php?answer=" + answerAndId.toString() + '&vid=' + vid;

        } else if (answerAndId.length === 2) {
            layer.msg('您只答了2道题', function(){
               window.location.reload(); //todo 目前需刷新，不然会有错误
                //关闭后的操作
            });



        } else {
            layer.msg('您还未作答！', function(){
               window.location.reload(); //todo 目前需刷新，不然会有错误
                //关闭后的操作
            });

        }

        console.log(answerAndId);

    });




/*

    var is_submitting = false;
   var is_complete = false;
    $('.kq_submit_btn').click(function () {
        var question_id = $current.data('question_id');
        var answer = JSON.stringify($q.val());



        if (answer == '[""]') {
            $q.focus();
            return;
        }
        if (is_submitting) {
            return;
        }
        if (is_complete) {
            return;
        }
        is_submitting = true;

        $.ajax({
            async: true,
            cache: false,
            url: "./RESTApi/answer_stage_question.php",
            data: {stage_id: stage_id, question_id: question_id, answer: answer},
            dataType: 'JSON'
        }).done(function (res) {
            if (res.errcode != 0) {
                window.location.reload();
                return;
            }
            is_complete = res.data.completed;
            runErrorLeft(res.data.error_left);
            showResult(res.data);
        }).complete(function () {
            is_submitting = false;
        });


    });



*/



    $('.kq_done_btn').click(function () {
        $(this).hide();
        $('.kq_right_btn,.kq_wrong_btn,.stage_question_explain,.stage_question_line,.stage_question_explains').show();
        $current.find('.kq_q_body_content').css('min-height', '0px');
        $('html,body').animate({scrollTop: $current.find('.stage_question_line').offset().top + 'px'});
    });


    $('.kq_right_btn,.kq_wrong_btn').click(function () {
        var question_id = $current.data('question_id');
        var answer = 1;
        if ($(this).hasClass('kq_right_btn'))
            answer = 1; else if ($(this).hasClass('kq_wrong_btn'))
            answer = 0;
        if (is_submitting) {
            return;
        }
        if (is_complete) {
            return;
        }
        is_submitting = true;
        $.ajax({
            async: true,
            cache: false,
            url: "ajax/answer_stage_question.php",
            data: {stage_id: stage_id, question_id: question_id, answer: answer},
            dataType: 'JSON'
        }).done(function (res) {
            if (res.errcode != 0) {
                window.location.reload();
                return;
            }
            is_complete = res.data.completed;
            runErrorLeft(res.data.error_left);
            showResult(res.data);
        }).complete(function () {
            is_submitting = false;
        });
    });


    if ($('#kq_answer_result').length == 0) {
        $('body').append('<div id="kq_answer_result" class="kq_answer_result"></div>');
    }

    function showResult(data) {
        var width = $('.kq_q_list').width() * (data.corrects) / data.answer.length;
        var e = $('.kq_q_star:eq(' + (data.stars - 1) + ')');
        if (data.stars <= 0 || e.hasClass('kq_q_star_yes')) {
            playAnswerAudio(data.completed, data.correct, false);
        } else {
            playAnswerAudio(data.completed, data.correct, true);
        }
        if (data.correct == false) {
            if ($('#current').html() - data.corrects == 1 && data.completed == false) {
                enhanceLight();
            }
            heartBroken();
        }
        $('.kq_q_list_finished').animate({width: width + 'px'}, 100, function () {
            var e = $('.kq_q_star:eq(' + (data.stars - 1) + ')');
            if (data.stars <= 0 || e.hasClass('kq_q_star_yes')) {
            } else {
                e.addClass('kq_q_star_yes').addClass('star');
                e.append('<div class="light"></div>');
                playStarErupt(parseInt($(e).css("left")));
                setTimeout(function () {
                    e.find('.light').remove();
                }, 1000);
            }
        });
        if (data.former_tasks < data.after_tasks) {
            var task_tran = [];
            var task_add = data.after_tasks - data.former_tasks;
            if (task_add / 4 >= 1 && $("#knowledge_task1").css("display") == "none") {
                task_tran.push(1);
            }
            if ((task_add % 4) / 2 >= 1 && $("#knowledge_task2").css("display") == "none") {
                task_tran.push(2);
            }
            if (task_add % 2 >= 1 && $("#knowledge_task3").css("display") == "none") {
                task_tran.push(3);
            }
            stageTasks(task_tran);
        }
        if (data.completed == false) {
            $('#current').html(data.current + 1);
            $(".kq_q_body").hide();
            $(".kq_q_body:eq(" + data.current + ")").show();
            if ($(".kq_q_body:eq(" + data.current + ")").data('pattern') != "") {
                patternShow($(".kq_q_body:eq(" + data.current + ")").data('pattern'));
            }
            switchTo(data.current);
        } else {
            var e = $('.kq_q_star:eq(' + (data.stars - 1) + ')');
            var done_animate_delay = 0;
            if (data.stars > 0 && !e.hasClass('kq_q_star_yes')) {
                done_animate_delay = 1000;
            }
            setTimeout(function () {
                var $kq_result = $('#kq_answer_result');
                var wHeight = window.innerHeight > document.body.scrollHeight ? window.innerHeight : document.body.scrollHeight;
                $kq_result.height(wHeight);
                $kq_result.show();
                $kq_result.css('visibility', 'hidden');
                playDoneAnimate($kq_result.get(0), data.stars, data.award.coins, data.award.experiences, data.award.gems, data.stars > 0, data.accuracy, data.durations, data.answer, data.task);
                if (data.after_tasks >= 7 && data.former_tasks < 7) {
                    playTask(2000, data.former_tasks, data.after_tasks);
                    if (data.animate_rounds) {
                        playRound(2500, true);
                    }
                } else if (data.animate_rounds) {
                    playRound(2000, false);
                }
                if ($kq_result.find('.kq_answer_todo').length <= 0) {
                    $kq_result.append('<div class="kq_answer_todo"></div>');
                    var sTop = wHeight <= 650 + $(window).scrollTop() ? wHeight - 650 : $(window).scrollTop();
                    $('.kq_answer_todo').css('top', sTop + 600 + 'px');
                }
                var analysis_link = 'stage_analysis.php?id=' + stage_id;
                var redo_link = 'stage_start.php?id=' + stage_id;
                var over_link = 'stages.php?id=' + category_id;
                var todo_inner_html;
                if (data.stars > 0) {
                    todo_inner_html = ['<div>', '<a class="cr_button btn_blue" href="' + analysis_link + '">看解析</a>', '<a class="cr_button btn_blue" href="' + redo_link + '">重新闯关</a>', '<a class="cr_button btn_green" href="' + over_link + '">继续闯关</a>', '</div>'].join('');
                } else {
                    todo_inner_html = ['<div>', '<a class="cr_button btn_blue" href="' + analysis_link + '">看解析</a>', '<a class="cr_button btn_blue" href="' + over_link + '">返回</a>', '<a class="cr_button btn_green" href="' + redo_link + '">重新闯关</a>', '</div>'].join('');
                }
                $kq_result.find('.kq_answer_todo').html(todo_inner_html);
                if (data.task.length <= 0) {
                    $kq_result.find('.kq_answer_todo').css('top', '470px');
                }
                $kq_result.css('visibility', 'visible');
            }, done_animate_delay);
        }
        return;
    }





    function checkTime(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    }

    if ($('#time_left').val() != undefined) {
        runCheckTime($('#time_left').val());
    }
    var timer;

    function runCheckTime(total_second) {
        clearInterval(timer);
        timer = window.setInterval(function () {
            if (total_second > 0) {
                total_second--;
                var minute = Math.floor(total_second / 60);
                var second = Math.floor(total_second % 60);
                $(".kq_q_timer>div").html(checkTime(minute) + ":" + checkTime(second));
            } else {
                $.ajax({
                    async: false,
                    cache: false,
                    dataType: 'JSON',
                    url: "ajax/stage_over.php",
                    data: {stage_id: stage_id}
                }).done(function (res) {
                    if (res.errcode == 0) {
                        clearInterval(timer);
                        showResult(res.data);
                    } else {
                        total_second = res.data.time_left;
                    }
                });
            }
        }, 1000);
    }

    function runErrorLeft(error_left) {
        $(".kq_q_times>div>span").html(error_left);
    }

    function heartBroken() {
        $(".kq_q_times").append('<div class="heart_broken"></div>');
        setTimeout(function () {
            $(".kq_q_times .heart_broken").remove();
        }, 1000);
    }

    if (performance.navigation.type == 0 && $('.kq_q_body').first().data('pattern') != '') {
        setTimeout(function () {
            patternShow($('.kq_q_body').first().data('pattern'));
        }, 200);
    }

    function patternShow(pattern_title) {
        $('body').append('<div class="pattern_bg" style="position:absolute;pointer-events:none;top:0;left:0;right:0;height:80px;overflow:hidden;"></div>');
        var style1 = 'width:404px;'
            + 'height:55px;'
            + 'vertical-align:middle;'
            + 'padding:0px 10px;'
            + 'background:url(http://www.91xiaoyu.com/images/pattern.png) 0px 10px no-repeat;'
            + 'position:absolute;'
            + 'left: -30%;'
            + 'margin-left:-298px;'
            + 'z-index:1001;'
            + 'top:10px;'
            + 'font-size:16px;'
            + 'text-align:center;'
            + 'color:#FFF;'
            + 'font-weight:bold;';
        var style2 = 'width: 1px;'
            + 'height: 100%;'
            + 'margin-left: -1px;'
            + 'vertical-align: middle;'
            + 'display: inline-block;';
        var $last_pattern_bg = $('.pattern_bg').last();
        $last_pattern_bg.append('<div class="pattern" style="' + style1 + '"><span style="' + style2 + '"></span><span style="vertical-align: middle;display: inline-block;">' + pattern_title + '</span></div>');
        var $last_pattern = $('.pattern').last();
        $last_pattern.animate({left: "55%"}, 300);
        $last_pattern.animate({left: "48%"}, 80);
        $last_pattern.animate({left: "52%"}, 70);
        $last_pattern.animate({left: "49%"}, 50);
        $last_pattern.animate({left: "50%"}, 10);
        setTimeout(function () {
            $last_pattern.animate({left: "150%"}, 300);
        }, 2 * 1000);
        setTimeout(function () {
            $last_pattern_bg.remove();
        }, 2 * 1000 + 300);
    }
});








function playAudio(btn) {
    var $questions = $('#kq_frame').find('.kq_q_body');
    $current = $questions.filter(function () {
        if ($(this)[0].style.display == 'block') {
            return true;
        }
    });
    var cur_audio = $current.find("audio:eq(0)")[0];
    if (!(cur_audio.addEventListener && cur_audio.play)) {
        return;
    }
    var timer = setInterval(function () {
        if (btn.style['backgroundPosition'] == '-32px -800px') {
            btn.style['backgroundPosition'] = '-33px -800px';
        } else {
            btn.style['backgroundPosition'] = '-32px -800px';
        }
    }, 500);
    cur_audio.addEventListener('ended', function () {
        clearInterval(timer);
        btn.style['backgroundPosition'] = '-32px -800px';
    });
    cur_audio.play();
}
;
/* DCwgi.js */
(function () {
    var time = {};
    var eLight = {};
    var eStar = {};
    window.markTimeMagic = function () {
        if (!g.Renderable)
            return;
        time.play();
    };
    window.enhanceLight = function () {
        if (!g.Renderable)
            return;
        eLight.play();
    };
    if (!g.Renderable)
        return;
    $(window).bind('load', function () {
        g.loadImage({
            marktime: 'http://www.91xiaoyu.com/images/marktime_magic.png',
            particle: 'http://www.91xiaoyu.com/images/pass_particle.png',
            starLight: 'http://www.91xiaoyu.com/images/star_light.png'
        });
        g.audio.prepare({marktime_effect: {urls: ['v2/sound/marktime_effect.mp3'], preload: true}});
    });
    time.isInit = false;
    eLight.isInit = false;
    eStar.isInit = false;
    time.init = function (callback) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', 'marktime_magic');
        var mTop = $(window).scrollTop() - 38;
        canvas.setAttribute('style', 'position: absolute;top: ' + mTop + 'px;left: -340px;z-index:1111;');
        $("#kq_frame").append(canvas);
        var mWidth = document.body.scrollWidth > window.innerWidth ? document.body.scrollWidth : window.innerWidth;
        var mHeight = document.body.scrollHeight > window.innerHeight ? document.body.scrollHeight : window.innerHeight;
        time.view = g.initView('marktime_magic', 1400, mHeight, false);
        time.world = time.view.world;
        time.view.clearBeforeDraw = true;
        g.loadImage({
            marktime: 'http://www.91xiaoyu.com/images/marktime_magic.png',
            particle: 'http://www.91xiaoyu.com/images/pass_particle.png'
        }, function (images) {
            time.images = g.divideImage({
                time_hourglass: [images.marktime, 0, 0, 161 * 5, 216],
                hourglass: [images.marktime, 161 * 4, 0, 161, 216],
                hourglass1: [images.marktime, 0, 0, 161, 216],
                time_light: [images.marktime, 805, 0, 237, 250],
                star_erupt: [images.particle, 240, 0, 60, 40],
                star1: [images.particle, 0, 40, 75, 80],
                star2: [images.particle, 75, 40, 75, 80],
                star3: [images.particle, 150, 40, 75, 80],
                star4: [images.particle, 225, 40, 75, 80]
            });
            time.isInit = true;
            delete images;
            g.audio.prepare({marktime_effect: {urls: ['v2/sound/marktime_effect.mp3'], preload: true}});
            typeof callback == 'function' ? callback() : '';
        });
    };
    time.play = function () {
        if (time.isInit == false) {
            time.init(function () {
                time.play();
            });
            return;
        }
        time.view.resume();
        time.world.removeAllChild();
        var mWidth = document.body.scrollWidth > window.innerWidth ? document.body.scrollWidth : window.innerWidth;
        var mHeight = document.body.scrollHeight > window.innerHeight ? document.body.scrollHeight : window.innerHeight;
        $('body').append('<div id="canvas_bg" style="position:absolute;top:0;left:0;background:rgba(0,0,0,0.7);width:' + mWidth + 'px;height:' + mHeight + 'px;z-index:1110"></div>');
        $('#marktime_magic').css('z-index', '1111');
        setTimeout(function () {
            $('#marktime_magic').css('z-index', '-1');
            $('#canvas_bg').remove();
            g.world.removeAllChild();
        }, 2700);
        time.world.appendChild(new time.Container({top: 200, left: 600, width: 1000, height: 1000}));
    };
    time.Container = g.Container.extend({
        init: function (settings) {
            this._super(g.Container, 'init', [settings]);
            var top = 0;
            var left = 0;
            new time.timeHourDown({
                image: time.images.hourglass1,
                top: 0,
                left: 0,
                zIndex: 11,
                scaleX: 0.7,
                scaleY: 0.7
            }).appendTo(this);
            this.pushClip(function () {
                new time.timeHour({top: 0.5, left: 0, zIndex: 10, scaleX: 0.7, scaleY: 0.7}).appendTo(this);
            }, 800);
            var delay = 500;
            this.pushClip(function () {
                this.appendChild(new time.timeHourTemp({
                    image: time.images.hourglass,
                    top: 0,
                    left: 0,
                    zIndex: 9,
                    time: delay + 50,
                    scaleX: 0.7,
                    scaleY: 0.7
                }));
            }, 1100);
            this.pushClip(function () {
                this.appendChild(new time.hourglass({
                    image: time.images.hourglass,
                    top: 0,
                    left: 0,
                    zIndex: 8,
                    scaleY: 0.7,
                    scaleX: 0.7
                }));
                g.audio.get('marktime_effect').play();
            }, 1150 + delay);
            this.pushClip(function () {
                this.appendChild(new time.timeLight({image: time.images.time_light, top: 0, left: -35, zIndex: 7}));
                this.appendChild(new time.StarErupt({top: 0, left: 0}));
                this.appendChild(new time.StarErupt1({top: 0, left: 0}));
            }, 1200 + delay);
        }
    });
    time.timeHourDown = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            this.top = g.easing(this.clock / 800, -500, 0, g.easing.Bounce.Out);
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, 800);
            this.isDirty = true;
            this.isMoved = true;
        }
    });
    time.timeHourTemp = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, settings.time);
        }
    });
    time.timeHour = g.AnimateSheet.extend({
        init: function (settings) {
            settings.image = time.images.time_hourglass;
            settings.width = 161;
            settings.height = 216;
            settings.frames = 5;
            settings.lineFrames = 5;
            settings.speed = 80;
            this._super(g.AnimateSheet, 'init', [settings]);
            this.addAnimate('main', [0, 1, 2, 3, 4]);
            this.setCurrentAnimate('main', 1);
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, 350);
        }
    });
    time.hourglass = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.clock = 0;
            this.isContentCacheable = true;
        }, update: function (dt) {
            if (this.duration != Infinity) {
                this.clock += dt;
                this.isMoved = true;
                this.scaleX = 0.7 + this.clock * 0.0020;
                this.scaleY = 0.7 + this.clock * 0.0020;
                this.opacity = 1 - this.clock * 0.0009;
                this.pushClip(function (clock) {
                    this.remove.defer(this);
                }, 1000);
            }
        }
    });
    time.timeLight = g.Sprite.extend({
        init: function (settings) {
            this._super(g.Sprite, 'init', [settings]);
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            this.scaleX = 1.2 + this.clock * 0.004;
            this.scaleY = 1.2 + this.clock * 0.004;
            this.opacity = 1 - this.clock * 0.0009;
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, 1000);
        }
    });
    time.StarErupt = g.Sprite.extend({
        init: function (settings) {
            settings.image = time.images.star_erupt;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 85;
            this.y0 = 85;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            for (var i = 0; i < 250; i++) {
                var temp = {scale: Math.rand(0.4, 0.6), x: 0, y: 0,};
                temp.r = Math.rand(0, 500);
                temp.angle = Math.rand(0, 360);
                temp.x0 = temp.r * Math.cos(temp.angle);
                temp.y0 = temp.r * Math.sin(temp.angle);
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 1000, 0, temp.x0, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 1000, 0, temp.y0, g.easing.Quadratic.Out);
                temp.opacity = g.easing(this.clock / 1000, 1, 0, g.easing.Quadratic.Out);
            }
            if (this.clock > 1000) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
    time.StarErupt1 = g.Sprite.extend({
        init: function (settings) {
            settings.image = time.images.star1;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 85;
            this.y0 = 85;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            for (var i = 0; i < 40; i++) {
                var temp = {scale: Math.rand(0.2, 1.4), x: 0, y: 0, image: time.images.star_erupt};
                temp.r = Math.rand(0, 650);
                temp.angle = Math.rand(0, 360);
                temp.x0 = temp.r * Math.cos(temp.angle);
                temp.y0 = temp.r * Math.sin(temp.angle);
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 1200, 0, temp.x0, g.easing.Cubic.Out);
                temp.y = g.easing(this.clock / 1200, 0, temp.y0, g.easing.Cubic.Out);
                temp.opacity = g.easing(this.clock / 1200, 1, 0, g.easing.Quadratic.Out);
                if (i % 4 == 0)
                    temp.image = time.images.star1
                else if (i % 4 == 1)
                    temp.image = time.images.star2
                else if (i % 4 == 2)
                    temp.image = time.images.star3
                else if (i % 4 == 3)
                    temp.image = time.images.star4
            }
            if (this.clock > 1200) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.objs[i].image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
    eLight.init = function (callback) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', 'eLightCanvas');
        canvas.setAttribute('style', 'position: absolute;top: -60px;left: -62px;z-index:1;pointer-events: none;');
        $(".sb_magic").append(canvas);
        eLight.view = g.initView('eLightCanvas', 200, 200, false);
        eLight.world = eLight.view.world;
        eLight.view.clearBeforeDraw = true;
        g.loadImage({
            starLight: 'http://www.91xiaoyu.com/images/star_light.png',
            starErupt: 'http://www.91xiaoyu.com/images/pass_particle.png'
        }, function (images) {
            eLight.images = g.divideImage({
                light: [images.starLight, 0, 0, 700, 140],
                star: [images.starErupt, 240, 0, 60, 40]
            });
            eLight.isInit = true;
            delete images;
            typeof callback == 'function' ? callback() : '';
        });
    };
    eLight.play = function () {
        if (eLight.isInit == false) {
            eLight.init(function () {
                eLight.play();
            });
            return;
        }
        eLight.view.resume();
        eLight.world.removeAllChild();
        eLight.world.appendChild(new eLight.Container({top: 0, left: 0, width: 200, height: 200}));
    };
    eLight.Container = g.Container.extend({
        init: function (settings) {
            this._super(g.Container, 'init', [settings]);
            eLight.enAnimate(this);
        }
    });
    eLight.enAnimate = function (thiz) {
        var isAdd = false;
        thiz.pushClip(function (clock) {
            if (!isAdd) {
                new eLight.enLight({top: 15, left: 33, scaleX: 0.7, scaleY: 0.7, opacity: 0.7}).appendTo(this);
                this.appendChild(new eLight.enStar({top: 18, left: 45}));
                isAdd = true;
            }
            if (clock >= 1700) {
                eLight.enAnimate(this);
            }
        }, 0, 1700);
    };
    eLight.enLight = g.AnimateSheet.extend({
        init: function (settings) {
            settings.image = eLight.images.light;
            settings.width = 140;
            settings.height = 140;
            settings.frames = 5;
            settings.lineFrames = 5;
            settings.speed = 80;
            this._super(g.AnimateSheet, 'init', [settings]);
            this.addAnimate('main', [0, 1, 2, 3, 4]);
            this.setCurrentAnimate('main', 1);
            this.pushClip(function (clock) {
                this.remove.defer(this);
            }, 2000);
        }
    });
    eLight.enStar = g.Sprite.extend({
        init: function (settings) {
            settings.image = eLight.images.star;
            this._super(g.Sprite, 'init', [settings]);
            this.x0 = 80;
            this.y0 = 80;
            this.sw = this.width;
            this.sh = this.height;
            this.objs = [];
            for (var i = 0; i < 50; i++) {
                var temp = {scale: Math.rand(0.2, 0.4), x: 0, y: 0,};
                temp.r = Math.rand(0, 50);
                temp.angle = Math.rand(0, 360);
                temp.x0 = temp.r * Math.cos(temp.angle);
                temp.y0 = temp.r * Math.sin(temp.angle);
                this.objs.push(temp);
            }
            this.clock = 0;
        }, update: function (dt) {
            this.clock += dt;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                var temp = this.objs[i];
                temp.x = g.easing(this.clock / 1000, 0, temp.x0, g.easing.Quadratic.Out);
                temp.y = g.easing(this.clock / 1000, 0, temp.y0, g.easing.Quadratic.Out);
                if (this.clock > 600)
                    temp.opacity = g.easing((this.clock - 600) / 400, 1, 0, g.easing.Quadratic.Out);
            }
            if (this.clock > 1000) {
                this.remove.defer(this);
            }
            this.isDirty = true;
        }, draw: function (ctx) {
            ctx.translate(~~(this.x0 - (this.sw) / 2), ~~(this.y0 - (this.sh) / 2));
            var globalAlpha = ctx.globalAlpha;
            for (var i = 0, len = this.objs.length; i < len; i++) {
                ctx.globalAlpha = globalAlpha * this.objs[i].opacity;
                ctx.drawImage(this.image, this.sx, this.sy, this.sw, this.sh, this.objs[i].x, this.objs[i].y, this.sw * this.objs[i].scale, this.sh * this.objs[i].scale);
            }
        }
    });
})();
;
/* uf7HB.js */
(function () {
    var animates = [];
    var interval = setInterval(function () {
        var now = new Date().getTime();
        for (var i = 0; i < animates.length; i++) {
            var animate_time = now - animates[i].start_time;
            if (animates[i].finished == true) {
                animates.splice(i, 1);
                continue;
            }
            for (var j = animates[i]['actions'].length - 1; j >= 0; j--) {
                var param = animates[i]['actions'][j];
                if (animate_time < param.start || (animate_time - param.start) / param.interval < param.tick)
                    continue;
                param.tick++;
                var is_end = false;
                if (param.last != 0) {
                    var progress = (animate_time - param.start) / param.last;
                    if (progress > 1) {
                        progress = 1;
                        is_end = true;
                    }
                    if (param.func(param.tick, progress) == true) {
                        is_end = true;
                    }
                } else {
                    is_end = param.func(param.tick);
                }
                if (is_end == true) {
                    animates[i]['actions'].splice(j, 1);
                    if (animates[i]['actions'].length <= 0) {
                        animates.splice(i, 1);
                    }
                }
            }
        }
    }, 20);
    window.Animate = function (global_interval) {
        this.actions = [];
        this.finished = false;
        this.start_time = 0;
        var interval_id, start_time, actions = this.actions,
            global_interval = global_interval == undefined ? 20 : global_interval;
        this.start = function () {
            if (this.actions.length <= 0) {
                return false;
            }
            this.start_time = new Date().getTime();
            animates.push(this);
        };
        this.stop = function () {
            this.finished = true;
        };
        this.push = function (func, start, last, interval) {
            actions.push({
                func: func,
                start: start == undefined ? 0 : start,
                last: last == undefined ? 0 : last,
                interval: interval == undefined ? global_interval : interval,
                tick: 0
            });
        };
        this.pushClip = function (clip, start) {
            start = start == undefined ? 0 : start;
            for (var i = clip.actions.length - 1; i >= 0; i--) {
                clip.actions[i].start += start;
                actions.push(clip.actions[i]);
            }
        };
    };
    window.loadImage = function (images, callback) {
        var loading_count = 0;
        for (i in images) {
            loading_count++;
            var src = images[i];
            images[i] = new Image();
            images[i].src = src;
            images[i].onload = function () {
                loading_count--;
                if (loading_count == 0) {
                    typeof callback == 'function' ? callback() : '';
                }
            };
        }
    };
})();
;

/* 113KmT.js */
function my_card_play_animation() {
    $(document).ready(function () {
        var animate = new Animate();
        var $expgap = $('#mc_expgap');
        animate.push(function (tick, progress) {
            $expgap.width(parseInt($expgap.data('number') * progress));
        }, 0, 1500);
        var numbers = [$('#mc_exp'), $('#mc_coin'), $('#mc_star'), $('#mc_gem')];
        $.each(numbers, function (index, element) {
            var number = element.data('number');
            animate.push(function (tick, progress) {
                element.html(parseInt(number * progress));
            }, 0, 1500);
        });
        animate.start();
    });
}

function my_card_add_counts(exps, coins, gems, stars, lv_up, last_time) {
    exps = parseInt(exps);
    coins = parseInt(coins);
    gems = parseInt(gems);
    star = parseInt(stars);
    lv_up = parseInt(lv_up);
    var $exp = $('#mc_exp');
    var $coin = $('#mc_coin');
    var $gem = $('#mc_gem');
    var $star = $('#mc_star');
    var $level = $('#mc_level');
    var $expgap = $('#mc_expgap');
    var $expwrap = $('#mc_expwrap');
    var ori_exp = parseInt($exp.data('number'));
    var ori_coin = parseInt($coin.data('number'));
    var ori_gem = parseInt($gem.data('number'));
    var ori_star = parseInt($star.data('number'));
    var lv_up_exp = parseInt($expwrap.data('levelup_exp'));
    $exp.data('number', ori_exp + exps);
    $coin.data('number', ori_coin + coins);
    $gem.data('number', ori_gem + gems);
    $star.data('number', ori_star + stars);
    var animate = new Animate();
    last_time = last_time == undefined ? 1 : last_time;
    animate.push(function (tick, progress) {
        $coin.html(ori_coin + parseInt(coins * progress));
        $gem.html(ori_gem + parseInt(gems * progress));
        $star.html(ori_star + parseInt(stars * progress));
    }, 0, last_time);
    animate.push(function (tick, progress) {
        var curr_exp = ori_exp + parseInt(exps * progress);
        var gap_width = 138;
        if (curr_exp >= lv_up_exp) {
            $level.html(parseInt($level.data('number')) + 1);
            $level.data('number', parseInt($level.data('number')) + 1);
            ori_exp = ori_exp - lv_up_exp;
            curr_exp = curr_exp - lv_up_exp;
            lv_up_exp += 2500;
            $expwrap.data('levelup_exp', lv_up_exp);
        }
        gap_width = (ori_exp + exps * progress) * 138 / lv_up_exp;
        $exp.html(curr_exp);
        if (gap_width < 0) {
            gap_width = 0;
        }
        if (gap_width > 138) {
            gap_width = 138;
        }
        $expgap.width(parseInt(gap_width));
    }, 0, last_time, 1);
    $expwrap.attr('title', '升到下一级还需' + (lv_up_exp - ori_exp - exps) + '点经验');
    return animate;
}

$(document).ready(function () {
    var messages = [];
    var isModuleLoading = false;
    var new_messages = 0;
    var exps = 0;
    var lastExpGetTime = 0;
    var lastUpdateTime = 0;

    function updateMessage() {
        $.ajax({
            url: "ajax/get_data1.php", type: "POST", data: {}, dataType: "JSON", success: function (res) {
                messages = res.data.message.messages;
                new_messages = res.data.message.unreads;
                exps = res.data.exp.exps;
                loadMessageModule();
                fixNewMessageDisplay();
                updateExps();
            }
        });
    }

/*    updateMessage();
    setInterval(function () {
        lastUpdateTime += 5000;
        if ((lastExpGetTime == 0 && lastUpdateTime > 60000) || (exps <= 0 && lastExpGetTime != 0 && (new Date().getTime() - lastExpGetTime) > 300000)) {
            lastUpdateTime = 0;
            updateMessage();
        }
    }, 5000);*/

    function loadMessageModule() {
        var effects = [];
        for (var i in messages) {
            try {
                if (messages[i].type == 2)
                    effects.push(messages[i].ext.actions[0].effect);
            } catch (e) {
            }
        }
        isModuleLoading = true;
        message.load(effects, function () {
            isModuleLoading = false;
        });
    }

    function fixNewMessageDisplay() {
        if (new_messages > 0) {
            $('#my_card_news').addClass('my_cr_message_new').html(new_messages);
            popAnimate($('#my_card_news'));
        } else {
            $('#my_card_news').removeClass('my_cr_message_new').html('');
        }
    }

    $('#my_card_news').bind('click', function () {
        if (isModuleLoading)
            return;
        if (messages.length <= 0)
            location.href = 'm.php'; else {
            var m = messages.shift();
            if (m.type == 2) {
                new_messages--;
                message.run(m.ext.actions[0]['effect'], m.ext.actions[0]['data']);
                fixNewMessageDisplay();
                $.get('ajax/view_message.php?id=' + m.id + '&index=0');
            }
        }
    });
    var isAudioLoaded = false;

    function updateExps() {
        if (exps > 0 && isAudioLoaded == false && ('ontouchstart' in window)) {
            isAudioLoaded = true;
            g.Renderable && g.audio.prepare({'bottle': {urls: ['v2/sound/exp_bottle.mp3'], preload: true}});
        }
        var percent = exps / 10000;
        var level = 1;
        if (percent > 0.95)
            level = 4; else if (percent > 0.35)
            level = 3; else if (percent > 0)
            level = 2;
        if (level == 4) {
            shakeAnimate($('#get_experience'));
        } else {
            stopShakeAnimate($('#get_experience'));
        }
        $('#get_experience').removeClass('my_exp1 my_exp2 my_exp3 my_exp4').addClass('my_exp' + level);
        $('#get_experience').attr('title', '' + exps + '点经验');
    }

    function popAnimate($e) {
        if (!$e.hasClass('my_cr_message_new')) {
            return false;
        }
        if ($e.hasClass('poping')) {
            return true;
        }
        $e.addClass('poping');
        var animate = new Animate(60);
        var duration = 750;
        var interval = 4000;
        animate.push(function (tick) {
            var t = (tick * 60) % interval;
            if (t <= duration) {
                var do_percent = t / duration;
                if (t <= duration * 0.25) {
                    var scale = 1 + (1.4 - 1) * do_percent;
                } else {
                    var scale = 1 + (1.4 - 1) * (1 - do_percent);
                }
                scale = scale.toFixed(2);
                $e.css('-webkit-transform', 'scale(' + scale + ',' + scale + ')').css('transform', 'scale(' + scale + ',' + scale + ')');
                if (do_percent == 1) {
                    $e.removeClass('poping');
                }
            }
        }, 0, 10000000, 1);
        animate.start();
    }

    function shakeAnimate($e) {
        if ($e.hasClass('shaking')) {
            return true;
        }
        $e.addClass('shaking');
        var animate = new Animate(60);
        var duration = 1000;
        var interval = 4000;
        var flag = false;
        animate.push(function (tick) {
            var t = (tick * 60) % interval;
            if (t > duration) {
                flag = true;
                $e.css('-webkit-transform', 'rotate(0deg)');
                $e.css('transform', 'rotate(0deg)');
            } else {
                flag = false;
            }
            if (flag == false) {
                var do_percent = t / duration;
                if (!$e.hasClass('shaking')) {
                    animate.stop();
                    $e.css('-webkit-transform', 'rotate(0deg)');
                    $e.css('transform', 'rotate(0deg)');
                    return;
                }
                var rotate = g.easing(do_percent, 0, 30, function (k) {
                    return Math.sin(k * Math.PI * 2 * 4);
                });
                $e.css('-webkit-transform', 'rotate(' + rotate.toFixed(2) + 'deg)');
                $e.css('transform', 'rotate(' + rotate.toFixed(2) + 'deg)');
            }
        }, 0, 10000000, 1);
        animate.start();
    }

    function stopShakeAnimate($e) {
        $e.removeClass('shaking');
        $e.css('-webkit-transform', 'rotate(0deg)');
        $e.css('transform', 'rotate(0deg)');
    }

    function playExpBottleAnimate(exps) {
        var $bottle = $('#get_experience');
        stopShakeAnimate($bottle);
        card.play(exps);
        my_card_add_counts(exps, 0, 0, 0, 0, 1000).start();
    }

    $('#get_experience').click(function () {
        if (exps <= 0) {
            return false;
        }
        $.ajax({
            url: "ajax/collect_exp.php", type: "GET", data: {}, dataType: "JSON", success: function (res) {
                var origin = exps;
                if (res.data.exps > 0) {
                    playExpBottleAnimate(res.data.exps);
                }
                stopShakeAnimate($('#get_experience'));
                exps = 0;
                updateExps();
                updateMessage();
                lastExpGetTime = new Date().getTime();
            }
        });
    });
});
(function () {
    window.card = {};
    if (!g.Renderable) {
        card.play = function () {
        };
        return;
    }
    card.isInit = false;
    card.init = function (wrapper, callback) {
        var canvas = document.createElement('canvas');
        canvas.setAttribute('id', 'card_animate_canvas');
        wrapper.appendChild(canvas);
        card.view = g.addView('card_animate_canvas', 600, 400);
        card.world = card.view.world;
        card.view.clearBeforeDraw = true;
        g.loadImage({re: 'http://www.91xiaoyu.com.com/images/re.png'}, function (images) {
            card.images = g.divideImage({bubble: [images.re, 300, 580, 16, 16], drop: [images.re, 60, 580, 34, 42]});
            delete images;
            card.isInit = true;
            card.fonts = {
                number: new g.ShadowFont({
                    fontFamily: 'microsoft yahei',
                    fontSize: 20,
                    color: '#fff',
                    shadowWidth: 2,
                    shadowColor: '#000'
                })
            };
            typeof callback == 'function' ? callback() : '';
            if (location.hash == '#debug') {
                card.world.appendChild(new g.Debug({view: card.view}));
            }
        });
    };
    card.play = function (exps) {
        if (card.view == null) {
            var top = $('#get_experience').offset().top - 135;
            $('body').append('<div id="card_animate" style="pointer-events:none;width:100%;position:absolute;top:' + top + 'px;left:0px;overflow:hidden;height:400px;"><div id="card_animate_wrapper" style="pointer-event:none;position:absolute;top:0px;left:50%;margin-left:154px;width:350px;height:400px;"></div></div>')
            card.init(document.getElementById('card_animate_wrapper'), function () {
                card.play(exps);
            });
            return;
        }
        card.exps = exps;
        document.getElementById('card_animate').style.display = 'block';
        card.view.resume();
        card.world.removeAllChild();
        card.world.appendChild(new card.MainScreen({}));
    };
    card.MainScreen = g.Container.extend({
        init: function () {
            var settings = {width: card.world.width, height: card.world.height - 16};
            this._super(g.Container, 'init', [settings]);
            this.pushClip(function () {
                document.getElementById('card_animate').style.display = 'none';
                card.view.pause();
            }, 3000);
            var percent = card.exps / 10000;
            g.audio.prepare({'bottle': {urls: ['v2/sound/exp_bottle.mp3'], preload: true, autoplay: false}});
            g.audio.get('bottle').play();
            var number = ~~(percent * 120);
            number = number > 40 ? number : 40;
            this.appendChild(new card.Drop(), new card.Number(), new g.ParticleBlow({
                image: card.images.bubble,
                sx: 0,
                sy: 0,
                sw: 16,
                sh: 16,
                x0: ~~(this.width / 2) + 10,
                y0: 134 + 10,
                v0: 0.75,
                divergeAngle: 30 / 180 * Math.PI,
                xRange: 20,
                numbers: number,
                damp: 0.4,
                accelerate: 0.002,
                scaleMax: 1.6,
                scaleMin: 0.4,
                diffTime: 10
            }));
        }
    });
    card.Drop = g.Sprite.extend({
        init: function () {
            this._super(g.Sprite, 'init', [{image: card.images.drop, top: 134, left: (card.world.width / 2)}]);
            this.pushClip(function (clock) {
                this.scale(g.easing(clock / 700, 1, 1.5, function (k) {
                    return Math.sin(Math.PI * k * 2 * 5) * ((1 - k) * (1 - k)) + (-0.4 * k * (2 - k) + 0.4);
                }));
                this.isDirty = true;
            }, 0, 700);
        }
    });
    card.Number = g.FloatText.extend({
        init: function () {
            this._super(g.FloatText, 'init', [{
                font: card.fonts.number,
                text: '+' + card.exps,
                top: 134 + 10,
                left: (card.world.width / 2) + 10,
                textAlign: 'center',
                offset: 60,
                duration: 1000
            }]);
        }
    });
})();
;
/* jDuuT.js */
var message = new (function () {
    var modules = {};
    var loaded = [];
    this.run = function (module, ext) {
        if (hasModule(module))
            return use(module, ext); else
            return false;
    };
    this.load = function (moduleNames, callback) {
        var loads = [];
        for (var i in moduleNames) {
            var temp = moduleNames[i].toLowerCase();
            if ($.inArray(temp, loaded) < 0) {
                loads.push(temp);
                loaded.push(temp);
            }
        }
        if (loads.length > 0) {
            $.getScript('v2/message/js.php?f=' + loads.join('-')).done(function () {
                typeof callback == 'function' && callback();
            });
        } else {
            typeof callback == 'function' && callback();
        }
    };
    this.register = function (module, obj) {
        modules[module] = obj;
    };

    function hasModule(module) {
        return modules[module] != undefined;
    }

    function use(module, param) {
        if (modules[module] == undefined) {
            console.error('module: %s not exist', module);
            return false;
        }
        modules[module].run(param);
        return true;
    }
})();
;
/* 16SkAx.js */












