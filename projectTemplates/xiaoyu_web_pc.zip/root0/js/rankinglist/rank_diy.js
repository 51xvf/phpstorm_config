$(function () {


    ajaxreq();

    function ajaxreq() {
        $.ajax({

            //提交数据的类型 POST GET
            type: "POST",

            //提交的网址
            url: "./RESTApi/doUserRank.php",

            //提交的数据
            data: {do: "act"},

            //返回数据的格式
            datatype: "json",//"xml", "html", "script", "json", "jsonp", "text".

            //在请求之前调用的函数
            beforeSend: function (XMLHttpRequest) {
                //todo
                $(".loading").html("<img src='http://ai.91xiaoyu.com/xiaoyu_pc/images/loading.gif'>");
            },

            //成功返回之后调用的函数
            success: function (data) {

                var jsondata = $.parseJSON(data);

                var temp = "";
                var num = 1;
                var avatar = "";
                var pers = "";
                var me = "";
                var myname = "";
                var star_num =null;
                var jyz_num = null;
                var dat_num = null;


                console.log(jsondata);

                $.each(jsondata, function (key, val) {

                    if (!val.avatar) {
                        avatar = "./images/defimg.png";
                    } else {
                        avatar = val.avatar;
                    }

                    if (val.nickname) {

                        pers = val.nickname;


                    } else {

                        pers = val.mobile;

                    }

                    if (key === jsondata.length - 1) {

                        return false; //跳出循环[zj]

                    }

                    if (val.nickname === nickname) {
                        mystyle = "cc_li_my";
                        me = val.rank;
                        myname = pers;
                        star_num = val.star;
                        jyz_num = val.exp;
                        dat_num = val.stuDay;


                    } else {

                        mystyle = "";
                    }

                    temp += "                    <a href=\"chapterlist.php\">\n" +
                        "                    <div class=\"cc_li clearfix " + mystyle + " \">\n" +
                        "                        <div title='名次' class=\"cc_number top3\">" + "第" + val.rank + "名" + "</div>\n" +
                        "                        <div class=\"cc_level\">" + "<img src='" + avatar + "' height='64' width='64' >" + "</div>\n" +
                        "                        <div class=\"cc_uname ellipsis\">" + pers + "</div>\n" +
                        "                        <div class=\"cc_gems\">累计学习天数" + val.stuDay + "天</div>\n" +
                        "                        <div title='经验值' class=\"cc_coins\"><span title='经验值' class=\"lv_coin\"></span>" + val.exp + "</div>\n" +
                        "                        <div title='星星' class=\"cc_awards\"><span title='星星' class=\"lv_medal\"></span>" + val.star + "</div>\n" +
                        "                    </div>\n" +
                        "                </a>";

                    num++;

                });


                $(".cc_list").append(temp);
                $("#display_clan_no").text(me);
                $(".star_num").text(star_num);
                $(".jyz_num").text(jyz_num);
                $(".dat_num").text(dat_num);


                //todo
            },

            //调用执行后调用的函数
            complete: function (XMLHttpRequest, textStatus) {
                //todo
                $(".loading").empty();
            },

            //调用出错执行的函数
            error: function () {
                //todo
            }
        });

    }


});