<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/11 0011
 * Time: 16:57
 */


require_once("../API/qqConnectAPI.php");
$qc = new QC();
$qc->qq_login();

 
 
 
 
 

 
 
 
 
 
 
 
 
 