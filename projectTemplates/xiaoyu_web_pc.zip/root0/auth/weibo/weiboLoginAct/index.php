<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/11 0011
 * Time: 18:36
 */

session_start();


if (isset($_SESSION['token'])) {
    require_once('../config.php');
    require_once('../saetv2.ex.class.php');

    $c = new SaeTClientV2(WB_AKEY, WB_SKEY, $_SESSION['token']['access_token']);
    $ms = $c->home_timeline(); // done
    $uid_get = $c->get_uid();
    $uid = $uid_get['uid'];
    $user_message = $c->show_user_by_id($uid);//根据ID获取用户等基本信息


    $uid = $user_message["idstr"]; //字符串型的用户UID
    $screen_name = $user_message["screen_name"]; //用户昵称
    $gender = $user_message["gender"];  //性别，m：男、f：女、n：未知
    $avatar_large = $user_message["avatar_large"]; //用户头像地址（大图），180×180像素
    $avatar_hd = $user_message["avatar_hd"]; //用户头像地址（高清），高清头像原图


    require_once "../../../vendor/autoload.php";

    Requests::register_autoloader();

    //请求头部
    $headers = array('Content-Type' => 'application/json');

    $data = array('userType' => 2, 'opeId' => $uid, 'avatar' => $avatar_large, 'nickname' => $screen_name);

    //第三方登陆接口
    $url = "http://api.91xiaoyu.com/rs/user/login";
    $request = Requests::post($url, $headers, json_encode($data));
    $user_info = json_decode($request->body, true);

    !empty($user_info["data"]["nickname"]) ? $_SESSION["nickname"] = $user_info["data"]["nickname"] : $_SESSION["nickname"] = "小雨点"; //用户昵称
    !empty($user_info["data"]["realname"]) ? $_SESSION["realname"] = $user_info["data"]["realname"] : $_SESSION["realname"] = null; //真实姓名
    !empty($user_info["data"]["avatar"]) ? $_SESSION["avatar"] = $user_info["data"]["avatar"] : $_SESSION["avatar"] = "http://ai.91xiaoyu.com/xiaoyu_pc/images/defpic.jpg"; //头像
    !empty($user_info["data"]["grade"]) ? $_SESSION["grade"] = $user_info["data"]["grade"] : $_SESSION["grade"] = null; //年级

    !empty($user_info["data"]["ext"]["exp"]) ? $_SESSION["exp"] = $user_info["data"]["ext"]["exp"] : $_SESSION["exp"] = 0; //经验值
    !empty($user_info["data"]["ext"]["learned"]) ? $_SESSION["learned"] = $user_info["data"]["ext"]["learned"] : $_SESSION["learned"] = 0; //累计学习天数
    !empty($user_info["data"]["ext"]["gc"]) ? $_SESSION["gc"] = $user_info["data"]["ext"]["gc"] : $_SESSION["gc"] = 0; //金币数
    !empty($user_info["data"]["ext"]["sc"]) ? $_SESSION["sc"] = $user_info["data"]["ext"]["sc"] : $_SESSION["sc"] = 0; //星数

    !empty($user_info['data']["birthday"]) ? $_SESSION["birthday"] = date("Y-m-d", $user_info['data']["birthday"]) : $_SESSION["birthday"] = null; //生日


    $_SESSION["cusId"] = $user_info["data"]["id"];


    //登陆标志位-全局使用
    $_SESSION["is_login"] = "bl4ctruxojGx3C5Y";

    header('Location:../../../myhome.php');


} else {
    exit("非法访问~");
}



 
 
 
 
 