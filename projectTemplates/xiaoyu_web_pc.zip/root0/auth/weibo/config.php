<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '731326247' );
define( "WB_SKEY" , 'a9a2ad9225fd51ec451e2c02708d289d' );
define( "WB_CALLBACK_URL" , 'http://www.91xiaoyu.com/authReturnDir/weibocallback.php' );
