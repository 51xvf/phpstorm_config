<?php

namespace ccccc;


require './vendor/autoload.php';


use Respect\Validation\Validator as v;

$number = "1";


$xx = v::trueVal()->validate($number); // true


echo $xx;


/**
 * @param $arr
 */

function p($arr)
{

    echo "<pre>";

    print_r($arr);

    echo "</pre>";
}



