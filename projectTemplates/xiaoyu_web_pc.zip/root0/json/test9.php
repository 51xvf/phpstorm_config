<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/30 0030
 * Time: 10:44
 */




require_once "../vendor/autoload.php";


//保存Session测试

/*$session = new \vakata\session\Session(); // autostarts session and applies useful defaults

$session->set('val.ue.cc.jj', "xxxxxx"); // same as $_SESSION['val'] = [ 'ue' => 1 ];
$session->set('val.xx.gg.kk', true); // same as $_SESSION['val'] = [ 'ue' => 1 ];
$session->set('val.yy.dd.uu', 45.78); // same as $_SESSION['val'] = [ 'ue' => 1 ];
$session->set('val.yy.dd.uu', array("name"=>21,"age"=>32,"arr"=>[1,2,3,5],6,8)); // same as $_SESSION['val'] = [ 'ue' => 1 ];
//$session->del('val'); // same as unset($_SESSION['value']);


$xx = $session->get('val'); // same as $_SESSION['value'];

 */
 
 //print_r($xx);





//SessionCache->Memcache测试

// optionally sessions can be stored in memcached / filecache / database
$sessionDB = new \vakata\session\Session(
    true, // autostart
    new \vakata\session\handler\SessionCache(
        new \vakata\cache\Memcache(),
        'namespace_yinjun' // this allows easy clearing
    )
);


$sessionDB->del("","");

$sessionDB->set("x.test_name","test_yinjun",".");
$sessionDB->set("x.test_name1","test_yinjun1",".");
$sessionDB->set("x.test_name2","test_yinjun2",".");
$sessionDB->set("x.test_name3","test_yinjun3",".");
$sessionDB->set("x.test_name4","test_yinjun4",".");
$sessionDB->set("x.test_name5","test_yinjun5",".");
$sessionDB->set("x.test_name6","test_yinjun6",".");



//$sessionDB->del("x");

//Memcache测试
$cache = new \vakata\cache\Memcache(); // by default connects to 127.0.0.1

$cache->set("xxx",["name"=>"yinjun","age"=>21],"default",800);
//$cache->clear("default");

$zz = $cache->get("xxx");


//print_r($cache);

echo "<hr>";

//echo $zz;



p($zz);


/**
 * @param $arr
 */

function p($arr)
{

    echo "<pre>";

    print_r($arr);

    echo "</pre>";
}




//文件测试
// $f = new \vakata\cache\Filecache("./test/test.txt");
$f = new \vakata\cache\Filecache(__DIR__ . '/test',"def");
$f->set("xx",["name"=>"yinjun","age"=>21,"nianji"=>"chuyi"]);

$s = $f->get("xx");


p($s) ;



//原生memcathe

$mem = new Memcache;

$mem->connect("127.0.0.1", 11211);

$mem->set('test','123444444444',0,60);
 
$a = $mem->get('test');

echo $a;


print_r($_SESSION["x"]);








