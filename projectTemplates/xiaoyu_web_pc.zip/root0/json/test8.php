<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/23 0023
 * Time: 10:47
 */
 
 

require_once "../vendor/autoload.php";


$url = urldecode($_GET["data"])?urldecode($_GET["data"]) :"xxxxxxxx";



/*

use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\LabelAlignment;
use Endroid\QrCode\QrCode;

// Create a basic QR code
$qrCode = new QrCode('Life is too short to be generating QR codes');
$qrCode->setWriterByName('png')->setSize(300)->setErrorCorrectionLevel(ErrorCorrectionLevel::HIGH)->setText($url)->setMargin("45")->setLogoPath('../images/logo.png')->setForegroundColor(['r' => 255, 'g' => 0, 'b' => 255])->setBackgroundColor(['r' => 255, 'g' => 255, 'b' => 255])->setLabel('扫码支付',25,__DIR__.'/../font/simkai.ttf','center')->writeFile(__DIR__.'/../uploads/tt.jpg');



// Directly output the QR code

header('Content-Type: '.$qrCode->getContentType());
echo $qrCode->writeString();

*/

/*
$password ="5594518@20161";

$lib = new PasswordLib\PasswordLib();
$hash = $lib->createPasswordHash($password);
$boolean = $lib->verifyPasswordHash($password, $hash);

$a = $lib->getRandomNumber(1,1000);


$token = $lib->getRandomToken(6);

echo $hash;

echo "<hr>";

echo $boolean;

echo "<hr>";

echo $token;


echo "<hr>";
echo $a;
*/




use Hashids\Hashids;

$hashids = new Hashids();

$id = $hashids->encode(1, 2, 3); // o2fXhV
$s = $hashids->encode(123456);
$numbers = $hashids->decode($id); // [1, 2, 3]

$d = $hashids->decode($s);


echo $id;
echo "<hr>";
echo $s;
echo "<hr>";
p($d);
echo "<hr>";
p($numbers);

/**
 * @param $arr
 */

function p($arr)
{

    echo "<pre>";

    print_r($arr);

    echo "</pre>";
}















