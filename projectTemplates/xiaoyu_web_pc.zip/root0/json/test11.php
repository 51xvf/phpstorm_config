<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/31 0031
 * Time: 08:57
 */




require_once "../vendor/autoload.php";






//本地测试
$db = new \vakata\session\Session(
    true, // autostart
    new \vakata\session\handler\SessionDatabase(
        new \vakata\database\DB('mysqli://root:root@127.0.0.1/test'),
        'ses_table'
    )
);

/*$db->del("xxx");
$db->close();
$db->destroy();*/

$h = $db->get("xxx");


p($h);




/**
 * @param $arr
 */

function p($arr)
{

    echo "<pre>";

    print_r($arr);

    echo "</pre>";
}



//ini_set("session.save_handler","user");



//require_once "../func/session.class.php";


/*
$_SESSION["username"]="yinjun";
$_SESSION["age"]=32;
$_SESSION["sex"]=true;
$_SESSION["uid"]=332222;
$_SESSION["isLogin5"]=1;
*/











