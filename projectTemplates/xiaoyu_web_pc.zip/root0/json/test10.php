<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/30 0030
 * Time: 11:42
 */



require_once "../vendor/autoload.php";


//session_start();



/*
$session = new \vakata\session\Session(); // autostarts session and applies useful defaults



$xx = $session->get('val'); // same as $_SESSION['value'];




//print_r($xx);











$cache = new \vakata\cache\Memcache(); // by default connects to 127.0.0.1

//$cache->set("xx","yinjun","def",10);

$zz = $cache->get("xxx");

//print_r($cache);

echo "<hr>";

echo $zz;
*/




/*
$sessionDB = new \vakata\session\Session(
    true, // autostart
    new \vakata\session\handler\SessionCache(
        new \vakata\cache\Memcache(),
        'namespace_yinjun' // this allows easy clearing
    )
);
 
 
 print_r($_SESSION["x"]);
*/



/*
$cache = new \vakata\cache\Memcache(); // by default connects to 127.0.0.1

$cache->set("xxxz",["name"=>"yinjun","age"=>21],"default",10);
$d = $cache->get("xxxz");
//$cache->clear("namespace_yinjun");




 p($d);
 */





//本地测试
$db = new \vakata\session\Session(
    true, // autostart
    new \vakata\session\handler\SessionDatabase(
        new \vakata\database\DB('mysqli://root:root@127.0.0.1/test'),
        'ses_table'
    )
);



$h = $db->get("xxx");











p($_SESSION);


/**
 * @param $arr
 */

function p($arr)
{

    echo "<pre>";

    print_r($arr);

    echo "</pre>";
}


 