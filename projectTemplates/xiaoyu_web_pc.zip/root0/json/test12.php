<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/31 0031
 * Time: 10:56
 */


ini_set("session.save_handler","user");


require_once "../func/session.class.php";



print_r($_SESSION);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 