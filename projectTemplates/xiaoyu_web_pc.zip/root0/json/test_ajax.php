<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/9/11 0011
 * Time: 09:26
 */


$xxx = '{
  "code": 0,
  "message": "成功",
  "totalCount": 0,
  "type": 0,
  "data": [
    {
      "name": "aa",
      "exams": [
        {
          "id": 175,
          "text": null,
          "playUrl": null,
          "summary": null,
          "speak": null,
          "analysis": null,
          "star": 6,
          "vip": 0,
          "exp": 0,
          "coin": 0
        }
      ]
    },
    {
      "name": "bb",
      "exams": [
        {
          "id": 176,
          "text": null,
          "playUrl": null,
          "summary": null,
          "speak": null,
          "analysis": null,
          "star": 6,
          "vip": 0,
          "exp": 0,
          "coin": 0
        }
      ]
    },
    {
      "name": "cc",
      "exams": [
        {
          "id": 177,
          "text": null,
          "playUrl": null,
          "summary": null,
          "speak": null,
          "analysis": null,
          "star": 6,
          "vip": 0,
          "exp": 0,
          "coin": 0
        }
      ]
    },
    {
      "name": "dd",
      "exams": [
        {
          "id": 178,
          "text": null,
          "playUrl": null,
          "summary": null,
          "speak": null,
          "analysis": null,
          "star": 6,
          "vip": 0,
          "exp": 0,
          "coin": 0
        }
      ]
    },
    {
      "name": "ee",
      "exams": [
        {
          "id": 179,
          "text": null,
          "playUrl": null,
          "summary": null,
          "speak": null,
          "analysis": null,
          "star": 6,
          "vip": 0,
          "exp": 0,
          "coin": 0
        }
      ]
    }
  ]
}';


echo $xxx;
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 