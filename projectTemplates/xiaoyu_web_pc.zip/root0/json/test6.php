<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/5 0005
 * Time: 16:42
 */
 
 
 
 echo 6;
 
 
 echo 77777;
 
 
 
 echo 888888;
 
 
 
 
 echo 22222;
 
 
 echo 4444;
 
 echo 55555;
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 