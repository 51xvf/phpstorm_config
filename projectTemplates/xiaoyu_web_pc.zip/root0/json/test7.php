<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Span模拟单选按钮Radio</title>


    <style type="text/css">
        .unchecked {
            border: 1px solid gray;
            padding: 6px 6px 6px 6px;
            cursor: pointer;
        }

        .checked {
            border: 2px solid #c00;
            padding: 6px 6px 6px 6px;
            cursor: pointer;
        }
    </style>


</head>

<body>
</body>


<script type="text/javascript" src="../js/chapterlist/jquery-1.7.1.min.js"></script>





<script type="text/javascript">




    var obj = {
        colorSpan: "",
        sizeSpan: "",
        chandi:""
    };



    function change(span) {
        $('span[name="' + $(span).attr('name') + '"]').each(function () {
            if (this.checked && this != span) {
                this.className = "unchecked";
                this.checked = false;
            }
        });
        obj[$(span).attr('name')] = span.innerHTML;
        span.className = "checked";
        span.checked = true;
        select();
    }



    function select() {
        var html = '';
        for (var i in obj) {
            if (obj[i] != '') {
                html += '<font color=orange>"' + obj[i] + '"</font> 、';
            }
        }
        html = '<b>已选择:</b> ' + html.slice(0, html.length - 1);
        $('#resultSpan').html(html);

    }


</script>


<div>
    颜色:
    <span class='unchecked' name='colorSpan' checked='false' onclick='change(this);'>卡其格</span>
    <span class='unchecked' name='colorSpan' checked='false' onclick='change(this);'>黑白格</span>
</div>


<br/>
<br/>



<div>
    尺码:
    <span class='unchecked' name='sizeSpan' checked='false' onclick='change(this);'>S</span>
    <span class='unchecked' name='sizeSpan' checked='false' onclick='change(this);'>M</span>
    <span class='unchecked' name='sizeSpan' checked='false' onclick='change(this);'>L</span>
</div>




<br/>
<br/>





<div>
    产地:
    <span class='unchecked' name='chandi' checked='false' onclick='change(this);'>北京</span>
    <span class='unchecked' name='chandi' checked='false' onclick='change(this);'>上海</span>
    <span class='unchecked' name='chandi' checked='false' onclick='change(this);'>陕西</span>
</div>







<br/>
<br/>




<div>
    <b>提示:</b>
    <span id='resultSpan'></span>
</div>



</html>