<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/24 0024
 * Time: 09:31
 */

session_start();

echo 1111;

/*echo '<script>var img=newImage();img.src="http：//changyan.sohu.com/api/2/logout？client_id=cyr7gJLTt";</script>';


sso_loginout();


function sso_loginout()
{


    if (!isset($_SESSION["is_login"])) {
        $return = array(
            'code' => 1,
            'reload_page' => 0
        );
    } else {
        //$mwuser->logout();
        $return = array(
            'code' => 1,
            'reload_page' => 1
        );
    }
}
 
 
 */
 
 
 
 
 
 
 
 
 
 