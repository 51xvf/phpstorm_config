<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/26 0026
 * Time: 09:29
 */

$shareID = "tsina"; //分享ID参数代表你要分享到哪个站点的ID编号, 可以通过这个文档查询：分享网站ID清单
$siteUrl = "http://ke.91xiaoyu.com"; //参数代表你要分享的网站链接地址，可以通过动态程序调用
$siteTitle = "这是分享标题"; //参数代表你要分享的网站页面标题，可以通过动态程序调用，也可自定义。
$uid = 1623117; //(非必须) 代表你注册JiaThis的会员UID，可以登录网站后查到您的UID，用于数据统计。
$summary = "这是一大段描述信息这是一大段描述信息这是一大段描述信息这是一大段描述信息这是一大段描述信息";
$appkey = 731326247;

$url = "http://www.jiathis.com/send/?webid=$shareID&url=$siteUrl&title=$siteTitle&summary=$summary&uid=$uid&appkey=$appkey";


?>


<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>小雨在线-开发测试</title>


</head>
<body>





    <div class="container" style="margin-top: 25px">

        <!-- JiaThis Button BEGIN -->
        <div class="jiathis_style_32x32">
            <a class="jiathis_button_qzone"></a>
            <a class="jiathis_button_tsina"></a>
            <a class="jiathis_button_tqq"></a>
            <a class="jiathis_button_renren"></a>
            <a class="jiathis_button_kaixin001"></a>
            <a href="http://www.jiathis.com/share?uid=1623117"
               class="jiathis jiathis_txt jiathis_separator jtico jtico_jiathis" target="_blank"></a>
            <a class="jiathis_counter_style"></a>
        </div>
        <script type="text/javascript">
            var jiathis_config = {
                url: "",
                title: "韩教授中考数学难题训练",
                summary: "每日一题，天天训练，做个有实力的学霸！",
                shortUrl: false,
                hideMore: true,
                data_track_clickback: true,
                pic: "http://www.91xiaoyu.com/images/reg.jpg",
                /*      sm:"tsina,tqq,t163,tsohu",
                      siteNum:4,*/
                appkey: {tsina: "731326247"},
                siteName: "小雨在线",
                evt: {"share": "geturl"}
            };


            function geturl(evt) {
                console.log(evt.data);
            }


        </script>
        <script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1623117" charset="utf-8"></script>
        <!-- JiaThis Button END -->


        <br><br><br>

        <a href="<?php echo $url; ?>" target="_blank">xxxxx</a>




    </div>





</body>
</html>



 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 