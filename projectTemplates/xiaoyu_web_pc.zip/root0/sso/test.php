<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/24 0024
 * Time: 09:35
 */
session_start();



p($_SESSION);

/**
 * @param $arr
 */

function p($arr)
{

    echo "<pre>";

    print_r($arr);

    echo "</pre>";
}




?>


<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>小雨在线-开发测试</title>
    <script type="text/javascript" src="../json/paytest/jquery.min.js"></script>
    <script type="text/javascript" src="http://test.91xiaoyu.com/plus/layer/layer.js"></script>



        <link href="./bootstrap.min.css" rel="stylesheet">



</head>
<body>


<div class="container">




    <!--PC和WAP自适应版-->
    <div id="SOHUCS" sid="40" ></div>
    <script type="text/javascript">
        (function(){
            var appid = 'cyr7gJLTt';
            var conf = 'prod_3948730d3bfbcc822e6cebe4361364ba';
            var width = window.innerWidth || document.documentElement.clientWidth;
            if (width < 960) {
                window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="https://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("https://changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>



</div>


<!--
<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

-->

<script>




    function cyLogin() {

        //询问框
        layer.confirm('评论前需登录殴~', {
            btn: ['登录', '取消'] //按钮
        }, function () {
            layer.msg('登录操作');
        }, function () {
            layer.msg('取消操作');
        });

    }


</script>


</body>
</html>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 