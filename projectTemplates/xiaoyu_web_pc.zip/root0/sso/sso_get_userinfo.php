<?php
/**
 * Created by 小雨在线.
 * User: 飛天
 * Date: 2017/10/24 0024
 * Time: 09:28
 */

session_start();


/*
changyan_sso::getuserinfo();

class changyan_sso
{
    public static function getuserinfo()
    {
        global $wgUser; //全局变量
        // (注意：$wgUser变量用来表示用户在您网站登录信息，该变量得开发者自己实现，实现方式一般是通过cookie或session原理)
        if ($wgUser->getId() != 0) {
            $ret = array(
                "is_login" => 1, //已登录，返回登录的用户信息
                "user" => array(
                    "user_id" => $wgUser->getId(),
                    "nickname" => $wgUser->getName(),
                    "img_url" => "",
                    "profile_url" => "",
                    "sign" => "**" //注意这里的sign签名验证已弃用，任意赋值即可
                ));


        } else {
            $ret = array("is_login" => 0);//未登录
        }

        echo $_GET['callback'] . '(' . json_encode($ret) . ')';

    }
}*/



sso_login();

/**
 *
 */
function sso_login()
{

    if (isset($_SESSION["is_login"])) {
        $ret = array(
            "is_login" => 1, //已登录，返回登录的用户信息
            "user" => array(
                "user_id" => 80,
                "nickname" => '隔壁老王',
                "img_url" => "http://api.91xiaoyu.com/upload/80/ava/10_2017_10_06_09_53_38.jpg",
                "profile_url" => "http://www.91xiaoyu.com/",
                "sign" => "**" //注意这里的sign签名验证已弃用，任意赋值即可
            ));

    } else {
        $ret = array("is_login" => 0);//未登录
    }

    echo $_GET['callback'] . '(' . json_encode($ret) . ')';


}



 
 
 
 
 
 
 
 
 
 
 
 
 