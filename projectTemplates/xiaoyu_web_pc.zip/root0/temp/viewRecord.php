<?php

require_once "../RESTApi/is_Login.php";

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <link href="../css/space/kEVUV.css?t=1446710456" rel="stylesheet" type="text/css"/>
    <link href="../css/space/6wqd1-dqsBY-tPDc-19vqxg-TfFPT-13nnKF-5MzDa-c5en6-XATuT-XcmpP-wt0O9-12m8Cq-izBle-s6kkN.css?t=1481181424"
          rel="stylesheet" type="text/css"/>
    <link href="../css/space/8BBKm-BYGSc-crFms-lsDsZ.css?t=1479458562" rel="stylesheet" type="text/css"/>

    <script type="text/javascript" src="../js/space/12ArWF.js?t=1441100803"></script>
    <script type="text/javascript" src="../myhome/laydate/js/laydate.js"></script>
    <script type="text/javascript" src="http://test.91xiaoyu.com/plus/layer/layer.js"></script>
    <script type="text/javascript" src="../js/space/myhome.js?t=1444968198"></script>


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>韩教授难题训练-基本资料修改_个人空间</title>
    <meta name="keywords" content="个人空间"/>
    <meta name="applicable-device" content="pc"/>
    <style type="text/css">

        .course_prosess_div {
            width: 530px !important;
        }

        .course_prosess {
            width: 477px;
        }

        .records_course_name {
            width: 125px !important;
        }
    </style>

</head>
<body>


<?php include_once "../head.php" ?>

<div class="wrapper clearfix" style="margin-bottom:20px;">
    <div class='space_header'>

        <div class='img_cover'>

            <img id="sh_space_image" data-id="1" src='../images/default.jpg'
                 data-origin_src="../images/default.jpg"/>

            <div class="sh_img_bottom"></div>
        </div>

        <div class='user_profile clearfix'>
            <div class='avatar'>
                <div>
                    <img src="<?php echo $avatar; ?>"/>
                </div>
                <a href="#" class="change_avatar"></a>
            </div>


            <div class='user_info'>
                <div class='top clearfix'>
                    <span class='uname'><?php echo $nickname; ?></span><span>（雨点号：27475336）</span>
                    <span class='sex' title='男'>&nbsp;</span>
                    <span class='sh_role sh_r_student' title='学生'></span>

                </div>
                <div class='bottom'>

                    <div class="right clearfix">
                        <div class="light_medal"><img title="获得经验值数<?php echo $exp; ?>" width="57" height="62"
                                                      src="../images/christmas-gift-box.png" alt=""/></div>
                        <div class="light_medal"><img title="获得金币数<?php echo $gc; ?>" width="57" height="62"
                                                      src="../images/jinbi.png" alt=""/></div>
                        <div class="light_medal"><img title="获得星数<?php echo $sc; ?>" width="57" height="62"
                                                      src="../images/star-icon.png" alt=""/></div>
                        <div class="light_medal"><img title="累计学习天数<?php echo $learned; ?>" width="57" height="62"
                                                      src="../images/sheng.png" alt=""/></div>
                    </div>


                    <table id="mytable" border="1" bordercolor="#E0E0E0" cellpadding="0" cellspacing="0"
                           style="border-collapse:collapse" width="100%">

                        <tbody>


                        <tr>

                            <td>经验值</td>
                            <td>金币数</td>
                            <td>星数</td>
                            <td>累计学习天数</td>
                        </tr>


                        <tr>

                            <td><?php echo $exp; ?></td>
                            <td><?php echo $gc; ?></td>
                            <td><?php echo $sc; ?></td>
                            <td><?php echo $learned; ?></td>
                        </tr>


                        </tbody>


                    </table>


                </div>
            </div>


        </div>
    </div>
    <div style="background-color: #fafafa;padding: 0px 0px 15px 20px;">
        <div class="breadcrumb">
            <span><a href="../index.php">首页</a></span>
            <span>&gt;</span>
            <span>个人设置</span>
        </div>
    </div>


    <!--    主体区开始-->


    <div class="personal_set_main clearfix" style="padding:20px 0;height:600px;">
        <div class="psm_left clearfix" style="float:left;width:200px;height:100%;">


            <?php include_once "../myhomeMenu.php" ?>

        </div>
        <div class="psm_right clearfix" style="float:left;width:738px;border:1px solid #e0e0e0;">


            <div class="personal_update clearfix" style="padding:10px;">


                <!--历史记录-->

                <div class="last_records_course">
                    <div class="last_records_course_items">
                        <div class="loading" style="height: 95px;width: 149px"></div>

                    </div>
                </div>

                <!--历史记录结束-->

            </div>


        </div>
    </div>
    <!--    主体区结束-->


</div>




<div id="querySummary" style="display: none">

<p>111111111111111</p>
    <p>222222222222222</p>
    <p>33333333333333333333</p>


</div>




<?php include_once "../footer.php" ?>

</body>
</html>