<?php
$config = array (
    //应用ID,您的APPID。
    'app_id' => "2015121500980317",

    //商户私钥，您的原始格式RSA私钥
    'merchant_private_key' => "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCC74iglXDz5glYUMYBUakU9Awi5aY/sVUcBVX+6vNP/Eb5b743vqpWJ5x+Q3TJ5YeBF4k4J+QKeMkx2DIRM0rU9oOf07kINQhh5LsHslYpY34+Dr3DhNf/cjBsKjfNF20R2W38h1KkQkbxkpvmSven5fcg/y2nEagDwGbiwSGMSbYtX2+wJ5aaoA7QA5YHttpxgIghz2S6GMb09Uflpz4iG+uH4O1+lzjZ3LWHgWW+BqBR7czgAL2e2oYwsei2iEZXtcnEE4nzseHpaOD3FAXd5LStOwN0O+o6xb4yH3NbwW4Jl7dZzd9wJo97EOpV4COQ15K9d6rr81V60SaFqMIfAgMBAAECggEAOXURuJ47ldvxZ97yNOv3zakWlk2+eZ7A4W36AcZqhUQIhTci+uVhbDMvujyxyFM/9kc0wP7IVEwSxhvARMoEYZXXxtArF03mYsbzx/nbU4hEgskHPwBRpNggJacVG5vXEgke+b0MZ+ZpqWKTpShqqzQAEWvJRdI6r4LD42eq6BthDTpXNZt9Xv1nekINqlRWFvdh4WQyHdFwjNLmZ618LWE3fJz4qakQsYt41+KyDvFyMfoUJd5LOKo0SrMQNfoYkhIJ4igIxQUvCkjo/5X2kaP+erHrPCIsrRhaQSdAOfu13gQIFXGJE+vs3CQf2NQiN3e5V1QOZ4/+78oassBjyQKBgQDdZvY4wEBDXOFvXpin2mFaz0Bi7dZR1xciykXm9lx7YN/SL2HrYZag3ytPUGbEOtcEb4cXiVMC01h5+xVE0jbAD1pcnhyQDFIuLYL5vxBfFhFOzQhw5PieOoaIgojFh9+zerJ/nnUzbKCsUbjgbEphPweIAv7WY3toOEMBMscCuwKBgQCXZYXdZZN2t/J/OO68id/ldMAf2u4RIg0cs0+mM5g9wf8ti3rty1eBX24yrAn+kE1o/Yok9KsjdbqQaEkJnBIWTvToUUWGM2lQsy8STo2o8DLAGtHXANWRq8wr9fyN0xA5EdIIsRYVZ3g+Qm27X9eoK5uRo9c3QTnH0mm76/GB7QKBgFPtMsrifbnLXJ2GA2IlkyAETkjyFXsiiN+kQ4lAvF/8ofugAINkk9/ZmSZQuRQLpfRFfrU6ViBNE03yEubqtNxrNXrEaNlmAkUE9ZBMkB0rVVZEvL1m3qPEVbkrmkMetXrouP9Nhun+dI290NIp2qwwY194mzeTsHUaVrP+lpf/AoGARQaMmfyN1zrW3Rpf/qX95ufsEJoIoNcdk1BNqEEt0Dp61ZEaYwCqzNltrLyzcdTo9k1ihqbmwCwU+3IQmskFlhY5oxIq2JzoD1siwv39qGCbQur3cUd4GApz9DcbBq6MXvi5Ai17HBcow3oV/bAc6xe2vhgtL4wVg/1zJ7LTUaECgYEA0hvig2qd8wsFIMl056jg0PRfljOHFBTqw1a3cnLQncGiGDm7OiTqdJOPQBG2VUH0IiuuX4payEQF0Zs41pDBoK6Xyxe6eXuPn+0ghmACy6fuH9G6BWYfcelnQ3KnEegSZmU/srHptgD+OniwzB6XHlsnM3oVEsaNPXtlPXQUBV0=",

//		http://test.91xiaoyu.com/test/unit/alipay/mob/return_url.php?total_amount=0.01&timestamp=2017-07-20+18%3A25%3A56&sign=X%2FTGLODyT1o0TKCgZ3bEqVZMhlzdqGz5JhPlcew2YvCGIOeAh92M8TfJ5o%2BUeTs%2BRU7ZXCT9o6gUHtRvJbJ7C%2FvHBaL5PtaBeWIVPyC6nUuZbEpiIY9Dp7Pi7qjQSdQys79d5riWmTJnJBRL7qRuKzoAo8sxyL9y0OKIVIiXMCCjR0SlNgbTf6bAInZM9JAZq2fUBw4ymciaVhF4lt8yc6Tva9M5LgbRDVIjLMkM7uuadR3Mr%2B5z%2B1eEdervgY2KE2mEonoEUyxpIp1EJOyqAJnxUwSqbHSox2Qasj6G8jqWeQ3MwKxa69I0RCqeB%2F8CjJN50mCtFCDx2fGMh%2BebDA%3D%3D&trade_no=2017072021001004000270820836&sign_type=RSA2&auth_app_id=2015121500980317&charset=UTF-8&seller_id=2088711720556226&method=alipay.trade.wap.pay.return&app_id=2015121500980317&out_trade_no=2017720182455390&version=1.0


    //异步通知地址
    'notify_url' => "http://test.91xiaoyu.com/test/unit/alipay/mob/notify_url.php",

    //同步跳转
    'return_url' => "http://test.91xiaoyu.com/test/unit/alipay/mob/return_url.php",

    //编码格式
    'charset' => "UTF-8",

    //签名方式
    'sign_type'=>"RSA2",

    //支付宝网关
    'gatewayUrl' => "https://openapi.alipay.com/gateway.do",

    //支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    'alipay_public_key' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApDLF7+TLr1IXFJApqsyZfXq6bCNpsYYtbGDFqVd9WZIc51g/Zhqum742XDlBVz2EvG2mRaZGdCaa3zFyyNWiIRIh36IGgO9je+XAXtL+SzH7sSHqvNa+YbRLYvSjVSL6Q9n1VvyGtEv2byMNjdEGIZZecodQvfPRzpof+hJil2WyukMXZGW9bNmjv+jOs89KUl6CSNVSsWpsqhkjJEXwKnQLaddB+k/KouKyEG7b5rxU+UFMbas3H72ahRa78KUHPK7261on+iZO7kh2h9EC/emy6NXBl/unytm8OrCDCY4/9QJ2bXRcLQOBbqOYHvdNom6E7cE2zp3LsSQSPtI+pwIDAQAB",


);